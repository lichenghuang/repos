﻿using System;
using System.IO;
using EDLib;
using EDLib.SQL;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;

namespace BrokerSQL4
{
	class Program
	{
		static double Jumpsize(double p)
		{
			if (p < 5)
				return (0.01);
			else if (p < 10)
				return (0.05);
			else if (p < 50)
				return (0.1);
			else if (p < 100)
				return (0.5);
			else if (p < 500)
				return (1);
			else
				return (5);
		}

		static double TenTickAdj(double p)
		{
			int count = 1;
			double jumpSize = Jumpsize(p);
			while (count <= 10)
			{
				p = p - jumpSize;
				jumpSize = Jumpsize(p);
				count += 1;
			}
			return Math.Max(p, 0);
		}

		static void Main(string[] args)
		{
			StreamReader reader = null;
			/*Get Input & open the daily quotation files*/
			try
			{
#if !DEBUG
				string date = "20181130";//TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");//
				//string[] dateTrade = { "20180706", "20180709", "20180710", "20180711", "20180712", "20180713","20180716", "20180717", "20180718", "20180719", "20180720", "20180723"};
#else
				Console.Write("Please input date (yyyyMMdd):");
				string date = Console.ReadLine();
#endif
				//foreach (string date in dateTrade)
				//{
					Console.WriteLine($"Inserting WarrantTradingBroker of {date}");

					reader = new StreamReader($"\\\\10.19.1.203\\Warrant\\QuoteData\\JQuote\\{date}\\WarrantData_v3.csv", System.Text.Encoding.Default);//TODO
					// reader = new StreamReader($@"C:\Users\0010150\Desktop\WarrantBroker\{date}.csv", System.Text.Encoding.Default);//TODO																																				/*Open SQL Connection & Delete old data*/
					using (SqlConnection conn = new SqlConnection("Data Source=10.19.1.45;Initial Catalog=newEDIS;User ID=sa;Password=dw910770"))
					{
						conn.Open();

						MSSQL.ExecSqlCmd($"DELETE FROM WarrantTradingBroker WHERE TDate>='{date}' and TDate<='{date} 23:59'", conn);
						string[] stringSeparators = { "\",\"", "\",", ",\"", "," };
						int[] bidIndex = {12, 14, 16, 18, 20 };
						string[] lineSplit = reader.ReadLine().Split(stringSeparators, StringSplitOptions.None);
						using (StreamWriter sqlLog = new StreamWriter(".\\SQLlog.txt"))
						{
							while (!reader.EndOfStream)
							{
								List<double> bidspread = new List<double>();
								string minBidSpread;
								lineSplit = reader.ReadLine().Split(stringSeparators, StringSplitOptions.None);
								for (int i = 0; i < lineSplit.Length; i++)
								{
									lineSplit[i] = lineSplit[i].ToString() == "NA" ? "(NULL)" : lineSplit[i];
								}
								foreach (int i in bidIndex)
								{
									if (lineSplit[100] != "(NULL)" && lineSplit[8] != "(NULL)" && lineSplit[8] != "0" && lineSplit[101] != "(NULL)" && lineSplit[101] != "0" && lineSplit[i] != "(NULL)")
									{
										if (double.Parse(lineSplit[i]) >= Math.Min(TenTickAdj(double.Parse(lineSplit[8])), TenTickAdj(double.Parse(lineSplit[101]))))
											bidspread.Add(double.Parse(lineSplit[100]) - double.Parse(lineSplit[i]));
									}
								}
								if (bidspread.Count == 0)
								{
									minBidSpread = "(NULL)";
								}
								else
								{
									bidspread = bidspread.OrderBy(x => Math.Abs(x)).ToList();
									if (bidspread.Count > 1 && bidspread[0] + bidspread[1] == 0)
										minBidSpread = Math.Max(bidspread[0], bidspread[1]).ToString();
									else
										minBidSpread = bidspread[0].ToString();
								}
								lineSplit[102] = lineSplit[102].ToString() == "" || lineSplit[102].ToString() == "NaN" ? "(NULL)" : lineSplit[102];
								lineSplit[103] = lineSplit[103].ToString() == "" || lineSplit[103].ToString() == "NaN" ? "(NULL)" : lineSplit[103];
								lineSplit[96] = lineSplit[96].ToString() == "" || lineSplit[96].ToString() == "NaN" ? "(NULL)" : lineSplit[96];
								string SQLcmd = $@"Insert into WarrantTradingBroker(TDate, WID, LastPx, LastQty, BrokerBuy, BrokerSell, BrokerBuyFlag, BrokerSellFlag, RanOver, PnL, SerialNumber, Delta, BrokerBuyID, BrokerSellID, HPnL, RanOverDelete, BaseLineVol, DeltaBid, DeltaAsk, TheoBid, TheoAsk, HedgeDepth, DepthPnL, Bid1, Bid2, Bid3, Bid4, Bid5, Ask1, Ask2, Ask3, Ask4, Ask5, MinBidSpread) Values("
								  + $"'{lineSplit[0].TrimStart('"')}','{lineSplit[1]}','{lineSplit[8]}','{lineSplit[10]}','{lineSplit[86]}','{lineSplit[87]}','{lineSplit[88]}'"
								  + $",'{lineSplit[89]}','{lineSplit[92]}',{lineSplit[93]},'{lineSplit[104]}',{lineSplit[95]}, '{lineSplit[105]}', '{lineSplit[106].TrimEnd('"')}'"
								  + $", {lineSplit[94]}, '{lineSplit[97]}', {lineSplit[96]}, {lineSplit[98]}, {lineSplit[99]}, {lineSplit[100]}, {lineSplit[101]}, {lineSplit[102]}, {lineSplit[103]}"
								  + $", {lineSplit[12]}, {lineSplit[14]}, {lineSplit[16]}, {lineSplit[18]}, {lineSplit[20]}, {lineSplit[22]}, {lineSplit[24]}, {lineSplit[26]}, {lineSplit[28]}, {lineSplit[30]}, {minBidSpread})";
								sqlLog.WriteLine(SQLcmd);
								Console.WriteLine(SQLcmd);
								MSSQL.ExecSqlCmd(SQLcmd, conn);
							
							}
						//}
					}
				}
			}
			catch (Exception e)
			{
				Console.ReadLine();
				MailService ms = new MailService();
				ms.SendMail("jerry.zeng@kgi.com", "10.19.1.45 ERROR", new string[] { "jerry.zeng@kgi.com" }, null, null, "BrokerSQL4 ERROR!", e.ToString(), false, null);
			}
			finally
			{
				if (reader != null)
					reader.Close();
			}
		}
	}
}

