﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using System.IO.Compression;
using EDLib;
using EDLib.SQL;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace BrokerClassification
{
	class Program
	{

		private static object brokerLock = new object();

		//抓出自營與造市交易
		static DataTable WarrantTradingBroker(SqlConnection newEDIS45, string date)
		{
			string sqlstr = "Select ISNULL(A.WID, B.WID) as WID, ISNULL(A.BrokerBuyID, B.BrokerSellID) as BrokerID, ISNULL(A.PropBuyingLots, 0) as PropBuyingLots, " +
									 "ISNULL(B.PropSellingLots, 0) as PropSellingLots from " +
									 "(SELECT WID, BrokerBuyID, SUM(LastQty) as PropBuyingLots FROM[newEDIS].[dbo].[WarrantTradingBroker] " +
                                     $"where cast(TDate as Date) = '{date}' and BrokerBuyFlag = 'Prop' and BrokerBuyID <> '' " +
                                     "group by WID, BrokerBuyID) as A full join " +
                                     "(SELECT WID, BrokerSellID, SUM(LastQty) as PropSellingLots " +
                                     "FROM[newEDIS].[dbo].[WarrantTradingBroker] " +
                                     $"where cast(TDate as Date) = '{date}' and BrokerSellFlag = 'Prop' and BrokerSellID<> '' " +
                                     "group by WID, BrokerSellID) as B on A.WID = B.WID and A.BrokerBuyID = B.BrokerSellID ";

			DataTable wTable = new DataTable();
			SqlCommand cmd = new SqlCommand(sqlstr, newEDIS45)
			{
				CommandTimeout = 300
			};
			SqlDataAdapter da = new SqlDataAdapter(cmd);
			da.Fill(wTable);
			foreach (DataRow row in wTable.Rows)
			{
				row["WID"] = row["WID"].ToString().Substring(0, 6);
				if (!row["BrokerID"].ToString().Substring(3, 1).Any(char.IsDigit) && row["BrokerID"].ToString().Substring(3, 1).Any(char.IsLower))
					row["BrokerID"] = row["BrokerID"].ToString().Substring(0, 3) + row["BrokerID"].ToString().Substring(3, 1).ToUpper() + "1";
			}
			return wTable;
		}

		static DataTable FinalTable()
		{
			DataTable dt = new DataTable();
			dt.Columns.Add("TDate");
			dt.Columns.Add("WID");
			dt.Columns.Add("UID");
			dt.Columns.Add("IssuerName");
			dt.Columns.Add("Good");
			dt.Columns.Add("Bad");
			return dt;
		}

		static DataTable InitialNextDayShortTable()
		{
			DataTable dt = new DataTable();
			dt.Columns.Add("TDate");
			dt.Columns.Add("BrokerID");
			dt.Columns.Add("ShortAmount");
			dt.Columns.Add("NextDayShortRatio");
			return dt;
		}

		//分好壞分點
		static Dictionary<string, string> Classification(DataTable brokerInfo, List<double> shortAmountList)
		{
			Dictionary<string, string> dc = new Dictionary<string, string>();
			double shortAmount100 = shortAmountList[99];
			double shortAmount50 = shortAmountList[49];
			foreach (DataRow row in brokerInfo.Rows)
			{
				if ((double.Parse(row["ShortAmount"].ToString()) > shortAmount100 && double.Parse(row["NextDayShortRatio"].ToString()) > 0.9) || (double.Parse(row["ShortAmount"].ToString()) > shortAmount50 && double.Parse(row["NextDayShortRatio"].ToString()) > 0.8))
					dc.Add(row["BrokerID"].ToString(), "Bad");
				else
					dc.Add(row["BrokerID"].ToString(), "Good");
			}
			return dc;
		}

		static List<string> WidList(SqlConnection newEDIS45, string date)
		{
			List<string> widList = new List<string>();
			string sqlstr = " SELECT distinct WID FROM[newEDIS].[dbo].[BrokerHoldingDays] " +
									 " where TDate in (select top(20) TradeDate from [10.60.0.37].[TsQuote].[dbo].[TradeDate] " +
									 $" where IsTrade = 'Y' and TradeDate <= '{date}' order by TradeDate desc) ";
			DataTable widTable = MSSQL.ExecSqlQry(sqlstr, newEDIS45);
			foreach (DataRow row in widTable.Rows)
				widList.Add(row["WID"].ToString());
			return widList;
		}

		static List<string> BrokerIDList(SqlConnection newEDIS45, string date)
		{
			List<string> brokerList = new List<string>();
			string sqlstr = " SELECT distinct BrokerID FROM[newEDIS].[dbo].[BrokerHoldingDays] " +
									 " where TDate in (select top(20) TradeDate from [10.60.0.37].[TsQuote].[dbo].[TradeDate] " +
									 $" where IsTrade = 'Y' and TradeDate <= '{date}' order by TradeDate desc) ";
			DataTable brokerTable = MSSQL.ExecSqlQry(sqlstr, newEDIS45);
			foreach (DataRow row in brokerTable.Rows)
				brokerList.Add(row["BrokerID"].ToString());
			return brokerList;
		}

		//權證的標的與發行商資訊
		static Dictionary<string, string[]> WidInfo(SqlConnection newEDIS45, string date)
		{
			string issuerName, uid;			
			Dictionary<string, string[]> dc = new Dictionary<string, string[]>();
			string sqlstr = $"Select WID, IssuerName, UID from [WarrantTrading] where TDate = '{date}'";
			DataTable wTable = MSSQL.ExecSqlQry(sqlstr, newEDIS45);
			foreach (DataRow row in wTable.Rows)
			{
				string wid = row["WID"].ToString();
				issuerName = wTable.AsEnumerable().Where(r => r["WID"].ToString() == wid).Select(s => s["IssuerName"].ToString()).ToList()[0];
				uid = wTable.AsEnumerable().Where(r => r["WID"].ToString() == wid).Select(s => s["UID"].ToString()).ToList()[0];
				string[] info = {uid, issuerName};
				dc.Add(wid, info);
			}
			return dc;
		}

		static Dictionary<string, string> BrokerIDName()
		{
			Dictionary<string, string> dc = new Dictionary<string, string>();
			SqlConnection conn = new SqlConnection("Data Source=10.19.1.45;Initial Catalog=testEDIS;User ID=sa;Password=dw910770");
			string sqlstr = "Select * from [testEDIS].[dbo].[BrokerNameID]";
			DataTable brokerIDName = MSSQL.ExecSqlQry(sqlstr, conn);
			foreach (DataRow row in brokerIDName.Rows)
				dc.Add(row["BrokerID"].ToString(), row["BrokerName"].ToString());
			return dc;
		}

		static void Main(string[] args)
		{
			DataTable brokerInfo = InitialNextDayShortTable();

			Dictionary<string, string> brokerDc = BrokerIDName();

			SqlConnection newEDIS45 = new SqlConnection("Data Source=10.19.1.45;Initial Catalog=newEDIS;User ID=sa;Password=dw910770");

			SqlConnection newEDIS37 = new SqlConnection("Data Source=10.60.0.37;Initial Catalog=newEDIS;User ID=WarrantWeb;Password=WarrantWeb");

			string date = TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");

			//抓出自營跟造市交易
			DataTable propTrade = WarrantTradingBroker(newEDIS45, date);

			string sqlstr = " SELECT convert(varchar, TDate, 112) as TDate, UID, WID, WName, IssuerName, BrokerID, BrokerName, BuyingLots, SellingLots, AvgBuyPrice, AvgSellPrice FROM[newEDIS].[dbo].[BrokerHoldingDays] " +
									 " where TDate in (select top(20) TradeDate from [10.60.0.37].[TsQuote].[dbo].[TradeDate] " +
									 $" where IsTrade = 'Y' and TradeDate <= '{date}' order by TradeDate desc) ";
			
			//前20日交易紀錄
			DataTable wTable = MSSQL.ExecSqlQry(sqlstr, newEDIS45);
			//前1日交易
			DataTable wTable_lastday = wTable.AsEnumerable().Where(r => r["TDate"].ToString() == date).CopyToDataTable();

			//交易日期
			List<string> tradeDate = wTable.AsEnumerable().Select(r => r["TDate"].ToString()).Distinct().OrderBy(s => s).ToList();
			//權證代碼List
			List<string> widList = WidList(newEDIS45, date); //wTable.AsEnumerable().Select(r => r["WID"].ToString()).Distinct().ToArray();
			//分點代碼List
			List<string> brokerIDList = BrokerIDList(newEDIS45, date); //wTable.AsEnumerable().Select(r => r["BrokerID"].ToString()).Distinct().ToArray();
			
			//權證的標的與發行商
			Dictionary<string, string[]> wInfo = WidInfo(newEDIS45, date);
			Console.WriteLine("wInfo");

			Parallel.ForEach(brokerIDList, brokerID =>
			{
				Console.WriteLine(brokerID);
				double nextDayShortRatio = -1;
				double nextDayShortAmount = 0;
				double yBuyingAmount = 0;
				//挑出該分點的交易
				DataRow[] wTable_broker = wTable.AsEnumerable().Where(r => r["BrokerID"].ToString() == brokerID).ToArray();
				//計算賣出金額
				double shortAmount = wTable_broker.AsEnumerable().Sum(r => double.Parse(r["SellingLots"].ToString()) * double.Parse(r["AvgSellPrice"].ToString()));
				foreach (string wid in widList)
				{
					//該分點過去交易該權證的資訊
					DataRow[] wTable_brokerIdWid = wTable_broker.AsEnumerable().Where(r => r["WID"].ToString() == wid).ToArray();
					//該分點過去交易該權證的資訊且買張 > 0
					DataRow[] wTable_buy = wTable_brokerIdWid.AsEnumerable().Where(r => r["BuyingLots"].ToString() != "0" && r["TDate"].ToString() != date).ToArray();
					//計算昨日買金額與今日賣金額
					if (wTable_buy.Count() > 0)
					{
						foreach (DataRow row in wTable_buy)
						{
							string nextDay = tradeDate[tradeDate.IndexOf(row["TDate"].ToString()) + 1];
							DataRow[] nextDayTrade = wTable_brokerIdWid.AsEnumerable().Where(r => r["TDate"].ToString() == nextDay).ToArray();
							if (nextDayTrade.Count() > 0)
							{
								if (nextDayTrade[0]["SellingLots"].ToString() != "0")
								{
									double avgPrice = (double.Parse(nextDayTrade[0]["AvgSellPrice"].ToString()) + double.Parse(row["AvgBuyPrice"].ToString())) / 2;
									yBuyingAmount += double.Parse(row["BuyingLots"].ToString()) * avgPrice;
									nextDayShortAmount += Math.Min(double.Parse(nextDayTrade[0]["SellingLots"].ToString()), double.Parse(row["BuyingLots"].ToString())) * avgPrice;
								}
								else
								{
									yBuyingAmount += double.Parse(row["BuyingLots"].ToString()) * double.Parse(row["AvgBuyPrice"].ToString());
								}
							}
							else
							{
								yBuyingAmount += double.Parse(row["BuyingLots"].ToString()) * double.Parse(row["AvgBuyPrice"].ToString());
							}
						}
					}
				}

				//計算隔日沖比例
				if (yBuyingAmount > 0)
					nextDayShortRatio = nextDayShortAmount / yBuyingAmount;

				lock (brokerLock)
				{
					DataRow newRow = brokerInfo.NewRow();
					newRow["TDate"] = date;
					newRow["BrokerID"] = brokerID;
					newRow["ShortAmount"] = shortAmount;
					newRow["NextDayShortRatio"] = nextDayShortRatio;
					brokerInfo.Rows.Add(newRow);
				}
			});
			Utility.SaveToCSV(brokerInfo, ".\\brokerInfo.csv", true);

			//賣出量排列
			List<double> shortAmountList = brokerInfo.AsEnumerable().Select(r => double.Parse(r["ShortAmount"].ToString())).ToList().OrderByDescending(x => x).ToList();
			Dictionary<string, string> classification = Classification(brokerInfo, shortAmountList);

			foreach (string broID in classification.Keys)
			{
				string brokerID = broID;
				if (broID.Length == 5)
					brokerID = broID.Substring(0, 3) + broID.Substring(3, 1).ToLower();
				if (brokerDc.ContainsKey(broID))
				{ 
					string brokerName = brokerDc[broID];
					string cl = classification[broID];
					string sqlInsert = $"Insert BrokerClassification Values('{date}', '{broID}', '{brokerName}', '{cl}')";
					MSSQL.ExecSqlCmd(sqlInsert, newEDIS37);
				}
			}

			DataTable wTable_lastdayTrade = wTable_lastday.AsEnumerable().Where(r => r["BuyingLots"].ToString() != "0" || r["SellingLots"].ToString() != "0").CopyToDataTable();

			wTable_lastdayTrade.Columns.Add("Classification");
			wTable_lastdayTrade.Columns.Add("PropBuyingLots");
			wTable_lastdayTrade.Columns.Add("PropSellingLots");

			//分點分出自營交易張數
			foreach (DataRow row in wTable_lastdayTrade.Rows)
			{	
				row["Classification"] = classification[row["BrokerID"].ToString()];
				row["PropBuyingLots"] = 0;
				row["PropSellingLots"] = 0;
				DataRow[] temp = propTrade.AsEnumerable().Where(r => r["WID"].ToString() == row["WID"].ToString() && r["BrokerID"].ToString() == row["BrokerID"].ToString()).ToArray();
				if(temp.Count() > 0)
				{
					row["PropBuyingLots"] = int.Parse(temp[0]["PropBuyingLots"].ToString());
					row["PropSellingLots"] = int.Parse(temp[0]["PropSellingLots"].ToString());
					row["BuyingLots"] = int.Parse(row["BuyingLots"].ToString()) - int.Parse(row["PropBuyingLots"].ToString());
					row["SellingLots"] = int.Parse(row["SellingLots"].ToString()) - int.Parse(row["PropSellingLots"].ToString());
				}
			}
			Utility.SaveToCSV(wTable_lastdayTrade, ".\\result1.csv", true);
			/* 
			//string[] widlast = wTable_lastday.AsEnumerable().Select(r => r["WID"].ToString()).Distinct().ToArray();
			DataTable result = FinalTable();
			foreach(string wl in wInfo.Keys)
			{			
				DataRow[] wTable_lastday_wid = wTable_lastday.AsEnumerable().Where(r => r["WID"].ToString() == wl).ToArray();
				double goodLots = wTable_lastday_wid.AsEnumerable().Where(r => r["Classification"].ToString() == "Good").Sum(s => double.Parse(s["BuyingLots"].ToString()));
				double badLots = wTable_lastday_wid.AsEnumerable().Where(r => r["Classification"].ToString() == "Bad").Sum(s => double.Parse(s["BuyingLots"].ToString()));
				DataRow newRow = result.NewRow();
				newRow["TDate"] = date;
				newRow["WID"] = wl;
				newRow["UID"] = wInfo[wl][0];
				newRow["IssuerName"] = wInfo[wl][1];
				newRow["Good"] = goodLots;
				newRow["Bad"] = badLots;
				result.Rows.Add(newRow);
			}
			Utility.SaveToCSV(result, ".\\result.csv", true);
			*/
#if !DEBUG
			foreach (DataRow row in wTable_lastdayTrade.Rows)
			{
				string sqlInsert = $"Insert BrokerLots Values('{row[0].ToString()}', '{row[1].ToString()}', '{row[2].ToString()}', '{row[3].ToString()}', '{row[4].ToString()}', '{row[5].ToString()}', '{row[6].ToString()}', '{row[7].ToString()}', '{row[8].ToString()}', '{row[9].ToString()}', '{row[10].ToString()}', '{row[11].ToString()}', '{row[12].ToString()}', '{row[13].ToString()}')";
				MSSQL.ExecSqlCmd(sqlInsert, newEDIS37);
			}
#endif
		}
	}
}
