﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EDLib;
using EDLib.SQL;
using EDLib.Pricing.Option;
using EDLib.Pricing;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms.DataVisualization.Charting;

namespace MarketExtremeRisk
{
	class Program
	{
		static double targetShare = 0.145;
		//標的分類資料
		static Dictionary<string, string> UClass (string date)
		{
			Dictionary<string, string> uMarketRank = new Dictionary<string, string>();
			SqlConnection specialUnderlying = new SqlConnection("Data Source = 10.10.1.30; Initial Catalog = EDIS; User ID = WarrantWeb; Password = WarrantWeb");
			string sqlstr = "SELECT  distinct [UID], case [Type] when 'B' then 'HighRisk' when 'KY' then 'HighRisk' when 'R' then 'HighRisk' else 'M' end as Class FROM[EDIS].[dbo].[SpecialStock] " +
				$" where DataDate = (Select MAX(DataDate) from [EDIS].[dbo].[SpecialStock] where DataDate <= '{date}')";
			DataTable uTable = MSSQL.ExecSqlQry(sqlstr, specialUnderlying);
			foreach (string uid in uTable.AsEnumerable().Select(s => s["UID"].ToString()).Distinct().ToList())
			{
				DataRow[] uTemp = uTable.AsEnumerable().Where(r => r["UID"].ToString() == uid).ToArray();
				if (uTemp.Count() == 1)
					uMarketRank.Add(uid, uTemp[0]["Class"].ToString());
				else
					uMarketRank.Add(uid, "HighRisk");
				//int rank = uTable.AsEnumerable().Where(r => double.Parse(r["MarketValue"].ToString()) >= double.Parse(row["MarketValue"].ToString()) && r["UID"].ToString().Substring(0,2) != "TW" && r["UID"].ToString().Substring(0, 2) != "00").Count();
				//Console.WriteLine(double.Parse(row["MarketValue"].ToString()));
				//Console.WriteLine(row["UID"].ToString().Substring(0, 2));
				//Console.WriteLine(row["UID"].ToString());
				//Console.WriteLine(rank);
				//uMarketRank.Add(row["UID"].ToString(), row["Class"].ToString());			
			}
			return uMarketRank;
		}

		public static DataTable SQLquery(string sqlqry, SqlConnection conn)
		{
			DataTable wTable;
			wTable = new DataTable();
			SqlCommand cmd = new SqlCommand(sqlqry, conn)
			{
				CommandTimeout = 300
			};
			SqlDataAdapter da = new SqlDataAdapter(cmd);
			da.Fill(wTable);
			return wTable;
		}

		//股價
		static Dictionary<string, double> UClosePrice (string date)
		{
			Dictionary<string, double> uClose = new Dictionary<string, double>();
			SqlConnection posi37 = new SqlConnection("Data Source = 10.60.0.37; Initial Catalog = newEDIS; User ID = WarrantWeb; Password = WarrantWeb");
			string sqlstr = " SELECT distinct B.UID, (A.Spot - A.OffSet) as Price " +
								" FROM[PositionReport].[dbo].[BidVol] as A " +
								" inner join[10.19.1.45].[newEDIS].[dbo].[WarrantBasics] as B " +
                                " on A.CommodityId = B.WID and  A.CommodityNm = B.WName " +
                                $" where A.TradeDate = '{date}' and B.LastTradingDate > '{date}' and B.ListedDate <='{date}'";
			DataTable uCloseTable = MSSQL.ExecSqlQry(sqlstr, posi37);
			foreach (DataRow row in uCloseTable.Rows)
				uClose.Add(row["UID"].ToString(), double.Parse(row["Price"].ToString()));		
			return uClose;
		}

		//歷史波動率
		static Dictionary<string, double> HVol(string date)
		{
			Dictionary<string, double> hVol = new Dictionary<string, double>();
			SqlConnection volMana = new SqlConnection("Data Source = 10.101.10.5; Initial Catalog = WMM3; User ID = hedgeuser; Password = hedgeuser");
			string sqlstr = $"SELECT [WID],[TH_Vol] FROM [WMM3].[dbo].[VolManagerDetail] where cast(UPDATETIME as Date) = '{date}' and WID <> '' and VER = 1";
			DataTable hVolTable = MSSQL.ExecSqlQry(sqlstr, volMana);
			foreach (DataRow row in hVolTable.Rows)
				hVol.Add(row["WID"].ToString(), double.Parse(row["TH_Vol"].ToString())/100);
			return hVol;
		}
		
		//BaseLineVol若是自家抓造市，他家抓MMVol
		static Dictionary<string, double> BaseLineVol(string date)
		{
			Dictionary<string, double> bVol = new Dictionary<string, double>();
			SqlConnection volMana = new SqlConnection("Data Source = 10.60.0.37; Initial Catalog = newEDIS; User ID = WarrantWeb; Password = WarrantWeb");
			string sqlstr = " SELECT A.[WID], case B.IssuerName when '9200' then A.WBidMedianIV_FinRate else (case A.MMVolCap when 0 then A.WBidMedianIV_FinRate else A.MMVolCap end) end as BaseLineVol " +
									 " FROM[newEDIS].[dbo].[WarrantTrading] as A left join [10.19.1.45].[newEDIS].[dbo].[WarrantTrading] as B " +
									 $" on A.TDate = B.TDate and A.WID = B.WID where A.TDate = '{date}'";
			DataTable bVolTable = MSSQL.ExecSqlQry(sqlstr, volMana);
			foreach (DataRow row in bVolTable.Rows)
				bVol.Add(row["WID"].ToString(), double.Parse(row["BaseLineVol"].ToString()));
			return bVol;
		}

		//計算權證價格，此用來計算指數與TXF標的(因為要考慮股利率
		static double OptionPricing(string type, double S, double K, double t, double r, double q, double v)
		{
			double d1 = (Math.Log(S / K) + (r - q + 0.5*Math.Pow(v, 2)*t)) / (v * Math.Sqrt(t));
			double d2 = d1 - (v * Math.Sqrt(t));
			if(type == "c")
				return S *Math.Exp(-q*t)* NormDist.N(d1) - K * Math.Exp(-r * t) * NormDist.N(d2);
			else
				return K * Math.Exp(-r * t) * NormDist.N(-d2) - S * Math.Exp(-q * t) * NormDist.N(-d1);
		}

		//計算權證Delta，此用來計算指數與TXF標的(因為要考慮股利率
		static double OptionDelta(string type, double S, double K, double t, double r, double q, double v)
		{
			double d1 = (Math.Log(S / K) + (r - q + 0.5 * Math.Pow(v, 2) * t)) / (v * Math.Sqrt(t));
			if (type == "c")
				return Math.Exp(-q * t) * NormDist.N(d1);
			else
				return Math.Exp(-q * t) * (NormDist.N(d1) - 1);
		}

		static  double interestRate = 0.025;

		static void Main(string[] args)
		{
			try
			{
				SqlConnection newEDIS45 = new SqlConnection("Data Source = 10.19.1.45; Initial Catalog = newEDIS; User ID = sa; Password = dw910770");
				SqlConnection newEDIS37 = new SqlConnection("Data Source = 10.60.0.37; Initial Catalog = newEDIS; User ID = WarrantWeb; Password = WarrantWeb");

				string date = TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");
				Console.WriteLine(date);
				string sqlstr = " Select A.[TDate], A.[WID], A.[WName], A.[UID], A.[UName], " +
										" [WClass], [StrikePrice], [Moneyness], [TtoM], [CR], " +
										" [AccReleasingLotsRetail], ISNULL(B.Adj, 0) as Adj from " +
										" (SELECT TDate, WID, WName, UID, UName, IssuerName, WBidMedianIV_FinRate, " +
										" WClass, StrikePrice, Moneyness, TtoM, CR, AccReleasingLots " +
										$" AccReleasingLotsRetail FROM[newEDIS].[dbo].[WarrantTrading] where TDate = '{date}') as A " +
										$" left join(Select TDate, WID, Adj from [10.19.1.20].[EDIS].[dbo].[WarrantIV] where TDate = '{date}' and SaveTime = '13:25') as B " +
										" on A.TDate = B.TDate and A.WID = B.WID where A.WBidMedianIV_FinRate > 0  and A.UID in " +
										" (SELECT distinct D.UID FROM [10.60.0.37].[PositionReport].[dbo].[BidVol] as C " +
										" inner join[newEDIS].[dbo].[WarrantBasics] as D on C.CommodityId = D.WID and  C.CommodityNm = D.WName " +
										$" where C.TradeDate = '{date}' and D.LastTradingDate > '{date}' and D.ListedDate <= '{date}')";

				DataTable wTable = SQLquery(sqlstr, newEDIS45);
				Dictionary<string, string> uClass = UClass(date);
				Dictionary<string, double> uClose = UClosePrice(date);
				Dictionary<string, double> hVolTable = HVol(date);
				Dictionary<string, double> bVolTable = BaseLineVol(date);

				/*
				DataTable dt = new DataTable();
				dt.Columns.Add("UID");
				dt.Columns.Add("Class");
				foreach(var pair in uRank)
				{
					DataRow newRow = dt.NewRow();
					newRow["UID"] = pair.Key;
					newRow["Class"] = pair.Value;
					dt.Rows.Add(newRow);
				}
				Utility.SaveToCSV(dt, ".\\rank.csv", true);
				*/

				wTable.Columns.Add("Class", typeof(string));
				wTable.Columns.Add("UClosePrice", typeof(string));
				wTable.Columns.Add("HV", typeof(string));
				wTable.Columns.Add("BV", typeof(string));
				wTable.Columns.Add("WPrice", typeof(double));
				wTable.Columns.Add("StockPrice_Up", typeof(double));
				wTable.Columns.Add("StockPrice_Down", typeof(double));
				wTable.Columns.Add("WPrice_Up", typeof(double));
				wTable.Columns.Add("WPrice_Down", typeof(double));
				wTable.Columns.Add("Delta_HV", typeof(double));
				wTable.Columns.Add("WPnLUp", typeof(double));
				wTable.Columns.Add("HedgePnLUp", typeof(double));
				wTable.Columns.Add("WPnLDown", typeof(double));
				wTable.Columns.Add("HedgePnLDown", typeof(double));

				//先將標的分類，依據不同的分類，標的模擬的漲跌幅也有所不同，並計算權證部位損益與
				//避險部位損益，避險部位採用HedgeVol避險，且假設前一天Delta Neutral下持有多少股票
				foreach (DataRow row in wTable.Rows)
				{
					Console.WriteLine(row["UID"].ToString());
					//Console.WriteLine(row["WID"].ToString());
					row["UClosePrice"] = uClose[row["UID"].ToString()] + double.Parse(row["Adj"].ToString());
					if (uClass.ContainsKey(row["UID"].ToString()))
					{
						if (uClass[row["UID"].ToString()] == "M") 
						{
							row["Class"] = "Top30";
							row["StockPrice_Up"] = double.Parse(row["UClosePrice"].ToString()) * 1.15;
							row["StockPrice_Down"] = double.Parse(row["UClosePrice"].ToString()) * 0.8;
						}
						else
						{
							row["Class"] = "Risky";
							row["StockPrice_Up"] = double.Parse(row["UClosePrice"].ToString()) * 1.3;
							row["StockPrice_Down"] = double.Parse(row["UClosePrice"].ToString()) * 0.5;
						}
					}
					else
					{
						if (row["UID"].ToString().Substring(0, 2) == "00")
							row["Class"] = "ETF";
						else if (row["UID"].ToString().Substring(0, 2) == "TW" || row["UID"].ToString().Substring(0, 3) == "TXF")
							row["Class"] = "Index";
						else
							row["Class"] = "Others";

						if (row["UID"].ToString().Substring(row["UID"].ToString().Length - 1, 1) == "R")
						{
							row["StockPrice_Up"] = double.Parse(row["UClosePrice"].ToString()) * 0.93;
							row["StockPrice_Down"] = double.Parse(row["UClosePrice"].ToString()) * 1.1;
						}
						else if (row["UID"].ToString().Substring(row["UID"].ToString().Length - 1, 1) == "L")
						{
							row["StockPrice_Up"] = double.Parse(row["UClosePrice"].ToString()) * 1.14;
							row["StockPrice_Down"] = double.Parse(row["UClosePrice"].ToString()) * 0.8;
						}
						else if (row["UID"].ToString().Substring(0, 2) == "00" || row["UID"].ToString().Substring(0, 2) == "TW" || row["UID"].ToString().Substring(0, 3) == "TXF")
						{
							row["StockPrice_Up"] = double.Parse(row["UClosePrice"].ToString()) * 1.07;
							row["StockPrice_Down"] = double.Parse(row["UClosePrice"].ToString()) * 0.9;
						}
						else
						{
							row["StockPrice_Up"] = double.Parse(row["UClosePrice"].ToString()) * 1.3;
							row["StockPrice_Down"] = double.Parse(row["UClosePrice"].ToString()) * 0.5;
						}
					}

					double stockPrice = double.Parse(row["UClosePrice"].ToString());
					double stockPrice_Up = double.Parse(row["StockPrice_Up"].ToString());
					double stockPrice_Down = double.Parse(row["StockPrice_Down"].ToString());
					double strike = double.Parse(row["StrikePrice"].ToString());
					double t = double.Parse(row["TtoM"].ToString()) - 1;
					double cr = double.Parse(row["CR"].ToString());
					double bVol = bVolTable[row["WID"].ToString()];
					double hVol = hVolTable[row["WID"].ToString()];
					row["BV"] = bVol;
					row["HV"] = hVol;
					if (row["WClass"].ToString() == "c")
					{
						if (row["UID"].ToString().Substring(0, 2) != "TW" && row["UID"].ToString().Substring(0, 2) != "TX")
						{
							row["WPrice"] = PlainVanilla.CallPrice(stockPrice, strike, interestRate, bVol, t / 252) * cr;
							row["WPrice_Up"] = PlainVanilla.CallPrice(stockPrice_Up, strike, interestRate, bVol, t / 252) * cr;
							row["WPrice_Down"] = PlainVanilla.CallPrice(stockPrice_Down, strike, interestRate, bVol, t / 252) * cr;
							row["Delta_HV"] = PlainVanilla.CallDelta(stockPrice, strike, interestRate, hVol, t / 252) * cr;
						}
						else
						{
							row["WPrice"] = OptionPricing("c", stockPrice, strike, t / 252, interestRate, 0.025, bVol) * cr;
							row["WPrice_Up"] = OptionPricing("c", stockPrice_Up, strike, t / 252, interestRate, 0.025, bVol) * cr;
							row["WPrice_Down"] = OptionPricing("c", stockPrice_Down, strike, t / 252, interestRate, 0.025, bVol) * cr;
							row["Delta_HV"] = OptionDelta("c", stockPrice, strike, t / 252, interestRate, 0.025, hVol) * cr;
						}
					}
					else if (row["WClass"].ToString() == "p")
					{
						/*
						if (row["WID"].ToString() == "03775P")
						{
							Console.WriteLine(stockPrice);
							Console.WriteLine(strike);
							Console.WriteLine(t);
							Console.WriteLine(interestRate);
							Console.WriteLine(cr);
							Console.WriteLine(bVol);
							Console.WriteLine(t / 252);
							Console.WriteLine(PlainVanilla.PutPrice(stockPrice, strike, interestRate, bVol, t / 252) * cr);
							Console.ReadLine();
						}
						*/
						if (row["UID"].ToString().Substring(0, 2) != "TW" && row["UID"].ToString().Substring(0, 2) != "TX")
						{
							row["WPrice"] = PlainVanilla.PutPrice(stockPrice, strike, interestRate, bVol, t / 252) * cr;
							row["WPrice_Up"] = PlainVanilla.PutPrice(stockPrice_Up, strike, interestRate, bVol, t / 252) * cr;
							row["WPrice_Down"] = PlainVanilla.PutPrice(stockPrice_Down, strike, interestRate, bVol, t / 252) * cr;
							row["Delta_HV"] = PlainVanilla.PutDelta(stockPrice, strike, interestRate, hVol, t / 252) * cr;
						}
						else
						{
							row["WPrice"] = OptionPricing("p", stockPrice, strike, t / 252, interestRate, 0.025, bVol) * cr;
							row["WPrice_Up"] = OptionPricing("p", stockPrice_Up, strike, t / 252, interestRate, 0.025, bVol) * cr;
							row["WPrice_Down"] = OptionPricing("p", stockPrice_Down, strike, t / 252, interestRate, 0.025, bVol) * cr;
							row["Delta_HV"] = OptionDelta("p", stockPrice, strike, t / 252, interestRate, 0.025, hVol) * cr;
						}
					}
					else if (row["WClass"].ToString() == "puo")
					{
						row["WPrice"] = (strike - stockPrice) * cr + strike * bVol * t / 365 * cr;
						row["WPrice_Up"] = (strike - stockPrice_Up) * cr + strike * bVol * t / 365 * cr;
						row["WPrice_Down"] = (strike - stockPrice_Down) * cr + strike * bVol * t / 365 * cr;
						row["Delta_HV"] = -1 * cr;
					}
					else if (row["WClass"].ToString() == "cdo" || row["WClass"].ToString() == "xcdo")
					{
						row["WPrice"] = (stockPrice - strike) * cr + strike * bVol * t / 365 * cr;
						row["WPrice_Up"] = (stockPrice_Up - strike) * cr + strike * bVol * t / 365 * cr;
						row["WPrice_Down"] = (stockPrice_Down - strike) * cr + strike * bVol * t / 365 * cr;
						row["Delta_HV"] = 1 * cr;
					}
					row["WPnLUp"] = (double.Parse(row["WPrice_Up"].ToString()) - double.Parse(row["WPrice"].ToString())) * double.Parse(row["AccReleasingLotsRetail"].ToString());
					row["HedgePnLUp"] = -double.Parse(row["Delta_HV"].ToString()) * double.Parse(row["AccReleasingLotsRetail"].ToString()) * (double.Parse(row["StockPrice_Up"].ToString()) - double.Parse(row["UClosePrice"].ToString()));
					row["WPnLDown"] = (double.Parse(row["WPrice_Down"].ToString()) - double.Parse(row["WPrice"].ToString())) * double.Parse(row["AccReleasingLotsRetail"].ToString());
					row["HedgePnLDown"] = -double.Parse(row["Delta_HV"].ToString()) * double.Parse(row["AccReleasingLotsRetail"].ToString()) * (double.Parse(row["StockPrice_Down"].ToString()) - double.Parse(row["UClosePrice"].ToString()));
				}

				DataTable uGroup = new DataTable();
				uGroup.Columns.Add("TDate");
				uGroup.Columns.Add("UID");
				uGroup.Columns.Add("Class");
				uGroup.Columns.Add("WarrantPnLUp");
				uGroup.Columns.Add("HedgePnLUp");
				uGroup.Columns.Add("WarrantPnLDown");
				uGroup.Columns.Add("HedgePnLDown");
				//將wTable裡的資料，依標的做group by
				foreach (string uid in wTable.AsEnumerable().Select(r => r["UID"].ToString()).Distinct().ToList())
				{
					DataTable temp = wTable.AsEnumerable().Where(r => r["UID"].ToString() == uid).CopyToDataTable();
					DataRow newRow = uGroup.NewRow();
					newRow["TDate"] = date;
					newRow["UID"] = uid;
					newRow["Class"] = temp.AsEnumerable().Select(r => r["Class"].ToString()).ToList()[0];
					newRow["WarrantPnLUp"] = temp.AsEnumerable().Sum(r => double.Parse(r["WPnLUp"].ToString()));
					newRow["HedgePnLUp"] = temp.AsEnumerable().Sum(r => double.Parse(r["HedgePnLUp"].ToString()));
					newRow["WarrantPnLDown"] = temp.AsEnumerable().Sum(r => double.Parse(r["WPnLDown"].ToString()));
					newRow["HedgePnLDown"] = temp.AsEnumerable().Sum(r => double.Parse(r["HedgePnLDown"].ToString()));
					uGroup.Rows.Add(newRow);
				}
				Utility.SaveToCSV(wTable, ".\\wTable.csv", true);
				Utility.SaveToCSV(uGroup, ".\\uGroup.csv", true);
#if !DEBUG
				foreach (DataRow row in uGroup.Rows)
				{
					double criteria;
					double totalPnL = Math.Min(double.Parse(row["WarrantPnLUp"].ToString()) + double.Parse(row["HedgePnLUp"].ToString()), double.Parse(row["WarrantPnLDown"].ToString()) + double.Parse(row["HedgePnLDown"].ToString()));
					if (row["Class"].ToString() == "Index" || row["Class"].ToString() == "ETF")
						criteria = Math.Min(60000, Math.Max(Math.Abs(totalPnL) * targetShare, 60000));
					else if (row["Class"].ToString() == "Top30")
						criteria = Math.Min(50000, Math.Max(Math.Abs(totalPnL) * targetShare, 40000));
					else
						criteria = Math.Min(50000, Math.Max(Math.Abs(totalPnL) * targetShare, 20000));
					string sqlInsert = $"Insert MarketExtremePnL Values('{row["TDate"].ToString()}', '{row["UID"].ToString()}', '{row["Class"].ToString()}', '{row["WarrantPnLUp"].ToString()}', '{row["HedgePnLUp"].ToString()}', '{double.Parse(row["WarrantPnLUp"].ToString()) + double.Parse(row["HedgePnLUp"].ToString())}', '{row["WarrantPnLDown"].ToString()}', '{row["HedgePnLDown"].ToString()}', '{double.Parse(row["WarrantPnLDown"].ToString()) + double.Parse(row["HedgePnLDown"].ToString())}', '{criteria}')";
					MSSQL.ExecSqlCmd(sqlInsert, newEDIS37);
				}
#endif
			}
			catch(Exception e)
			{
				MailService ms = new MailService();
				ms.SendMail("jerry.zeng@kgi.com", "10.60.0.37 ERROR", new string[] { "jerry.zeng@kgi.com" }, null, null, "MarketExtremePnL ERROR!", e.ToString(), false, null);
			}
		}
	}
}
