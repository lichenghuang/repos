﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EDLib.Pricing.Option;
using EDLib.SQL;
using EDLib;
using System.Data.SqlClient;
using System.Data;

namespace MMVol
{
	class Program
	{
		//權證價格
		static double OptionPrice(string type, double S, double K, double T, double v, double CR)
		{
			double price = 0;
			T = T / (double)252;
			if (type == "c")
			{
				price = PlainVanilla.CallPrice(S, K, 0.025, v, T) * CR;
			}
			else if (type == "p")
			{
				price = PlainVanilla.PutPrice(S, K, 0.025, v, T) * CR;
			}
			return price;
		}

		//跳動價差
		static double Jumpsize(double p)
		{
			if (p < 5)
				return (0.01);
			else if (p < 10)
				return (0.05);
			else if (p < 50)
				return (0.1);
			else if (p < 100)
				return (0.5);
			else if (p < 500)
				return (1);
			else
				return (5);
		}

		//理論價調整
		static double PriceAdj(double Price)
		{
			double price;
			price = Math.Round(Price / Jumpsize(Price), MidpointRounding.AwayFromZero) * Jumpsize(Price);
			return price;
		}

		static void Main(string[] args)
		{
			SqlConnection conn = new SqlConnection("Data Source= 10.19.1.45;Initial Catalog=newEDIS;User=sa;Password=dw910770");
			SqlConnection conn20 = new SqlConnection("Data Source= 10.19.1.20;Initial Catalog=EDIS;User=WarrantWeb;Password=WarrantWeb");
			SqlConnection conn37 = new SqlConnection("Data Source= 10.60.0.37;Initial Catalog=newEDIS;User=WarrantWeb;Password=WarrantWeb");
			string date = TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");

			string sqlIndexQuery = $"SELECT [TDate], [WID], [UID], ([UBidPrice]+[UAskPrice])/2 + Adj as ClosePrice FROM WarrantIV where TDate = '{date}' and SaveTime = '13:25'";
			string sqlqry = $"SELECT convert(varchar,[TDate],112) as TDate, [WID], WClass, [UID], IssuerName, StrikePrice, CR, WBidMedianIV_FinRate, TtoM FROM WarrantTrading where TDate = '{date}'";
			DataTable uTable = MSSQL.ExecSqlQry(sqlIndexQuery, conn20);
			DataTable wTable = MSSQL.ExecSqlQry(sqlqry, conn);

			wTable.Columns.Add("MarketVol");

			foreach (DataRow row in wTable.Rows)
			{
				string type = row["WClass"].ToString();
				if (row["IssuerName"].ToString() != "9200")
				{
                    //非凱基發行的權證(用資訊部算的Implied Vol)
                    row["MarketVol"] = row["WBidMedianIV_FinRate"];
				}
				else
				{
                    //凱基發行的權證
                    DataRow[] utemp = uTable.AsEnumerable().Where(r => r["UID"].ToString() == row["UID"].ToString()).ToArray();
					if (utemp.Count() > 0 && (type == "c" || type == "p"))
					{
						double stockPrice = double.Parse(utemp[0]["ClosePrice"].ToString());
						double strikePrice = double.Parse(row["StrikePrice"].ToString());
						double vol = double.Parse(row["WBidMedianIV_FinRate"].ToString());
						double t = double.Parse(row["TtoM"].ToString());
						double cR = double.Parse(row["CR"].ToString());
						double optionPrice = PriceAdj(OptionPrice(type, stockPrice, strikePrice, t, vol, cR));
						if (type == "c")
						{
							double iV = PlainVanilla.CallIVNewton(stockPrice, strikePrice, 0.025, t / 252, optionPrice / cR);
							if (iV <= 0)
								row["MarketVol"] = row["WBidMedianIV_FinRate"];
							else
								row["MarketVol"] = iV;
						}
						else
						{
							double iV = PlainVanilla.PutIVNewton(stockPrice, strikePrice, 0.025, t / 252, optionPrice / cR);
							if (iV <= 0)
								row["MarketVol"] = row["WBidMedianIV_FinRate"];
							else
								row["MarketVol"] = iV;
						}
					}
					else
					{
						row["MarketVol"] = row["WBidMedianIV_FinRate"];
					}
				}
			}
			Utility.SaveToCSV(wTable, ".\\wTable.csv", true);
#if !DEBUG
			foreach (DataRow row in wTable.Rows)
			{
				Console.WriteLine(row[0].ToString());
				string sqlInsert = $"Insert MarketMakerVol Values('{row[0].ToString()}', '{row[1].ToString()}', '{row[2].ToString()}', '{row[3].ToString()}', '{row[4].ToString()}', '{row[7].ToString()}', '{row[9].ToString()}')";
				MSSQL.ExecSqlCmd(sqlInsert, conn37);
			}
#endif
		}
	}
}
