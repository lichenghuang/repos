﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EDLib;
using EDLib.SQL;
using EDLib.Pricing.Option;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;

namespace BrokerDailyPnL
{
	class Program
	{
		static string date;

		//權證基本資料
		static Dictionary<string, string[]> WidIssuerName(DataTable warrantTrading)
		{
			Dictionary<string, string[]> widIssuerName = new Dictionary<string, string[]>();
			
			foreach(DataRow row in warrantTrading.Rows)
			{
				string[] list = {row["IssuerName"].ToString(), row["StrikePrice"].ToString(), row["TtoM"].ToString(), row["MMVol"].ToString(), row["WBidMedianIV_FinRate"].ToString(), row["CR"].ToString(), row["BarrierPrice"].ToString(), row["Delta_IV"].ToString() };
				widIssuerName.Add(row["WID"].ToString(), list);
			}
			return widIssuerName;
		}
		//權證價格
		static double OptionPrice(string type, double S, double K, double T, double v, double CR, double barrier)
		{
			double price = 0;
			T = T / (double)252;
			if (type == "c")
			{
				price = PlainVanilla.CallPrice(S, K, 0.025, v, T) * CR;
			}
			else if(type == "p")
			{
				price = PlainVanilla.PutPrice(S, K, 0.025, v, T) * CR;
			}
			return price;
		}
		//跳動價差
		static double Jumpsize(double p)
		{
			if (p < 5)
				return (0.01);
			else if (p < 10)
				return (0.05);
			else if (p < 50)
				return (0.1);
			else if (p < 100)
				return (0.5);
			else if (p < 500)
				return (1);
			else
				return (5);
		}
		//理論價調整
		static double PriceAdj(double Price)
		{
			double price;
			price = Math.Round(Price / Jumpsize(Price), MidpointRounding.AwayFromZero) * Jumpsize(Price);
			return price;
		}

		public static DataTable WTable(string sqlqry, SqlConnection conn)
		{
			DataTable wTable;
			wTable = new DataTable();
			SqlCommand cmd = new SqlCommand(sqlqry, conn);
			cmd.CommandTimeout = 300;
			SqlDataAdapter da = new SqlDataAdapter(cmd);
			da.Fill(wTable);
			return wTable;	
		}

		public static string ParseDate(string date)
		{
			string[] dateSplit = date.Split(' ')[0].TrimEnd(' ').Split('/');
			return dateSplit[0] + int.Parse(dateSplit[1]).ToString("D2") + int.Parse(dateSplit[2]).ToString("D2");
		}

		static void Main(string[] args)
		{
			try
			{
				SqlConnection conn = new SqlConnection("Data Source= 10.19.1.45;Initial Catalog=newEDIS;User=sa;Password=dw910770");
				SqlConnection conn20 = new SqlConnection("Data Source= 10.19.1.20;Initial Catalog=EDIS;User=WarrantWeb;Password=WarrantWeb");
				conn.Open();
				conn20.Open();

				date = TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");//"20181217";//
				Console.WriteLine(date);
				//撈WarrantTradingBroker資料
				string sqlqry = "Select ISNULL(A.TDate, B.TDate) as TDate, ISNULL(A.WID, B.WID) as WID, ISNULL(A.BrokerName, B.BrokerName) as BrokerName, "
						+ " ISNULL(A.BrokerID, B.BrokerID) as BrokerID, ISNULL(AvgBuyPrice, 0) as AvgBuyPrice, ISNULL(AvgSellPrice, 0) as AvgSellPrice, "
						+ " ISNULL(BuyingLots, 0) as BuyingLots, ISNULL(SellingLots, 0) as SellingLots from "
						+ " (SELECT cast(TDate as Date) as TDate ,[WID], [BrokerBuy] as BrokerName,[BrokerBuyID] as BrokerID, SUM(LastPx * LastQty) / SUM(LastQty) as AvgBuyPrice, "
						+ $" SUM(LastQty) as BuyingLots FROM[newEDIS].[dbo].[WarrantTradingBroker]where BrokerBuyFlag <> 'MM' and cast(TDate as Date) = '{date}' and LastQty <> 0"
						+ " group by cast(TDate as Date), WID, BrokerBuy, BrokerBuyID) as A full join(SELECT cast(TDate as Date) as TDate ,[WID] ,[BrokerSell] as BrokerName, "
						+ " [BrokerSellID] as BrokerID, SUM(LastPx* LastQty) / SUM(LastQty) as AvgSellPrice,SUM(LastQty) as SellingLots FROM[newEDIS].[dbo].[WarrantTradingBroker] "
						+ $" where BrokerSellFlag<> 'MM' and cast(TDate as Date) = '{date}' and LastQty <> 0 group by cast(TDate as Date), WID, BrokerSell, BrokerSellID) as B "
						+ " on A.TDate = B.TDate and A.WID = B.WID and A.BrokerName = B.BrokerName and A.BrokerID = B.BrokerID";

				//撈標的收盤價
				string cmQuery = $"SELECT 日期 as TDate, 代號 as WID, 標的代號 as UID, 標的名稱 as UName, 標的收盤價 as UClosePrice "
						+ $"from 權證評估表 where 日期 = '{date}'";

				//標的為指數的權證採用期貨評價，因此撈10.19.1.20的資料
				string sqlIndexQuery = $"SELECT distinct [TDate],[UID], ([UBidPrice]+[UAskPrice])/2 + Adj as ClosePrice FROM WarrantIV where TDate = '{date}' and SaveTime = '13:25' and UID Like 'TW%%%'";

				//加入標的收盤價欄位
				DataTable uTable = CMoney.ExecCMoneyQry(cmQuery);
				DataTable uIndexTable = MSSQL.ExecSqlQry(sqlIndexQuery, conn20);
				foreach (DataRow row in uTable.Rows)
				{
					if (row["UID"].ToString() == "TWA00" || row["UID"].ToString() == "TWB23" || row["UID"].ToString() == "TWB28")
					{
						row["UClosePrice"] = uIndexTable.AsEnumerable().Where(r => r["UID"].ToString() == row["UID"].ToString()).Select(s => s["ClosePrice"]).ToList()[0];
					}
				}

				DataTable wTable = WTable(sqlqry, conn);
				DataTable wTableCopy = wTable.Clone();
				wTableCopy.Columns[0].DataType = typeof(string);
				foreach (DataRow row in wTable.Rows)
				{
					wTableCopy.ImportRow(row);
				}
				foreach (DataRow row in wTableCopy.Rows)
				{
					row[0] = ParseDate(row[0].ToString());
					row[1] = row[1].ToString().Substring(0, 6);
				}
				wTable = wTableCopy.Copy();

				Utility.SaveToCSV(wTable, ".\\w.csv", true);

				Utility.SaveToCSV(uTable, ".\\u.csv", true);

				wTable.Columns.Add("UID");
				wTable.Columns.Add("UName");
				wTable.Columns.Add("UClosePrice");
				foreach (DataRow row in wTable.Rows)
				{
					int index = uTable.Rows.IndexOf(uTable.Select($"TDate = '{row["TDate"].ToString()}' AND WID = '{row["WID"].ToString()}'")[0]);
					row["UID"] = uTable.Rows[index]["UID"];
					row["UName"] = uTable.Rows[index]["UName"];
					row["UClosePrice"] = uTable.Rows[index]["UClosePrice"];
				}

				//撈權證基本資料
				DataTable warrantTrading = MSSQL.ExecSqlQry($"Select TDate, WID, WClass, IssuerName, StrikePrice, TtoM, WBidMedianIV_FinRate, MMVol, CR, BarrierPrice, Delta_IV from WarrantTrading where TDate = '{date}'", conn);

				Dictionary<string, string[]> widIssuerName = WidIssuerName(warrantTrading);

				DataTable wTableClean = wTable.Clone();

				wTableClean.Columns.Add("IssuerName");
				wTableClean.Columns.Add("WClosePrice");
				wTableClean.Columns.Add("LongPnL");
				wTableClean.Columns.Add("ShortPnL");
				wTableClean.Columns.Add("Delta_IV");

				//計算權證收盤價
				foreach (DataRow row in wTable.Rows)
				{
					if (widIssuerName.ContainsKey(row["WID"].ToString()) && row["BrokerID"].ToString() != "" && row["UClosePrice"].ToString() != "" && row["WID"].ToString().Substring(5, 1) != "X" && row["WID"].ToString().Substring(5, 1) != "C" && row["WID"].ToString().Substring(5, 1) != "B" && (row["BuyingLots"].ToString() != "0" || row["SellingLots"].ToString() != "0"))
					{
						double vol;
						string wClass;
						if (widIssuerName[row["WID"].ToString()][3].ToString() == "0")
							vol = double.Parse(widIssuerName[row["WID"].ToString()][4]);
						else
							vol = double.Parse(widIssuerName[row["WID"].ToString()][3]);
						if (vol == 0)
							continue;
						if (row["WID"].ToString().Substring(5, 1) == "P")
							wClass = "p";
						else
							wClass = "c";
						double S = double.Parse(row["UClosePrice"].ToString());
						double K = double.Parse(widIssuerName[row["WID"].ToString()][1]);
						double T = double.Parse(widIssuerName[row["WID"].ToString()][2]);
						double H = double.Parse(widIssuerName[row["WID"].ToString()][6]);
						double Cr = double.Parse(widIssuerName[row["WID"].ToString()][5]);
						double wClosePrice = OptionPrice(wClass, S, K, T, vol, Cr, H);

						//Console.WriteLine(row["WID"]);
						//Console.WriteLine(row["BrokerID"]);
						//Console.WriteLine(row["BrokerID"].ToString());
						//Console.WriteLine(row["BrokerID"].ToString().Length);
						DataRow newRow = wTableClean.NewRow();
						newRow["TDate"] = row["TDate"].ToString();
						newRow["WID"] = row["WID"].ToString();
						newRow["UID"] = row["UID"].ToString();
						newRow["UName"] = row["UName"].ToString();
						newRow["UClosePrice"] = row["UClosePrice"].ToString();
						newRow["BrokerID"] = row["BrokerID"].ToString();
						newRow["BrokerName"] = row["BrokerName"].ToString();
						newRow["BuyingLots"] = row["BuyingLots"].ToString();
						newRow["SellingLots"] = row["SellingLots"].ToString();
						newRow["AvgBuyPrice"] = row["AvgBuyPrice"].ToString();
						newRow["AvgSellPrice"] = row["AvgSellPrice"].ToString();
						newRow["IssuerName"] = widIssuerName[row["WID"].ToString()][0].ToString();
						newRow["WClosePrice"] = PriceAdj(wClosePrice).ToString();
						//Console.WriteLine((wClosePrice - double.Parse(row["AvgBuyPrice"].ToString())) * double.Parse(row["BuyingLots"].ToString()));
						newRow["LongPnL"] = (PriceAdj(wClosePrice) - double.Parse(row["AvgBuyPrice"].ToString())) * double.Parse(row["BuyingLots"].ToString());
						newRow["ShortPnL"] = -(PriceAdj(wClosePrice) - double.Parse(row["AvgSellPrice"].ToString())) * double.Parse(row["SellingLots"].ToString());
						newRow["Delta_IV"] = widIssuerName[row["WID"].ToString()][7].ToString();
						wTableClean.Rows.Add(newRow);
					}
				}

#if !DEBUG
				foreach (DataRow row in wTableClean.Rows)
				{
					string sqlInsert = $"Insert BrokerPnL Values( '{row["TDate"]}', '{row["WID"]}', '{row["UID"]}', '{row["UName"]}', '{row["UClosePrice"]}', " +
						$"'{row["BrokerID"]}', '{row["BrokerName"]}', '{row["BuyingLots"]}', '{row["SellingLots"]}', '{row["AvgBuyPrice"]}', '{row["AvgSellPrice"]}', '{row["IssuerName"]}', '{row["WClosePrice"]}', '{double.Parse(row["Delta_IV"].ToString()).ToString("N6")}')";
					MSSQL.ExecSqlCmd(sqlInsert, conn);
				}
#endif
				Utility.SaveToCSV(wTableClean, ".\\test1.csv", true);
				conn.Close();
			}
			catch (Exception e)
			{
				MailService ms = new MailService();
				ms.SendMail("jerry.zeng@kgi.com", "10.19.1.45", new string[] { "jerry.zeng@kgi.com" }, null, null, "BrokerPnL Fail", e.Message, false, null);
				//Console.ReadLine();
			}
		}
	}
}
