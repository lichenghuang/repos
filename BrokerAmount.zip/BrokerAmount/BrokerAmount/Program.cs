﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using EDLib;
using EDLib.SQL;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace BrokerAmount
{
	class Program
	{
		static string startDate = "20180502";

		static DataTable InitializeTable()
		{
			DataTable summary = new DataTable();
			summary.Columns.Add("TDate");
			summary.Columns.Add("WID");
			summary.Columns.Add("WName");
			summary.Columns.Add("UID");
			summary.Columns.Add("IssuerName");
			summary.Columns.Add("ListedDate");
			summary.Columns.Add("MaturityDate");
			summary.Columns.Add("BrokerID");
			summary.Columns.Add("BrokerName");
			summary.Columns.Add("BuyingLots");
			summary.Columns.Add("SellingLots");
			summary.Columns.Add("AvgBuyPrice");
			summary.Columns.Add("AvgSellPrice");
			summary.Columns.Add("AccLots");
			summary.Columns.Add("RestHoldingLots");
			summary.Columns.Add("BuyHoldingDays");
			summary.Columns.Add("HoldingDays");
			summary.Columns.Add("SoldWeightedDays");
			return summary;
		}

		static Dictionary<string, string[]> GetIssuerNameUID(DataTable warrantBasics)
		{
			Dictionary<string, string[]> dc = new Dictionary<string, string[]>();
			foreach (DataRow row in warrantBasics.Rows)
			{
				string s1 = row["WID"].ToString() + row["ListedDate"].ToString();
				string[] s2 = {row["UID"].ToString(), row["IssuerName"].ToString()};
				dc.Add(s1, s2);
			}
			return dc;
		}

		//計算有幾天
		static int NumTradingDays(DataTable tradeDate, string startDate, string endDate)
		{
			int startDateIndex = tradeDate.AsEnumerable().Where(r => r["TradeDate"].ToString() == startDate).Select(s => int.Parse(s["DateOrder"].ToString())).ToList()[0];
			int endDateIndex = tradeDate.AsEnumerable().Where(r => r["TradeDate"].ToString() == endDate).Select(s => int.Parse(s["DateOrder"].ToString())).ToList()[0];
			//Console.WriteLine(startDateIndex);
			//Console.WriteLine(endDateIndex);
			int numTradingDays = endDateIndex - startDateIndex;
			return numTradingDays;
		}

		static DataTable LotsReset(DataTable summary, DataTable summary_1, DataTable wTable, DataTable tradeDate, string date)
		{			
			DataTable result = InitializeTable();
			DateTime d = DateTime.ParseExact(date, "yyyyMMdd", null, System.Globalization.DateTimeStyles.None);
			
			//非起始統計日(表示summary_1的列數是不是0)
			if (summary_1.Rows.Count != 0)
			{
				//挑出權證代碼
				List<string> existWID_1 = summary_1.AsEnumerable().Select(s => s["WID"].ToString()).Distinct().ToList();
				foreach (string wid in existWID_1)
				{
					//挑出上個交易日被交易的權證代碼
					DataRow[] tempwid_1 = summary_1.AsEnumerable().Where(r => r["WID"].ToString() == wid).ToArray();
					//上個交易日交易該權證的分點代碼
					List<string> brokerIDList = tempwid_1.AsEnumerable().Select(s => s["BrokerID"].ToString()).Distinct().ToList();
					//先前交易過該權證的紀錄
					DataRow[] s_tempwid = summary.AsEnumerable().Where(s => s["WID"].ToString() == wid).ToArray();
					//今天交易該權證的紀錄
					DataRow[] w_tableIWD = wTable.AsEnumerable().Where(r => r["WID"].ToString() == wid).ToArray();
					foreach (string brokerID in brokerIDList)
					{
						//該分點交易該權證的過去紀錄(存成s_temp)
						DataTable s_temp = summary.Clone();
						DataRow[] s_tempEn = s_tempwid.OrderBy(r=> DateTime.ParseExact(r["TDate"].ToString(), "yyyyMMdd", null, System.Globalization.DateTimeStyles.None)).Where(s => s["BrokerID"].ToString() == brokerID).ToArray();
						foreach (DataRow row in s_tempEn)
							s_temp.ImportRow(row);

						//s_temp_1為上個交易日該分點交易該權證
						DataRow s_temp_1 = tempwid_1.AsEnumerable().Where(s => s["BrokerID"].ToString() == brokerID).ToList()[0];

						//w_temp為該分點今日有交易該權證的資訊(若有交易，則長度為1，反之為0)
						DataRow[] w_temp = w_tableIWD.Where(r => r["BrokerID"].ToString() == brokerID).ToArray();
						
						//透過以上三個變數計算分點持有天期
						var wUpdate = CalculateHoldingLotsAndHoldingDays(s_temp, s_temp_1, w_temp, tradeDate, date);
						//更新過去買持有天期
						DataTable widBroID = wUpdate.Item1;
						int holdingLots = wUpdate.Item2;
						double holdingDays = wUpdate.Item3;
						//今日賣持有天期(HoldingDays)
						if (w_temp.Count() == 0 && s_temp_1["AccLots"].ToString() != "0") //表示過去有交易，今天沒有
						{
							DataRow newRow = result.NewRow();
							newRow["TDate"] = date;
							newRow["WID"] = s_temp_1["WID"].ToString();
							newRow["WName"] = s_temp_1["WName"].ToString();
							newRow["UID"] = s_temp_1["UID"].ToString();
							newRow["IssuerName"] = s_temp_1["IssuerName"].ToString();
							newRow["ListedDate"] = s_temp_1["ListedDate"].ToString();
							newRow["MaturityDate"] = s_temp_1["MaturityDate"].ToString();
							newRow["BrokerID"] = s_temp_1["BrokerID"].ToString();
							newRow["BrokerName"] = s_temp_1["BrokerName"].ToString();
							newRow["BuyingLots"] = "0";
							newRow["SellingLots"] = "0";
							newRow["AvgBuyPrice"] = "0";
							newRow["AvgSellPrice"] = "0";
							newRow["AccLots"] = s_temp_1["AccLots"].ToString();
							newRow["RestHoldingLots"] = holdingLots.ToString();
							newRow["BuyHoldingDays"] = "0";
							newRow["HoldingDays"] = holdingDays.ToString();
							newRow["SoldWeightedDays"] = "0";
							result.Rows.Add(newRow);
						}
						else if(w_temp.Count() > 0) //表示過去有交易，今天也有
						{
							DataRow w_tempRow = w_temp.AsEnumerable().ToList()[0];
							DataRow newRow = result.NewRow();
							newRow["TDate"] = date;
							newRow["WID"] = s_temp_1["WID"].ToString();
							newRow["WName"] = s_temp_1["WName"].ToString();
							newRow["UID"] = s_temp_1["UID"].ToString();
							newRow["IssuerName"] = s_temp_1["IssuerName"].ToString();
							newRow["ListedDate"] = s_temp_1["ListedDate"].ToString();
							newRow["MaturityDate"] = s_temp_1["MaturityDate"].ToString();
							newRow["BrokerID"] = s_temp_1["BrokerID"].ToString();
							newRow["BrokerName"] = s_temp_1["BrokerName"].ToString();							
							newRow["BuyingLots"] = w_tempRow["BuyingLots"].ToString();
							newRow["SellingLots"] = w_tempRow["SellingLots"].ToString();
							newRow["AvgBuyPrice"] = w_tempRow["AvgBuyPrice"].ToString();
							newRow["AvgSellPrice"] = w_tempRow["AvgSellPrice"].ToString();
							newRow["AccLots"] = int.Parse(s_temp_1["AccLots"].ToString()) + int.Parse(w_tempRow["BuyingLots"].ToString()) - int.Parse(w_tempRow["SellingLots"].ToString());
							newRow["RestHoldingLots"] = holdingLots;
							newRow["BuyHoldingDays"] = 0;
							newRow["HoldingDays"] = holdingDays;
							newRow["SoldWeightedDays"] = 0;
							result.Rows.Add(newRow);
						}
						result.Merge(widBroID);			
					}
				}

				//在這之前只計算過去有交易紀錄的權證，但仍有分點才第一次交易的權證

				//從未交易過的權證或累積張數為0
				foreach (DataRow row in wTable.Rows)
				{
					DataRow[] temp = summary_1.AsEnumerable().AsParallel().Where(r => r["WID"].ToString() == row["WID"].ToString() && 
						r["ListedDate"].ToString() == row["ListedDate"].ToString() && r["BrokerID"].ToString() == row["BrokerID"].ToString()).ToArray();
					//表示過去未交易過或累積張數為0
					if (temp.Count() == 0)
					{
						DataRow newRow = result.NewRow();
						newRow["TDate"] = date;
						newRow["WID"] = row["WID"].ToString();
						newRow["WName"] = row["WName"];
						newRow["UID"] = row["UID"].ToString();
						newRow["IssuerName"] = row["IssuerName"].ToString();
						newRow["ListedDate"] = row["ListedDate"].ToString();
						newRow["MaturityDate"] = row["MaturityDate"].ToString();
						newRow["BrokerID"] = row["BrokerID"].ToString();
						newRow["BrokerName"] = row["BrokerName"].ToString();
						newRow["BuyingLots"] = row["BuyingLots"].ToString();
						newRow["SellingLots"] = row["SellingLots"].ToString();
						newRow["AvgBuyPrice"] = row["AvgBuyPrice"].ToString();
						newRow["AvgSellPrice"] = row["AvgSellPrice"].ToString();
						newRow["AccLots"] = row["BuyingLots"].ToString();
						newRow["RestHoldingLots"] = row["BuyingLots"].ToString();
						newRow["BuyHoldingDays"] = 0;
						newRow["HoldingDays"] = 0;
						newRow["SoldWeightedDays"] = 0;
						result.Rows.Add(newRow);
					}
				}
			}

			//起始日(剛開始計算持有天期)
			else
			{
				foreach(DataRow row in wTable.Rows)
				{
					DataRow newRow = result.NewRow();
					newRow["TDate"] = row["TDate"].ToString();
					newRow["WID"] = row["WID"].ToString();
					newRow["WName"] = row["WName"].ToString();
					newRow["UID"] = row["UID"].ToString();
					newRow["IssuerName"] = row["IssuerName"].ToString();
					newRow["ListedDate"] = row["ListedDate"].ToString();
					newRow["MaturityDate"] = row["MaturityDate"].ToString();
					newRow["BrokerID"] = row["BrokerID"].ToString();
					newRow["BrokerName"] = row["BrokerName"].ToString();
					newRow["BuyingLots"] = row["BuyingLots"].ToString();
					newRow["SellingLots"] = row["SellingLots"].ToString();
					newRow["AvgBuyPrice"] = row["AvgBuyPrice"].ToString();
					newRow["AvgSellPrice"] = row["AvgSellPrice"].ToString();
					newRow["AccLots"] = row["BuyingLots"].ToString();
					newRow["RestHoldingLots"] = row["BuyingLots"].ToString();
					newRow["BuyHoldingDays"] = 0;
					newRow["HoldingDays"] = 0;
					newRow["SoldWeightedDays"] = 0;
					result.Rows.Add(newRow);
				}
			}		
			return (result);
		}

		//用先進先出法計算平均持有天期
		static Tuple<DataTable, int, double> CalculateHoldingLotsAndHoldingDays(DataTable s_temp, DataRow s_temp_1, DataRow[] w_temp, DataTable tradeDate, string date)
		{
			int holdingLots;
			double sellHoldingdays = 0;
			double volWeightedSoldDays = 0;
			
			DataTable sdt = InitializeTable();

			//今天有交易且過去有剩餘賣張
			if (w_temp.Count() > 0 && s_temp.Rows.Count > 0) 
			{
				//今日買進張數
				holdingLots = w_temp.Select(r => int.Parse(r["BuyingLots"].ToString())).ToList()[0];

				foreach (DataRow row in s_temp.Rows)
					sdt.ImportRow(row);

				//今日賣出張數
				int sellingLots = w_temp.Select(r => int.Parse(r["SellingLots"].ToString())).ToList()[0];
			
				//更新先前HoldingLots
				foreach (DataRow row in sdt.Rows)
				{
					//檢查過去買一天的剩餘張數，用今日賣張去扣過去每一天的剩餘張數(先扣日期最早的)

					if (sellingLots > int.Parse(row["RestHoldingLots"].ToString()))
					{
						//先算加權張數乘以天期(用來計算賣持有天期)
						volWeightedSoldDays += NumTradingDays(tradeDate, row["TDate"].ToString(), date) * int.Parse(row["RestHoldingLots"].ToString());
						sellingLots = sellingLots - int.Parse(row["RestHoldingLots"].ToString());
						//加權張數乘以天期(用來計算買持有天期)(比如說前日買了10張昨日賣了兩張，那就有8張持有兩天，兩張持有一天)
						row["SoldWeightedDays"] = int.Parse(row["SoldWeightedDays"].ToString()) + int.Parse(row["RestHoldingLots"].ToString()) * NumTradingDays(tradeDate, row["TDate"].ToString(), date);
						//那一天的剩餘張數歸0
						row["RestHoldingLots"] = 0;
						//Console.WriteLine(sellingLots);
					}
					else
					{
						volWeightedSoldDays += NumTradingDays(tradeDate, row["TDate"].ToString(), date) * sellingLots;
						row["SoldWeightedDays"] = int.Parse(row["SoldWeightedDays"].ToString()) + sellingLots * NumTradingDays(tradeDate, row["TDate"].ToString(), date);
						row["RestHoldingLots"] = int.Parse(row["RestHoldingLots"].ToString()) - sellingLots;
						sellingLots = 0;
					}
					if(row["BuyingLots"].ToString() != "0")
						//計算買持有天期
						row["BuyHoldingDays"] = (int.Parse(row["SoldWeightedDays"].ToString()) + int.Parse(row["RestHoldingLots"].ToString()) * NumTradingDays(tradeDate, row["TDate"].ToString(), date)) / double.Parse(row["BuyingLots"].ToString());
					//if (sellingLots == 0)
					//break;
				}
				if(w_temp.AsEnumerable().Select(r => int.Parse(r["SellingLots"].ToString())).ToList()[0] > 0)
					//計算賣持有天期
					sellHoldingdays = volWeightedSoldDays / w_temp.Select(r => int.Parse(r["SellingLots"].ToString())).ToList()[0];
			}
			//今天有交易但過去無剩餘買張
			else if (w_temp.Count() > 0 && s_temp.Rows.Count == 0) 
			{
				holdingLots = w_temp.Select(r => int.Parse(r["BuyingLots"].ToString())).ToList()[0];
				//holdingdays = s_temp_1.Select(r => double.Parse(r["AvgHoldingDays"].ToString())).ToList()[0];
			}
			//今天沒有交易但過去有剩餘買張
			else if (w_temp.Count() == 0 && s_temp.AsEnumerable().Count() > 0) 
			{
				//仍要計算買持有天期(因為多持有一天
				foreach (DataRow row in s_temp.Rows)
				{
					row["BuyHoldingDays"] = (int.Parse(row["SoldWeightedDays"].ToString()) + int.Parse(row["RestHoldingLots"].ToString()) * NumTradingDays(tradeDate, row["TDate"].ToString(), date)) / double.Parse(row["BuyingLots"].ToString());
					sdt.ImportRow(row);
				}
				holdingLots = 0;
				//holdingdays = s_temp_1.Select(r => double.Parse(r["AvgHoldingDays"].ToString())).ToList()[0];
			}
			else
			{
				holdingLots = 0;
				//holdingdays = s_temp_1.Select(r => double.Parse(r["AvgHoldingDays"].ToString())).ToList()[0];
			}
			return Tuple.Create(sdt, holdingLots, sellHoldingdays);
		} 

		static DataTable ReadFile(string path)
		{
			DataTable dt = new DataTable();
			using (StreamReader sr = new StreamReader(path, Encoding.GetEncoding("Big5")))
			{
				List<string> headers = sr.ReadLine().Split(',').ToList();
				foreach (string header in headers)
				{
					dt.Columns.Add(header);
				}
				while (!sr.EndOfStream)
				{
					List<string> rows = sr.ReadLine().Split(',').ToList();
					DataRow dr = dt.NewRow();
					for (int i = 0; i < headers.Count(); i++)
					{
						dr[i] = rows[i];
					}
					dt.Rows.Add(dr);
				}
			}
			return dt;
		}

		static void Main(string[] args)
		{
			//上一個交易日
			string date = TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");

			SqlConnection newEDIS = new SqlConnection("Data Source = 10.19.1.45; Initial Catalog = newEDIS; User ID = sa; Password = dw910770");
			newEDIS.Open();

			SqlConnection tsQuote = new SqlConnection("Data Source = 10.60.0.37; Initial Catalog = TsQuote; User ID = WarrantWeb; Password = WarrantWeb");
			tsQuote.Open();

			string cmQuery;

			
			string sqlqry = $"SELECT Convert(VARCHAR(10), cast(TradeDate as Date), 112) as TradeDate, " +
										"ROW_NUMBER() Over(Order by TradeDate asc) as DateOrder FROM TradeDate " +
											$"where TradeDate >= '{startDate}' and IsTrade = 'Y' order by TradeDate asc";

			DataTable tradeDate = MSSQL.ExecSqlQry(sqlqry, tsQuote);
			//List<string> tradeDateList = tradeDate.AsEnumerable().Select(r => r["TradeDate"].ToString()).ToList().GetRange(166, 9);
			
			DataTable warrantBasics = MSSQL.ExecSqlQry($"SELECT WID, UID, IssuerName, convert(varchar, ListedDate, 112) as ListedDate from WarrantBasics Where ListedDate >= '{startDate}'", newEDIS);
			Dictionary<string, string[]> dc = GetIssuerNameUID(warrantBasics);

			DataTable wTable;

			Directory.CreateDirectory(".\\Cmoney");

			DataTable summary = InitializeTable();

			DateTime start = DateTime.Now;
			Console.WriteLine(date);

			//昨日交易的權證且未到期
			DataTable summary_1 = MSSQL.ExecSqlQry($"SELECT convert(varchar, TDate, 112) as TDate, WID, WName, UID, IssuerName, convert(varchar, ListedDate, 112) as ListedDate, convert(varchar, MaturityDate, 112) as MaturityDate, BrokerID, BrokerName, " +
				$"BuyingLots, SellingLots, AvgBuyPrice, AvgSellPrice, AccLots, RestHoldingLots, BuyHoldingDays, HoldingDays, SoldWeightedDays from BrokerHoldingDays WHERE TDate = (SELECT MAX(TDate) from BrokerHoldingDays) and MaturityDate > '{date}'", newEDIS);
			Console.WriteLine("summary_1:" + summary_1.Rows.Count + "\n");
			//先前仍持有張數>0且未到期的權證
			summary = MSSQL.ExecSqlQry($"SELECT convert(varchar, TDate, 112) as TDate, WID, WName, UID, IssuerName, convert(varchar, ListedDate, 112) as ListedDate, convert(varchar, MaturityDate, 112) as MaturityDate, BrokerID, BrokerName, " +
				$"BuyingLots, SellingLots, AvgBuyPrice, AvgSellPrice, AccLots, RestHoldingLots, BuyHoldingDays, HoldingDays, SoldWeightedDays from BrokerHoldingDays WHERE MaturityDate > '{date}' and RestHoldingLots > 0", newEDIS);
			Console.WriteLine("summary:" + summary.Rows.Count + "\n");

			Utility.SaveToCSV(summary_1, ".\\summary1.csv", true);

			//個股券商分點進出明細表加上上市日期與到期日
			cmQuery = $"SELECT A.日期 as TDate, A.股票代號 as WID, A.股票名稱 as WName, A.券商代號 as BrokerID, A.券商名稱 as BrokerName, ISNULL(A.買張, 0) as BuyingLots, ISNULL(A.賣張, 0) as SellingLots, A.買均價 as AvgBuyPrice, A.賣均價 as AvgSellPrice, B.上市日期 as ListedDate, B.到期日期 as MaturityDate "
				+ $"from 個股券商分點進出明細 as A left join 權證評估表 as B on A.日期 = B.日期 and A.股票代號 = B.代號  where A.日期 = '{date}' and 股票代號 in (SELECT 代號 from 權證評估表 where 日期 = '{date}' and 上市日期 >= '{startDate}')";

			wTable = CMoney.ExecCMoneyQry(cmQuery);

			Utility.SaveToCSV(wTable, ".\\wTable.csv", true);
			//Console.ReadLine();
			DataTable wTable1 = wTable.Clone();
			wTable1.Columns.Add("UID");
			wTable1.Columns.Add("IssuerName");

			//加上UID與IssuerName
			foreach (DataRow row in wTable.Rows)
			{
				//Console.WriteLine(row["WID"].ToString());
				//Console.WriteLine(row["ListedDate"].ToString());
				//var temp = warrantBasics.AsEnumerable().Where(r => r["WID"].ToString() == row["WID"].ToString() && r["ListedDate"].ToString() == row["ListedDate"].ToString());
				//string issuerName = temp.Select(s => s["IssuerName"].ToString()).ToList()[0];
				//string uid = temp.Select(s => s["UID"].ToString()).ToList()[0];
				string str = row["WID"].ToString() + row["ListedDate"].ToString();
				string[] issuerUID = dc[str];
				string issuerName = issuerUID[1];
				string uid = issuerUID[0];
				if (row["BrokerID"].ToString() != issuerName)
				{
					DataRow newRow = wTable1.NewRow();
					newRow["TDate"] = row["TDate"].ToString();
					newRow["WID"] = row["WID"].ToString();
					newRow["WName"] = row["WName"].ToString();
					newRow["BrokerID"] = row["BrokerID"].ToString();
					newRow["BrokerName"] = row["BrokerName"].ToString();
					newRow["BuyingLots"] = row["BuyingLots"].ToString();
					newRow["SellingLots"] = row["SellingLots"].ToString();
					newRow["AvgBuyPrice"] = row["AvgBuyPrice"].ToString();
					newRow["AvgSellPrice"] = row["AvgSellPrice"].ToString();
					newRow["ListedDate"] = row["ListedDate"].ToString();
					newRow["MaturityDate"] = row["MaturityDate"].ToString();
					newRow["IssuerName"] = issuerName;
					newRow["UID"] = uid;
					wTable1.Rows.Add(newRow);
				}
			}

			//計算買持有天期與賣持有天期
			DataTable result = LotsReset(summary, summary_1, wTable1, tradeDate, date);

			Utility.SaveToCSV(result, ".\\result.csv", true);
			Console.WriteLine("Begin Deleting");

#if !DEBUG
			MSSQL.ExecSqlCmd($"Delete from BrokerHoldingDays WHERE MaturityDate > '{date}' and RestHoldingLots > 0", newEDIS);
			foreach (DataRow row in result.Rows)
			{
				string sqlstr = $"Insert BrokerHoldingDays Values('{row["TDate"].ToString()}', '{row["WID"].ToString()}', '{row["WName"].ToString()}', '{row["UID"].ToString()}', '{row["IssuerName"].ToString()}', '{row["ListedDate"].ToString()}', '{row["MaturityDate"].ToString()}', '{row["BrokerID"].ToString()}', '{row["BrokerName"].ToString()}', '{row["BuyingLots"].ToString()}', '{row["SellingLots"].ToString()}', '{row["AvgBuyPrice"].ToString()}', '{row["AvgSellPrice"].ToString()}', '{row["AccLots"].ToString()}', '{row["RestHoldingLots"].ToString()}', '{row["BuyHoldingDays"].ToString()}', '{row["HoldingDays"].ToString()}', '{row["SoldWeightedDays"].ToString()}')";
				MSSQL.ExecSqlCmd(sqlstr, newEDIS);
			}
#endif
			DateTime end = DateTime.Now;
			Console.WriteLine(end - start);
		}
	}
}
