﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EDLib;
using EDLib.SQL;
using System.Data.SqlClient;
using System.Data;

namespace MMVolNotify
{
	class Program
	{
		static void Main(string[] args)
		{
			try
			{
				string abnormalWID = "";
				string lastTradeDate = TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");
				DataTable warrantTrading;
				string sqlstr = $"Select TDate, WID, WName, IssuerName, WBidMedianIV_FinRate, MMVol from newEDIS.dbo.WarrantTrading where TDate = '{lastTradeDate}'";
				using (SqlConnection newEDIS = new SqlConnection("Data Source = 10.60.0.37; Initial Catalog = newEDIS; User ID = WarrantWeb; Password = WarrantWeb"))
				{
					newEDIS.Open();
					warrantTrading = MSSQL.ExecSqlQry(sqlstr, newEDIS);
				}

				var abnormalWIDlist = warrantTrading.AsEnumerable().Where(r => r["WBidMedianIV_FinRate"].ToString() == "0" && r["MMVol"].ToString() == "0").Select(s => s["WID"]).ToList();
				bool zeroMMVol = warrantTrading.AsEnumerable().All(r => r["MMVol"].ToString() == "0");
				if (abnormalWIDlist.Count() > 0 && !zeroMMVol)
				{
					foreach (string i in abnormalWIDlist)
					{
						abnormalWID += (i + "\n");
					}
					MailService ms = new MailService();
                    //2019.2.11 寄信的記得要改!!
					ms.SendMail("jerry.zeng@kgi.com", "Abnormal Warrant", new string[] { "jerry.zeng@kgi.com" }, null, null, $"{lastTradeDate}未能計算隱波之權證", abnormalWID, false, null);
					//ms.SendMail("jerry.zeng@kgi.com", "Abnormal Warrant", new string[] { "it.WMM@kgi.com" }, null, null, $"'{lastTradeDate}'未能計算隱波之權證", abnormalWID, false, null);
					ms.SendMail("jerry.zeng@kgi.com", "Abnormal Warrant", new string[] { "ed.trdtww@kgi.com" }, null, null, $"'{lastTradeDate}'未能計算隱波之權證", abnormalWID, false, null);
				}
				else if (zeroMMVol)
				{
					lastTradeDate = TradeDate.LastNTradeDate(2).ToString("yyyyMMdd");
					sqlstr = $"Select TDate, WID, WName, IssuerName, WBidMedianIV_FinRate, MMVol from newEDIS.dbo.WarrantTrading where TDate = '{lastTradeDate}'";
					using (SqlConnection newEDIS = new SqlConnection("Data Source = 10.60.0.37; Initial Catalog = newEDIS; User ID = WarrantWeb; Password = WarrantWeb"))
					{
						newEDIS.Open();
						warrantTrading = MSSQL.ExecSqlQry(sqlstr, newEDIS);
					}
					abnormalWIDlist = warrantTrading.AsEnumerable().Where(r => r["WBidMedianIV_FinRate"].ToString() == "0" && r["MMVol"].ToString() == "0").Select(s => s["WID"]).ToList();
					foreach (string i in abnormalWIDlist)
					{
						abnormalWID += (i + "\n");
					}
					MailService ms = new MailService();
					ms.SendMail("jerry.zeng@kgi.com", "Abnormal Warrant", new string[] { "jerry.zeng@kgi.com" }, null, null, $"{lastTradeDate}未能計算隱波之權證", abnormalWID, false, null);
					//ms.SendMail("jerry.zeng@kgi.com", "Abnormal Warrant", new string[] { "it.WMM@kgi.com" }, null, null, $"'{lastTradeDate}'未能計算隱波之權證", abnormalWID, false, null);
					ms.SendMail("jerry.zeng@kgi.com", "Abnormal Warrant", new string[] { "ed.trdtww@kgi.com" }, null, null, $"'{lastTradeDate}'未能計算隱波之權證", abnormalWID, false, null);
				}
				else
				{
					MailService ms = new MailService();
					ms.SendMail("jerry.zeng@kgi.com", "Abnormal Warrant", new string[] { "jerry.zeng@kgi.com" }, null, null, "所有權證隱波皆能計算", "", false, null);
				}
			}
			catch(Exception e)
			{
				MailService ms = new MailService();
				ms.SendMail("jerry.zeng@kgi.com", "Abnormal Warrant", new string[] { "jerry.zeng@kgi.com" }, null, null, "MMVolNotify Fail", e.Message, false, null);
			}
		}
	}
}
