﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using System.IO.Compression;
using EDLib;
using EDLib.SQL;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace LiquidityIndex
{
	class Program
	{
		//行情欄位
		static string[] relatedColumns = { "RecordTime", "Symbol", "SymbolName", "ReferencePrice", "UpLimitPrice", "DownLimitPrice", "OpenPX",
			"HighPx", "LowPx", "LastPx", "PreClosePx", "LastShares", "CumQty", "Bid1Px", "Bid1Shares", "Bid2Px", "Bid2Shares", "Bid3Px", "Bid3Shares",
			"Bid4Px", "Bid4Shares", "Bid5Px", "Bid5shares", "Ask1Px", "Ask1Shares", "Ask2Px", "Ask2Shares", "Ask3Px", "Ask3Shares", "Ask4Px", "Ask4Shares",
			"Ask5Px", "Ask5Shares", "NetChg", "NetChgPct", "Matched", "MatchStatus", "MatchTime" };

		static string date, endDate, startDate;

		static string[] bidask = { "Bid", "Ask" };

		static double[] percentage = { 50, 10 };

		static string[] time = { "0900", "0930", "1000", "1030", "1100", "1130","1200", "1230", "1300", "1320" };

		//最後輸出Table
		static DataTable InitializeFinalResultTable()
		{
			DataTable dt = new DataTable();
			dt.Columns.Add("TDate");
			dt.Columns.Add("UID");
			dt.Columns.Add("MarketValue", typeof(double));
			foreach (double j in percentage)
			{
				foreach (string s in bidask)
				{
					dt.Columns.Add(s + "LiquidityIndicator" + j.ToString(), typeof(double));
				}
			}		
			return dt;
		}

		//建立行情的Table
		static DataTable InitializeTable()
		{
			DataTable dt = new DataTable();
			foreach (string s in relatedColumns)
			{
				dt.Columns.Add(s);
			}
			return dt;
		}

		//最佳買賣五檔Table
		static DataTable Quote(DataRow rowTemp)
		{
			string bidp, bidv, askp, askv;
			DataTable dt = new DataTable();
			dt.Columns.Add("Num");
			dt.Columns.Add("BidP");
			dt.Columns.Add("BidV");
			dt.Columns.Add("AskP");
			dt.Columns.Add("AskV");
			for (int i=1; i<6; i++)
			{
				DataRow newRow = dt.NewRow();
				bidp = "Bid" + i + "Px";
				bidv = "Bid" + i + "Shares";
				askp = "Ask" + i + "Px";
				askv = "Ask" + i + "Shares";
				newRow["Num"] = i.ToString();
				newRow["BidP"] = rowTemp[bidp].ToString();
				newRow["BidV"] = rowTemp[bidv].ToString();
				newRow["AskP"] = rowTemp[askp].ToString();
				newRow["AskV"] = rowTemp[askv].ToString();
				dt.Rows.Add(newRow);
			}
			return dt;
		}

		//讀行情資料
		static DataTable ReadFile(string path)
		{
			DataTable dt = new DataTable();
			using (StreamReader sr = new StreamReader(path, Encoding.GetEncoding("Big5")))
			{
				foreach (string header in relatedColumns)
				{
					dt.Columns.Add(header);
				}
				while (!sr.EndOfStream)
				{
					List<string> rows = sr.ReadLine().Split(',').ToList();
					DataRow dr = dt.NewRow();
					for (int i = 0; i < relatedColumns.Length; i++)
					{
						dr[i] = rows[i];
					}
					dt.Rows.Add(dr);
				}
			}
			return dt;
		}

		//解壓縮行情
		static void GZipDecompress(string source, string dest)
		{
			using (FileStream sourceFile = File.OpenRead(source))
			using (FileStream destFile = File.Create(dest))
			using (GZipStream Gzip = new GZipStream(sourceFile, CompressionMode.Decompress, true))
			{
				int theByte = Gzip.ReadByte();
				while (theByte != -1)
				{
					destFile.WriteByte((byte)theByte);
					theByte = Gzip.ReadByte();
				}
			}
		}

		static void SaveToCSV(DataTable oTable, string FilePath)
		{
			string data = "";
			StreamWriter wr = new StreamWriter(FilePath, false, Encoding.GetEncoding("Big5"));
			foreach (DataColumn column in oTable.Columns)
			{
				data += column.ColumnName + ",";
			}
			data += "\n";
			wr.Write(data);
			data = "";

			foreach (DataRow row in oTable.Rows)
			{
				foreach (DataColumn column in oTable.Columns)
				{
					data += row[column].ToString().Trim() + ",";
				}
				data += "\n";
				wr.Write(data);
				data = "";
			}
			data += "\n";
			wr.Dispose();
			wr.Close();
		}

		//取百分位數
		static double Quantile(List<double> list, double percentile)
		{
			List<double> listSort = list.OrderBy(r => r).ToList();
			double quantile;
			int index = Convert.ToInt16(Math.Ceiling(list.Count * percentile /100));
			if (index == list.Count * percentile / 100)
				quantile = (listSort[index-1] + listSort[index])/2;
			else
				quantile = listSort[index-1];
			return quantile;
		}

		//股票市值區間內平均
		static Dictionary<string, double> MarketValue(string startDate, string endDate)
		{
			Dictionary<string, double> marketValue = new Dictionary<string, double>();
			string cQuery = $"SELECT 股票代號 as UID, AVG([總市值(億)]) as MarketValue FROM 日收盤表排行 WHERE 日期 >= '{startDate}' and 日期 <= '{endDate}'  and " +
				$"股票代號 in (SELECT DISTINCT 標的代號 from 權證評估表 WHERE 日期 >= '{startDate}' and 日期 <= '{endDate}') group by 股票代號";
			DataTable cdt = CMoney.ExecCMoneyQry(cQuery);
			foreach (DataRow row in cdt.Rows)
			{
				marketValue.Add(row[0].ToString(), double.Parse(row[1].ToString()));
			}
			return marketValue;
		}

		//抽樣點每半小時取一個點(此函式未用到
		static List<double> Liquidity(DataTable udInfo)
		{
			List<double> result = new List<double>(); 
			double bidliqResult = 0;
			double askliqResult = 0;
			List<double> liquidityBid = new List<double>();
			List<double> liquidityAsk = new List<double>();
			for (int i = 0; i < time.Length - 1; i++)
			{
				string hour = time[i].Substring(0, 2);
				int[] minute = { int.Parse(time[i].Substring(2, 2)), int.Parse(time[i + 1].Substring(2, 2)) };
				DataRow[] temp;
				if (time[i].Substring(0, 2) != time[i + 1].Substring(0, 2))
				{ 
					temp = udInfo.AsEnumerable().Where(r => r["RecordTime"].ToString().Substring(8, 2) == hour && int.Parse(r["RecordTime"].ToString().Substring(10, 2)) >= minute[1]
							&& int.Parse(r["RecordTime"].ToString().Substring(10, 2)) < 60 && r["Bid1Px"].ToString() != "0" && r["Bid1Shares"].ToString() != "0"
							&& r["Bid2Px"].ToString() != "0" && r["Bid2Shares"].ToString() != "0" && r["Bid3Px"].ToString() != "0" && r["Bid3Shares"].ToString() != "0"
							&& r["Bid4Px"].ToString() != "0" && r["Bid4Shares"].ToString() != "0" && r["Bid5Px"].ToString() != "0" && r["Bid5Shares"].ToString() != "0"
							&& r["Ask1Px"].ToString() != "0" && r["Ask1Shares"].ToString() != "0" && r["Ask2Px"].ToString() != "0" && r["Ask2Shares"].ToString() != "0"
							&& r["Ask3Px"].ToString() != "0" && r["Ask3Shares"].ToString() != "0" && r["Ask4Px"].ToString() != "0" && r["Ask4Shares"].ToString() != "0"
							&& r["Ask5Px"].ToString() != "0" && r["Ask5Shares"].ToString() != "0").ToArray();
				}
				else
				{
					temp = udInfo.AsEnumerable().Where(r => r["RecordTime"].ToString().Substring(8, 2) == hour && int.Parse(r["RecordTime"].ToString().Substring(10, 2)) >= minute[0]
							&& int.Parse(r["RecordTime"].ToString().Substring(10, 2)) < minute[1] && r["Bid1Px"].ToString() != "0" && r["Bid1Shares"].ToString() != "0"
							&& r["Bid2Px"].ToString() != "0" && r["Bid2Shares"].ToString() != "0" && r["Bid3Px"].ToString() != "0" && r["Bid3Shares"].ToString() != "0"
							&& r["Bid4Px"].ToString() != "0" && r["Bid4Shares"].ToString() != "0" && r["Bid5Px"].ToString() != "0" && r["Bid5Shares"].ToString() != "0"
							&& r["Ask1Px"].ToString() != "0" && r["Ask1Shares"].ToString() != "0" && r["Ask2Px"].ToString() != "0" && r["Ask2Shares"].ToString() != "0"
							&& r["Ask3Px"].ToString() != "0" && r["Ask3Shares"].ToString() != "0" && r["Ask4Px"].ToString() != "0" && r["Ask4Shares"].ToString() != "0"
							&& r["Ask5Px"].ToString() != "0" && r["Ask5Shares"].ToString() != "0").ToArray();
				}

				int rowNum = temp.Count();
				
				if (rowNum > 0)
				{
					//Console.WriteLine(rowNum);
					//Console.WriteLine(RanNum(rowNum));
					DataRow rowTemp = temp[RanNum(rowNum)];
					DataTable quote = Quote(rowTemp);
					double medianPrice = (quote.AsEnumerable().Where(r => r["Num"].ToString() == "1").Select(s => double.Parse(s["BidP"].ToString())).ToList()[0] + quote.AsEnumerable().Where(r => r["Num"].ToString() == "1").Select(s => double.Parse(s["AskP"].ToString())).ToList()[0]) / 2;
					double bidliq = quote.AsEnumerable().Where(r => double.Parse(r["BidP"].ToString()) < medianPrice * 1.01).Sum(s => double.Parse(s["BidP"].ToString()) * double.Parse(s["BidV"].ToString()));
					double askliq = quote.AsEnumerable().Where(r => double.Parse(r["AskP"].ToString()) > medianPrice * 0.99).Sum(s => double.Parse(s["AskP"].ToString()) * double.Parse(s["AskV"].ToString()));
					liquidityBid.Add(bidliq);
					liquidityAsk.Add(askliq);
				}
			}
			if (liquidityBid.Count() > 0)
				bidliqResult = liquidityBid.Average();
			if (liquidityAsk.Count() > 0)
				askliqResult = liquidityAsk.Average();
			result.Add(bidliqResult);
			result.Add(askliqResult);
			return result;
		}

		//每幾秒一個區間
		static List<string> CreateTimeInterval(int sec)
		{
			List<string> timeInterval = new List<string>();
			string date = DateTime.Now.ToString("yyyyMMdd");
			DateTime initial = new DateTime(int.Parse(date.Substring(0, 4)), int.Parse(date.Substring(4, 2)), int.Parse(date.Substring(6, 2)), 9, 0, 0);
			DateTime end = new DateTime(int.Parse(date.Substring(0, 4)), int.Parse(date.Substring(4, 2)), int.Parse(date.Substring(6, 2)), 13, 20, 0);
			timeInterval.Add(initial.Hour.ToString().PadLeft(2, '0') + initial.Minute.ToString().PadLeft(2, '0') + initial.Second.ToString().PadLeft(2, '0'));
			while (initial.AddSeconds(sec).CompareTo(end) <= 0)
			{
				initial = initial.AddSeconds(sec);
				timeInterval.Add(initial.Hour.ToString().PadLeft(2, '0') + initial.Minute.ToString().PadLeft(2, '0') + initial.Second.ToString().PadLeft(2, '0'));
			}
			return timeInterval;
		}

		//幾秒取一個點，來計算流動性指標
		static List<double> Liquidity5s(DataTable udInfo, List<string> timeInterval)
		{
			List<double> result = new List<double>();
			List<double> liquidityBid = new List<double>();
			List<double> liquidityAsk = new List<double>();

			//DataTable dt = new DataTable();
			//dt.Columns.Add("Bid");
			//dt.Columns.Add("Ask");

			foreach (string time in timeInterval)
			{
				//最佳五檔報價都不為0，才取出來算
				DataRow[] temp = udInfo.AsEnumerable().Where(r => int.Parse(r["RecordTime"].ToString().Substring(8, 6)) <= int.Parse(time)
							&& r["Bid1Px"].ToString() != "0" && r["Bid1Shares"].ToString() != "0"
							&& r["Bid2Px"].ToString() != "0" && r["Bid2Shares"].ToString() != "0" && r["Bid3Px"].ToString() != "0" && r["Bid3Shares"].ToString() != "0"
							&& r["Bid4Px"].ToString() != "0" && r["Bid4Shares"].ToString() != "0" && r["Bid5Px"].ToString() != "0" && r["Bid5Shares"].ToString() != "0"
							&& r["Ask1Px"].ToString() != "0" && r["Ask1Shares"].ToString() != "0" && r["Ask2Px"].ToString() != "0" && r["Ask2Shares"].ToString() != "0"
							&& r["Ask3Px"].ToString() != "0" && r["Ask3Shares"].ToString() != "0" && r["Ask4Px"].ToString() != "0" && r["Ask4Shares"].ToString() != "0"
							&& r["Ask5Px"].ToString() != "0" && r["Ask5Shares"].ToString() != "0").ToArray();
				//Console.WriteLine(temp.Count());
				if (temp.Count() > 0)
				{
					//只取一筆行情來看
					DataRow templast = temp[temp.Count() - 1];
					//將這筆行情整理成五個欄位的DataTable，最佳幾檔、買價、買量、賣價、賣量
					DataTable quote = Quote(templast);

					//買一價
					double bid1P = quote.AsEnumerable().Where(r => r["Num"].ToString() == "1").Select(s => double.Parse(s["BidP"].ToString())).ToList()[0];
					//賣一價
					double ask1P = quote.AsEnumerable().Where(r => r["Num"].ToString() == "1").Select(s => double.Parse(s["AskP"].ToString())).ToList()[0];
					//中價
					double medianPrice = (bid1P + ask1P) / 2;
					//計算加權委買價
					double bidWeightedPrice = quote.AsEnumerable().Where(r => double.Parse(r["BidP"].ToString()) < medianPrice * 1.01).Sum(s => double.Parse(s["BidP"].ToString()) * double.Parse(s["BidV"].ToString())) / quote.AsEnumerable().Where(r => double.Parse(r["BidP"].ToString()) < medianPrice * 1.01).Sum(s => double.Parse(s["BidV"].ToString()));
					//計算加權委買價
					double askWeightedPrice = quote.AsEnumerable().Where(r => double.Parse(r["AskP"].ToString()) > medianPrice * 0.99).Sum(s => double.Parse(s["AskP"].ToString()) * double.Parse(s["AskV"].ToString())) / quote.AsEnumerable().Where(r => double.Parse(r["AskP"].ToString()) > medianPrice * 0.99).Sum(s => double.Parse(s["AskV"].ToString()));
					//買賣價差
					double bidSpread = Math.Abs(bidWeightedPrice - medianPrice) / medianPrice;
					double askSpread = Math.Abs(askWeightedPrice - medianPrice) / medianPrice;
					//計算買賣流動性指標
					double bidliq = quote.AsEnumerable().Where(r => double.Parse(r["BidP"].ToString()) < medianPrice * 1.01).Sum(s => double.Parse(s["BidP"].ToString()) * double.Parse(s["BidV"].ToString())) / bidSpread / 100;
					double askliq = quote.AsEnumerable().Where(r => double.Parse(r["AskP"].ToString()) > medianPrice * 0.99).Sum(s => double.Parse(s["AskP"].ToString()) * double.Parse(s["AskV"].ToString())) / askSpread / 100;
					
					liquidityBid.Add(bidliq);
					liquidityAsk.Add(askliq);
				}			
			}
			//Utility.SaveToCSV(dt, $".\\2474day.csv", true);
			//Console.ReadLine();
			//把每一天每盤的流動性指標，取第50百分位數與第10百分位數
			foreach (double p in percentage)
			{
				if (liquidityBid.Count() > 0)
					result.Add(Quantile(liquidityBid, p));
				else
					result.Add(0);
				if (liquidityAsk.Count() > 0)
					result.Add(Quantile(liquidityAsk, p));
				else
					result.Add(0);
			}
			return result;
		}

		static List<double> Liquidity10days(DataTable dailyTable)
		{
			List<double> list = new List<double>();
			foreach(DataColumn column in dailyTable.Columns)
			{
				double per = double.Parse(Regex.Match(column.ToString(), @"\d+").Value);
				double liq = Quantile(dailyTable.AsEnumerable().Where(r => r[column].ToString() != "0").Select(s => double.Parse(s[column].ToString())).ToList(), per);
				list.Add(liq);
			}
			return list;
		}

		//Random number generator
		static int RanNum(int i)
		{
			Random rnd = new Random();
			return rnd.Next(i);
		}

		static void Main(string[] args)
		{			
			List<string> timeInterval = CreateTimeInterval(5);

			try
			{
				for (int j = 1; j < 2; j++)
				{
					DataTable summary = InitializeFinalResultTable();
					Dictionary<string, double> marketValue = new Dictionary<string, double>();
					DataTable result = InitializeFinalResultTable();

					//看要跑過去第j天資料
					date = TradeDate.LastNTradeDate(j).ToString("yyyyMMdd"); //結束日
					Console.WriteLine(date);
					startDate = TradeDate.LastNTradeDate(j + 9).ToString("yyyyMMdd"); //起始日

					//計算近10日市值平均
					marketValue = MarketValue(startDate, date);

					foreach (string uid in marketValue.Keys)
					{
						Console.WriteLine(uid);
						//for (int i = numDayBefore; i < numDayBefore + 10; i++)
						//{
						//date = TradeDate.LastNTradeDate(i).ToString("yyyyMMdd");

						DirectoryInfo di = Directory.CreateDirectory($".\\UnderlyingSnapShot{date}");
						string file = $@"\\10.19.1.203\Warrant\QuoteData\JQuote\{date}\MarketDataSnapshotFullRefresh\{uid}.txt.gz";
						if (!File.Exists(file))
							continue;
						string fileName = Path.GetFileName(file).Substring(0, Path.GetFileName(file).Length - 3);
						GZipDecompress(file, $".\\UnderlyingSnapShot{date}\\{fileName}");
						DataTable udInfo = ReadFile($".\\UnderlyingSnapShot{date}\\{fileName}");
						Console.WriteLine(udInfo.Rows.Count);
						if (udInfo.Rows.Count == 0)
							continue;

						//計算流動性指標
						List<double> liquidityIndex = Liquidity5s(udInfo, timeInterval);

						DataRow newRow = result.NewRow();
						newRow["TDate"] = date;
						newRow["UID"] = uid;
						newRow["MarketValue"] = marketValue[uid];
						int num = 0;
						foreach (double p in percentage)
						{
							foreach (string s in bidask)
							{
								newRow[s + "LiquidityIndicator" + p.ToString()] = liquidityIndex[num];
								num += 1;
							}
						}
						result.Rows.Add(newRow);
					}
					//Console.WriteLine(result.Rows.Count);
					//Console.ReadLine();
					Utility.SaveToCSV(result, $".\\summary{date}.csv", true);
#if !DEBUG
					SqlConnection newEDIS = new SqlConnection("Data Source=10.19.1.45;Initial Catalog=newEDIS;User ID=sa;Password=dw910770");
					foreach (DataRow row in result.Rows)
					{
						string sqlInsert = $"Insert UnderlyingLiquidity Values('{row[0].ToString()}', '{row[1].ToString()}', '{row[2]}', '{row[3]}', '{row[4]}', '{row[5]}', '{row[6]}')";
						MSSQL.ExecSqlCmd(sqlInsert, newEDIS);
					}
#endif
					//Directory.Delete($".\\UnderlyingSnapShot{date}", true);
				}
			}
			catch(Exception e)
			{
				MailService ms = new MailService();
				ms.SendMail("jerry.zeng@kgi.com", "10.19.1.45", new string[] { "jerry.zeng@kgi.com" }, null, null, "UnderlyingLiquidity Fail", e.Message, false, null);
			}
		}
	}
}
