﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Net;
using System.Data;
using System.Data.SqlClient;
using EDLib;
using EDLib.SQL;
using System.IO.Compression;
using System.IO;

namespace SpreadOrder
{
	class Program
	{
		static string today = TradeDate.LastNTradeDate(1).ToString("yyyy_MM_dd");

		static void DownLoadFile(string today)
		{
			WebClient wc = new WebClient();
			wc.DownloadFile("http://www.taifex.com.tw/file/taifex/Dailydownload/DailydownloadCSV_C/Daily_"+today+"_C.zip",
			$".\\Daily_{today}_C.zip");
		}

		static void ZipCompress(string source, string dest)
		{
			using (ZipArchive archive = ZipFile.OpenRead(source))
			{
				foreach (ZipArchiveEntry entry in archive.Entries)
				{
					if (entry.FullName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase))
					{
						string destinationPath = Path.GetFullPath(Path.Combine(dest, entry.FullName));
						if (!File.Exists(destinationPath))
							entry.ExtractToFile(destinationPath);
					}
				}
			}
		}

		static DataTable ReadFile(string path)
		{
			DataTable dt = new DataTable();
			using (StreamReader sr = new StreamReader(path, Encoding.GetEncoding("Big5")))
			{
				string[] headers = sr.ReadLine().Split(',');
				foreach (string header in headers)
				{
					dt.Columns.Add($"{header}");
				}
				while (!sr.EndOfStream)
				{
					List<string> rows = sr.ReadLine().Split(',').ToList();
					DataRow dr = dt.NewRow();
					for (int i = 0; i < headers.Length; i++)
					{
							dr[i] = rows[i];
					}
					dt.Rows.Add(dr);
				}
			}
			return dt;
		}

		static void Main(string[] args)
		{
			try
			{
				SqlConnection testEDIS = new SqlConnection("Data Source=10.19.1.45;Initial Catalog=testEDIS;User ID=sa;Password=dw910770");
				string source = $".\\Daily_{today}_C.zip";
				Console.WriteLine(source);
				string dest = $".\\";
				Console.WriteLine($"DownLoad{today}File......");
				DownLoadFile(today);
				Console.WriteLine("Unzip......");
				ZipCompress(source, dest);
				DataTable data = ReadFile($".\\Daily_{today}_C.csv");
				Utility.SaveToCSV(data, $".\\{today}SpreadOreder.csv", true);
				foreach (DataRow row in data.Rows)
				{
#if !DEBUG
					if (row[8].ToString() == " ")
						row[8] = "N";
					else
						row[8] = "Y";

					string sqlInsert = $"Insert SpreadOrder Values( '{row[0].ToString()}', '{row[1].ToString()}', " +
						$"'{row[2].ToString()}', '{row[3].ToString()}', {row[4]}, {row[5]}, {row[6]}, {row[7]}, '{row[8]}')";
					MSSQL.ExecSqlCmd(sqlInsert, testEDIS);
#endif
				}
				File.Delete(source);
				File.Delete($".\\Daily_{today}_C.csv");
			}
			catch (Exception e)
			{
				MailService ms = new MailService();
				ms.SendMail("licheng@kgi.com", "10.19.1.45", new string[] { "licheng@kgi.com" }, null, null, "SpreadOrder Fail", e.Message, false, null);
			}
		}
	}
}
