﻿using System;
using System.Threading;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using EDLib.SQL;
using EDLib;

namespace BrokerLots
{
    class Program
    {
        static DataTable BrokerLots;
        static StreamWriter sqlLog = new StreamWriter(".\\SQLlogTest.txt");
        static string lastTDate = "20180416"; //TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");
        //static string lastTDate_1 = TradeDate.LastNTradeDate(2).ToString("yyyyMMdd");
        static void LoadData()
        {
            string sqlStr = "SELECT A.日期, A.股票代號, replace(A.券商名稱, '-', ''), A.買張, A.賣張, A.[買金額(千)] * 1000, A.[賣金額(千)] * 1000 from 個股券商分點進出明細 as A"
            + " inner join 權證評估表 as B on A.日期 = B.日期 and A.股票代號 = B.代號"
            + $" where A.日期 >= '{lastTDate}'";

            BrokerLots = CMoney.ExecCMoneyQry(sqlStr);
            Console.WriteLine("CMoneyCount:" + BrokerLots.Rows.Count);

            while (BrokerLots.Rows.Count == 0)
            {
                Thread.Sleep(60000);
                BrokerLots = CMoney.ExecCMoneyQry(sqlStr);
                Console.WriteLine("CMoneyCount:" + BrokerLots.Rows.Count);
            }
        }
        static void Main(string[] args)
        {
            LoadData();
#if !DEBUG
            /*Open SQL Connection*/
            SqlConnection testEDIS = new SqlConnection("Data Source = 10.19.1.45; Initial Catalog = testEDIS; User ID = sa; Password = dw910770");
            testEDIS.Open();
            //SqlConnection newEDIS = new SqlConnection("Data Source = 10.19.1.45; Initial Catalog = newEDIS; User ID = sa; Password = dw910770");
            //newEDIS.Open();
#endif 
            /*
            SqlConnection testEDIS = new SqlConnection("Data Source = 10.19.1.45; Initial Catalog = testEDIS; User ID = sa; Password = dw910770");
            testEDIS.Open();
            MSSQL.ExecSqlCmd("Delete from BrokerLots", testEDIS);
            */
            foreach (DataRow row in BrokerLots.Rows)
            {
                string sqlstring = string.Join(",", row.ItemArray);
                sqlLog.WriteLine(sqlstring);
                string sqlInsert = "Insert BrokerLots Values( '";
                sqlInsert += $"{row[0].ToString()}', '{row[1].ToString()}', '{row[2].ToString()}', '{row[3]}', '{row[4]}', '{row[5]}', '{row[6]}')";
#if !DEBUG
                MSSQL.ExecSqlCmd(sqlInsert, testEDIS);
#endif
            }
            sqlLog.Close();
            //testEDIS.Close();
        }
    }
}
