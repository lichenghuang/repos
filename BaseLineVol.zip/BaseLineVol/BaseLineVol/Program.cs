﻿using EDLib.Pricing.Option;
using EDLib.SQL;
using EDLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Data.SqlClient;

namespace BaseLineVol
{
	class Program
	{
		static string[] BrokerDataColumn = {"RecordTime.w", "Symbol.w", "ReferencePrice.w", "UpLimitPrice.w", "DownLimitPrice.w", "OpenPx.w", "HighPx.w", "LowPx.w", "LastPx.w", "PreClosePx.w", "LastShares.w", "CumQty.w", "Bid1Px.w", "Bid1Shares.w", "Bid2Px.w",
			"Bid2Shares.w", "Bid3Px.w", "Bid3Shares.w", "Bid4Px.w", "Bid4Shares.w", "Bid5Px.w", "Bid5Shares.w", "Ask1Px.w", "Ask1Shares.w", "Ask2Px.w", "Ask2Shares.w", "Ask3Px.w", "Ask3Shares.w", "Ask4Px.w", "Ask4Shares.w", "Ask5Px.w", "Ask5Shares.w", "NetChg.w", "NetChgPct.w",
			"Matched.w", "MatchStatus.w", "MatchTime.w", "MatchIndex.w", "RecordTime.u", "Symbol.u", "ReferencePrice.u", "UpLimitPrice.u", "DownLimitPrice.u", "OpenPx.u", "HighPx.u", "LowPx.u", "LastPx.u", "PreClosePx.u", "LastShares.u", "CumQty.u", "Bid1Px.u", "Bid1Shares.u",
			"Bid2Px.u", "Bid2Shares.u", "Bid3Px.u", "Bid3Shares.u", "Bid4Px.u", "Bid4Shares.u", "Bid5Px.u", "Bid5Shares.u", "Ask1Px.u", "Ask1Shares.u", "Ask2Px.u", "Ask2Shares.u", "Ask3Px.u", "Ask3Shares.u", "Ask4Px.u", "Ask4Shares.u", "Ask5Px.u", "Ask5Shares.u", "NetChg.u", "NetChgPct.u",
			"Matched.u", "MatchStatus.u", "MatchTime.u", "Last.RecordTime.u", "Last.Bid1Px.u", "Last.Bid1Shares.u", "Last.Ask1Px.u", "Last.Ask1Shares.u", "Last.MatchTime.u", "MatchIndex.u", "price.w", "Qty.w", "BidDifference.u", "AskDifference.u", "buyside", "sellside", "buyside_flag", "sellside_flag",
			"b_accuracy", "s_accuracy", "RanOver", "PnL", "Delta", "UniqueID", "buysideCode", "sellsideCode" };
		static DataTable brokerData;
		static DataTable warrantTrading;
		static string[] buySell = { "buy", "sell" };

		static Dictionary<string, string> BidAsk(string wClass)
		{
			if (wClass == "c")
			{
				 Dictionary<string, string> dict = new Dictionary<string, string>()
				{
					{ buySell[0], "Bid" }, {buySell[1], "Ask" }
				};
				return dict;
			}
			else
			{
				Dictionary<string, string> dict = new Dictionary<string, string>()
				{
					{ buySell[0], "Ask" }, {buySell[1], "Bid" }
				};
				return dict;
			}
		}
		
		static string todayStr = "20180529"; //DateTime.Today.ToString("yyyyMMdd");
		static Dictionary<string, double> dic = new Dictionary<string, double>();

		static readonly double intRate = 0.025;

		static DataTable InitializeBaseVolTables()
		{
			DataTable dt = new DataTable();
			dt.Columns.Add("WID", typeof(string));
			dt.Columns.Add("BaseLineVol", typeof(double));
			dt.Columns.Add("WBidMedianIV_FinRate", typeof(string));
			return dt;
		}

		static DataTable InitializeTables()
		{
			DataTable dt = new DataTable();
			dt.Columns.Add("TDate", typeof(string));
			dt.Columns.Add("WID", typeof(string));
			dt.Columns.Add("IssuerName", typeof(string));
			dt.Columns.Add("BaseLineVol", typeof(double));
			dt.Columns.Add("BidVolSpread", typeof(double));
			dt.Columns.Add("AskVolSpread", typeof(double));
			dt.Columns.Add("Total", typeof(double));
			return dt;
		}

		static DataTable OverNightVegaPLTable(DataTable warrantTrading, DataTable brokerData, Dictionary<string, double> baseLineVol)
		{
			DataTable dt = new DataTable();
			dt.Columns.Add("TDate", typeof(string));
			dt.Columns.Add("WID", typeof(string));
			dt.Columns.Add("UID", typeof(string));
			dt.Columns.Add("IssuerName", typeof(string));
			dt.Columns.Add("AccReleasingLots", typeof(double));
			dt.Columns.Add("BaseLineVol", typeof(double));
			dt.Columns.Add("WTheoPrice", typeof(double));
			dt.Columns.Add("WBidPrice", typeof(double));
			dt.Columns.Add("OverNightVegaPL", typeof(double));

			foreach (DataRow row in warrantTrading.Rows)
			{
				if (row["WClass"].ToString() != "c" && row["WClass"].ToString() != "p" && double.Parse(row["WBidPrice"].ToString()) != -1)
					continue;
				/*
				Console.WriteLine(row["WID"].ToString());
				
				if (row["WID"].ToString() == "03965P")
				{ 
					Console.WriteLine(row["WID"].ToString() == "03965P");
					Console.WriteLine(row["WClass"].ToString());
					Console.WriteLine(double.Parse(row["WBidPrice"].ToString()) == 0);
					Console.ReadLine();
					continue;
				}
				*/
				double vol = 0;
				double wTheoPrice = 0;
				double Acc = double.Parse(row["AccReleasingLots"].ToString());
				try
				{
					vol = baseLineVol[row["WID"].ToString()];
				}
				catch
				{
					vol = double.Parse(row["WBidMedianIV_FinRate"].ToString());
				}

				if (row["WClass"].ToString() == "c")
				{
					//Console.WriteLine(double.Parse(row["UBidPrice"].ToString()));
					//Console.ReadLine();
					if (double.Parse(row["UBidPrice"].ToString()) == 0)
					{
						//Console.WriteLine(double.Parse(row["UBidPrice"].ToString()) == 0);
						//Console.ReadLine();
						continue;
					}
					wTheoPrice = PlainVanilla.CallPrice(double.Parse(row["UBidPrice"].ToString()), double.Parse(row["StrikePrice"].ToString()), intRate, vol, double.Parse(row["TtoM"].ToString()) / 252) * double.Parse(row["CR"].ToString());
				}
				else
				{
					//Console.WriteLine(double.Parse(row["UAskPrice"].ToString()));
					//Console.ReadLine();
					if (double.Parse(row["UAskPrice"].ToString()) == 0)
						continue;
					wTheoPrice = PlainVanilla.PutPrice(double.Parse(row["UAskPrice"].ToString()), double.Parse(row["StrikePrice"].ToString()), intRate, vol, double.Parse(row["TtoM"].ToString()) / 252) * double.Parse(row["CR"].ToString());
				}
				wTheoPrice = WTheoPriceModify(wTheoPrice);
				double overNightVegaPL = -Acc * (wTheoPrice - double.Parse(row["WBidPrice"].ToString()));
				DataRow newRow = dt.NewRow();
				newRow["TDate"] = todayStr;
				newRow["WID"] = row["WID"].ToString();
				newRow["UID"] = row["UID"].ToString();
				newRow["IssuerName"] = row["IssuerName"].ToString();
				newRow["AccReleasingLots"] = row["AccReleasingLots"];
				newRow["BaseLineVol"] = vol;
				newRow["WTheoPrice"] = wTheoPrice;
				newRow["WBidPrice"] = row["WBidPrice"];
				newRow["OverNightVegaPL"] = overNightVegaPL;
				dt.Rows.Add(newRow);
			}
			return dt;
		}

		static DataTable ParseBrokerData(string fileName)
		{
			DataTable dt = new DataTable();
			foreach (string i in BrokerDataColumn)
				dt.Columns.Add(i);
			using (StreamReader reader = new StreamReader(fileName))
			{
				reader.ReadLine(); //skip first line
				string[] thisLine = null;
				while (!reader.EndOfStream)
				{
					thisLine = reader.ReadLine().Split(',');
					//Delete ""
					thisLine[1] = thisLine[1].TrimEnd('"').TrimStart('"');
					thisLine[88] = thisLine[88].TrimEnd('"').TrimStart('"');
					thisLine[89] = thisLine[89].TrimEnd('"').TrimStart('"');
					dt.Rows.Add(thisLine);
				}
			}
			return dt;
		}

		static Dictionary<string, double> BaseLineVol(DataTable warrantTrading, DataTable brokerData)
		{
			DataRow[] brokerDataMM = brokerData.AsEnumerable().Where(r => r[$"buyside_flag"].ToString() == "MM" &&
				 !r["Symbol.w"].ToString().Contains("C") && !r["Symbol.w"].ToString().Contains("B") && !r["Symbol.w"].ToString().Contains("X") && r["RanOver"].ToString() == "\"Normal\"" &&
				  r[$"Bid1Px.w"].ToString() != "NA" && r[$"Bid1Px.w"].ToString() != "0" //&&r["Symbol.w"].ToString() == "062190"
				  ).ToArray();
			//Console.WriteLine(brokerDataMM.Count());
			foreach (string wid in brokerDataMM.AsEnumerable().Select(r => r["Symbol.w"].ToString()).Distinct())
			{
				string bidAskSide;
				string WClass;
				if (wid[wid.Length - 1] == 'P')
				{
					brokerDataMM = brokerDataMM.Where(r => r[$"Ask1Px.u"].ToString() != "NA" && r[$"Ask1Px.u"].ToString() != "0").ToArray();
					bidAskSide = "Ask";
					WClass ="p";
				}
				else
				{
					brokerDataMM = brokerDataMM.Where(r => r[$"Bid1Px.u"].ToString() != "NA" && r[$"Bid1Px.u"].ToString() != "0").ToArray();
					bidAskSide = "Bid";
					WClass = "c";
				}
				
				var warrantTradingWid = warrantTrading.AsEnumerable().Where(r => r["WID"].ToString() == wid);
				DataRow[] brokerDataMMWid = brokerDataMM.Where(r => r["Symbol.w"].ToString() == wid).ToArray();
				//if (brokerDataMMWid.Count() == 0)
					//continue;
				List<double> baseLineVol = new List<double>();
				List<DataRow> baseLineVolCandidate = new List<DataRow>();
				foreach (double sp in brokerDataMMWid.AsEnumerable().Select(r => double.Parse(r[$"{bidAskSide}1Px.u"].ToString())).Distinct())
				{
				Console.WriteLine(sp);
				//Console.ReadLine();
					DataRow[] brokerDataMMWidStPrice = brokerDataMMWid.Where(r => r[$"{bidAskSide}1Px.u"].ToString() == sp.ToString()).OrderByDescending(r => r["LastPx.w"]).ToArray();
					if (brokerDataMMWidStPrice.Count() >= 1)
						baseLineVolCandidate.Add(brokerDataMMWidStPrice.First());
				}
				if (baseLineVolCandidate.Count <= 0)
				{
					dic.Add(wid, -1);
					continue;
				}
				Console.WriteLine(baseLineVolCandidate.Count());
				foreach (DataRow row in baseLineVolCandidate)
				{
					Console.WriteLine("StockPrice" + row[$"{bidAskSide}1Px.u"].ToString());
					double StockPrice = double.Parse(row[$"{bidAskSide}1Px.u"].ToString());
					double StrikePrice = double.Parse(warrantTradingWid.Select(r => r["StrikePrice"]).ToArray()[0].ToString());
					Console.WriteLine("StrikePrice" + StrikePrice);
					double TtoM = double.Parse(warrantTradingWid.Select(r => r["TtoM"]).ToArray()[0].ToString()) / 252;
					Console.WriteLine("ToM" + double.Parse(warrantTradingWid.Select(r => r["TtoM"]).ToArray()[0].ToString()));
					double CR = double.Parse(warrantTradingWid.Select(r => r["CR"]).ToArray()[0].ToString());
					Console.WriteLine("CR" + CR);
					double warrantPrice = double.Parse(row[$"LastPx.w"].ToString()) / CR;
					Console.WriteLine("Wp" + warrantPrice);
					double iV;
					if (WClass == "c")
					{
						iV = PlainVanilla.CallIVNewton(StockPrice, StrikePrice, intRate, TtoM, warrantPrice);
						if (iV < 0)
							iV = PlainVanilla.CallIVBisection(StockPrice, StrikePrice, intRate, TtoM, warrantPrice);
						baseLineVol.Add(iV);
						Console.WriteLine("IV" + iV);
					}
					else
					{
						iV = PlainVanilla.PutIVNewton(StockPrice, StrikePrice, intRate, TtoM, warrantPrice);
						if (iV < 0)
							iV = PlainVanilla.PutIVBisection(StockPrice, StrikePrice, intRate, TtoM, warrantPrice);
						baseLineVol.Add(iV);
						Console.WriteLine("IV" + iV);
					}
					//Console.ReadLine();
				}
				if  (Median(baseLineVol) > 0) 
					dic.Add(wid, Math.Round(Median(baseLineVol), 4, MidpointRounding.AwayFromZero));
			}
			return dic;
		}

		static double Median(List<double> vs)
		{
			if (vs.Count % 2 == 1)
				return vs[vs.Count / 2];
			else
				return (vs[vs.Count / 2] + vs[vs.Count / 2 - 1]) / 2;
		}

		static double Jumpsize(double p)
		{
			if (p < 5)
				return (0.01);
			else if (p < 10)
				return (0.05);
			else if (p < 50)
				return (0.1);
			else if (p < 100)
				return (0.5);
			else if (p < 500)
				return (1);
			else
				return (5);
		}

		static double WTheoPriceModify(double wTheoPrice)
		{
			double tick = Jumpsize(wTheoPrice);
			return Math.Round(wTheoPrice / tick, 0, MidpointRounding.AwayFromZero) * tick;
		}

		static void Main(string[] args)
		{
			SqlConnection testEDIS = new SqlConnection("Data source=10.19.1.45;Initial Catalog=testEDIS;User ID=sa;Password=dw910770");
			testEDIS.Open();

			Console.WriteLine("Parsing WarrantData_v3......");
			brokerData = ParseBrokerData($"\\\\10.19.1.203\\Warrant\\QuoteData\\JQuote\\{todayStr}\\WarrantData_v3.csv");
			Console.WriteLine("Loading WarrantTradingData......");
			warrantTrading = MSSQL.ExecSqlQry($"SELECT TDate, IssuerName, WID, UID, WClass, StrikePrice, CR, TtoM, UBidPrice, UAskPrice, WBidPrice, WAskPrice, AccReleasingLots, WBidMedianIV_FinRate from [dbo].[WarrantTrading] where TDate = '{todayStr}'", "Server=10.19.1.45;DataBase=newEDIS;Uid=readuser;pwd=readuser;");
			Dictionary<string, double> baseLineVol = BaseLineVol(warrantTrading, brokerData);

			DataTable baseVolResult = InitializeBaseVolTables();
			foreach (var pair in baseLineVol)
			{
				DataRow newRow = baseVolResult.NewRow();
				newRow["WID"] = pair.Key;
				newRow["BaseLineVol"] = pair.Value;
				newRow["WBidMedianIV_FinRate"] = warrantTrading.AsEnumerable().Where(r => r["WID"].ToString() == pair.Key).Select(r => r["WBidMedianIV_FinRate"].ToString()).ToArray().First();
				baseVolResult.Rows.Add(newRow);
			}
			
			Utility.SaveToCSV(baseVolResult, $".\\BaseLineVoltest{todayStr}.csv", true);

			//DataTable overNightVegaPLTable = OverNightVegaPLTable(warrantTrading, brokerData, baseLineVol);
			//Utility.SaveToCSV(overNightVegaPLTable, $".\\overNightVegaPL.csv", true);

			/*
			#region BidVolSpread  
			DataTable result = InitializeTables();
 
			foreach (string wid in baseLineVol.Keys)
			{
				string wClass;
				if (wid[wid.Length -1 ] == 'P')
				{
					wClass = "p";
				}
				else
				{
					wClass = "c";
				}
				Console.WriteLine(wClass);
				//Console.ReadLine();
				double BidVolSpread = 0;
				double AskVolSpread = 0;
				var warrantTradingWid = warrantTrading.AsEnumerable().Where(r => r["WID"].ToString() == wid);
				Console.WriteLine(warrantTradingWid.Count());
				foreach (string side in buySell)
				{
					if (side == "buy")
						continue;
					DataRow[] brokerDataMMWid = brokerData.AsEnumerable().Where(r => r[$"{side}side_flag"].ToString() == "MM" &&
						r[$"Symbol.w"].ToString() == wid && r[$"{bidAsk(wClass)[side]}1Px.u"].ToString() != "NA" && r[$"{bidAsk(wClass)[side]}1Px.u"].ToString() != "0" &&
						r[$"LastPx.w"].ToString() != "NA" && r[$"LastPx.w"].ToString() != "0").ToArray();
					Console.WriteLine(side + brokerDataMMWid.Count());
					if (brokerDataMMWid.Count() > 0)
					{ 
						foreach(DataRow row in brokerDataMMWid)
						{
							double StockPrice = double.Parse(row[$"{bidAsk(wClass)[side]}1Px.u"].ToString());
							double StrikePrice = double.Parse(warrantTradingWid.Select(r => r["StrikePrice"]).ToArray()[0].ToString());
							double TtoM = double.Parse(warrantTradingWid.Select(r => r["TtoM"]).ToArray()[0].ToString()) / 252;
							double CR = double.Parse(warrantTradingWid.Select(r => r["CR"]).ToArray()[0].ToString());
							double warrantPrice = double.Parse(row[$"LastPx.w"].ToString());
							double Qty = double.Parse(row[$"Qty.w"].ToString());
						if (side == "buy")
						{
							if (wClass == "c")
							{
								BidVolSpread += (Math.Round(PlainVanilla.CallPrice(StockPrice, StrikePrice, intRate, baseLineVol[wid], TtoM) * CR, 2, MidpointRounding.AwayFromZero) - warrantPrice) * Qty;
								Console.WriteLine(PlainVanilla.CallPrice(StockPrice, StrikePrice, intRate, baseLineVol[wid], TtoM) * CR);
								Console.WriteLine((PlainVanilla.CallPrice(StockPrice, StrikePrice, intRate, baseLineVol[wid], TtoM) * CR - warrantPrice) * Qty);
							}
							else
							{
								BidVolSpread += (Math.Round(PlainVanilla.PutPrice(StockPrice, StrikePrice, intRate, baseLineVol[wid], TtoM) * CR, 2, MidpointRounding.AwayFromZero) - warrantPrice) * Qty;
								Console.WriteLine(PlainVanilla.PutPrice(StockPrice, StrikePrice, intRate, baseLineVol[wid], TtoM) * CR);
								Console.WriteLine((PlainVanilla.PutPrice(StockPrice, StrikePrice, intRate, baseLineVol[wid], TtoM) * CR - warrantPrice) * Qty);
							}
						}
						else
						{
							if (wClass == "c")
							{
								AskVolSpread -= (Math.Round(PlainVanilla.CallPrice(StockPrice, StrikePrice, intRate, baseLineVol[wid], TtoM) * CR, 2, MidpointRounding.AwayFromZero) - warrantPrice) * Qty;
								Console.WriteLine(Math.Round(PlainVanilla.CallPrice(StockPrice, StrikePrice, intRate, baseLineVol[wid], TtoM) * CR, 2, MidpointRounding.AwayFromZero));
								Console.WriteLine((Math.Round(PlainVanilla.CallPrice(StockPrice, StrikePrice, intRate, baseLineVol[wid], TtoM) * CR, 2, MidpointRounding.AwayFromZero)) * Qty);
							}
							else
							{
								AskVolSpread -= (Math.Round(PlainVanilla.PutPrice(StockPrice, StrikePrice, intRate, baseLineVol[wid], TtoM) * CR, 2, MidpointRounding.AwayFromZero) - warrantPrice) * Qty;
								Console.WriteLine(Math.Round(PlainVanilla.PutPrice(StockPrice, StrikePrice, intRate, baseLineVol[wid], TtoM) * CR, 2, MidpointRounding.AwayFromZero));
								Console.WriteLine((Math.Round(PlainVanilla.PutPrice(StockPrice, StrikePrice, intRate, baseLineVol[wid], TtoM) * CR, 2, MidpointRounding.AwayFromZero) - warrantPrice)* Qty);
							}
						}
					}
				}
			}
				Console.ReadLine();
				DataRow newRow = result.NewRow();
				newRow["TDate"] = todayStr;
				newRow["WID"] = wid;
				newRow["IssuerName"] = warrantTradingWid.Select(r => r["IssuerName"]).ToArray()[0].ToString();
				newRow["BaseLineVol"] = baseLineVol[wid];
				newRow["BidVolSpread"] = BidVolSpread;
				newRow["AskVolSpread"] = AskVolSpread;
				newRow["Total"] = AskVolSpread + BidVolSpread;
				result.Rows.Add(newRow);
		    }

			/*
			DataTable BaseVolResult = InitializeBaseVolTables();
			foreach (var pair in baseLineVol)
			{
				DataRow newRow = BaseVolResult.NewRow();
				newRow["WID"] = pair.Key;
				newRow["BaseLineVol"] = pair.Value;
				BaseVolResult.Rows.Add(newRow);
			}
			Utility.SaveToCSV(result, $".\\BaseLineVoltest{todayStr}1.csv", true);
			#endregion
			*/
		}
	}
}
