﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.IO.Compression;
using System.Data;
using EDLib;
using EDLib.SQL;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace TXOVolume
{

	class Program
	{
		static string[] relatedColumns = {"CommodityId", "CommodityNm", "MatchTime", "LastP", "LastQ", "TotalQ", "Bid1P", "Bid1Q",
				"Ask1P", "Ask1Q", "UnderlyingId", "Kind", "InformationSeq", "InformationTime", "MatchSeq",
				"Bid2P", "Bid2Q", "Ask2P", "Ask2Q", "Bid3P", "Bid3Q", "Ask3P", "Ask3Q", "Bid4P", "Bid4Q", "Ask4P", "Ask4Q",
				"Bid5P", "Bid5Q", "Ask5P", "Ask5Q", "Maturity", "Strike", "RecTime" };

		static string[] timeInterval = {"0845", "0945", "1045", "1145", "1245", "1345", "1500", "1600", "1700", "1800", "1900", "2000", "2100", "2200", "2300"
		,"0000", "0100", "0200", "0300", "0400", "0500"};

		static string today;

		static DataTable InitializeResultTable()
		{
			DataTable dt = new DataTable();
			dt.Columns.Add("DateTime");
			dt.Columns.Add("Date");
			dt.Columns.Add("Time");
			dt.Columns.Add("Volume");
			return dt;
		}

		static DataTable InitializeTable()
		{
			DataTable dt = new DataTable();
			foreach(string s in relatedColumns)
			{
				dt.Columns.Add(s);
			}
			return dt;
		}

		static void Zipcompress(string source, string dest)
		{
			using(ZipArchive archive = ZipFile.OpenRead(source))
			{
				foreach(ZipArchiveEntry entry in archive.Entries)
				{
					if(entry.FullName.EndsWith(".txt", StringComparison.OrdinalIgnoreCase))
					{
						string destinationPath = Path.GetFullPath(Path.Combine(dest, entry.FullName));
						if(!File.Exists(destinationPath))
							entry.ExtractToFile(destinationPath);
					}
				}
			}
		}

		static DataTable ReadFile(string path)
		{
			DataTable dt = new DataTable();
			using (StreamReader sr = new StreamReader(path, Encoding.GetEncoding("Big5")))
			{
				foreach (string header in relatedColumns)
				{
					dt.Columns.Add(header);
				}
				while (!sr.EndOfStream)
				{
					List<string> rows = sr.ReadLine().Split(',').ToList();
					DataRow dr = dt.NewRow();
					for (int i = 0; i < relatedColumns.Length; i++)
					{
						if (i < rows.Count())
							dr[i] = rows[i];
						else
							dr[i] = "0";
					}
					dt.Rows.Add(dr);
				}
			}
			return dt;
		}

		static void SaveToCSV(DataTable oTable, string FilePath)
		{
			string data = "";
			StreamWriter wr = new StreamWriter(FilePath, false, Encoding.GetEncoding("Big5"));
			foreach (DataColumn column in oTable.Columns)
			{
				data += column.ColumnName + ",";
			}
			data += "\n";
			wr.Write(data);
			data = "";

			foreach (DataRow row in oTable.Rows)
			{
				foreach (DataColumn column in oTable.Columns)
				{
					data += row[column].ToString().Trim() + ",";
				}
				data += "\n";
				wr.Write(data);
				data = "";
			}
			data += "\n";
			wr.Dispose();
			wr.Close();
		}

		static DataTable SumVolume(string today)
		{
			DataTable dt = new DataTable();
			dt.Columns.Add("DateTime");
			dt.Columns.Add("Date");
			dt.Columns.Add("Time");
			dt.Columns.Add("Volume");
			foreach (string s in timeInterval)
			{
				DataRow newRow = dt.NewRow();
				if(s.Substring(2,2) == "45" || s.Substring(0, 1) != "0")
				{
					newRow["DateTime"] = DateTime.ParseExact(today + " " + s.Substring(0, 2) + ":" + s.Substring(2, 2), "yyyyMMdd HH:mm"
						,System.Globalization.CultureInfo.InvariantCulture);
					newRow["Date"] = today;
					newRow["Time"] = s.Substring(0, 2) + s.Substring(2, 2);
				}
				else
				{
					newRow["DateTime"] = DateTime.ParseExact(today + " " + s.Substring(0, 2) + ":" + s.Substring(2, 2), "yyyyMMdd HH:mm"
						, System.Globalization.CultureInfo.InvariantCulture);
					newRow["Date"] = today;
					newRow["Time"] = s.Substring(0, 2) + s.Substring(2, 2);
				}
				newRow["Volume"] = 0;
				dt.Rows.Add(newRow);
			}
			return dt;		
		}

		static DateTime CheckTimeInterval(string time, string today)
		{
			DateTime dateTime = new DateTime();
			var timeFind = timeInterval.Where(e => e.Substring(0, 2) == time.Substring(0, 2));
			string timeSelect;
			if (timeFind.Count() > 0)
			{
				timeSelect = timeFind.ToList()[0].ToString();
				if (timeSelect.Substring(2, 2) == "45")
				{
					if (time.Substring(2, 2) != "00" && int.Parse(time.Substring(2, 2).TrimStart('0')) >= 45)
						dateTime = DateTime.ParseExact(today + " " + timeSelect.Substring(0, 2) + ":" + timeSelect.Substring(2, 2), "yyyyMMdd HH:mm"
							, System.Globalization.CultureInfo.InvariantCulture);
					else
						dateTime = DateTime.ParseExact(today + " " + (int.Parse(timeSelect.Substring(0, 2).TrimStart('0')) - 1).ToString().PadLeft(2, '0') + ":" + timeSelect.Substring(2, 2), "yyyyMMdd HH:mm"
							, System.Globalization.CultureInfo.InvariantCulture);
				}
				else if (timeSelect.Substring(0, 1) == "0")
				{
					dateTime = DateTime.ParseExact(today + " " + time.Substring(0, 2) + ":" + "00", "yyyyMMdd HH:mm"
						, System.Globalization.CultureInfo.InvariantCulture);
				}
				else
				{
					dateTime = DateTime.ParseExact(today + " " + time.Substring(0, 2) + ":" + "00", "yyyyMMdd HH:mm"
						, System.Globalization.CultureInfo.InvariantCulture);
				}
			}
			else
			{
				dateTime = DateTime.ParseExact(today + " " + "06" + ":" + "00", "yyyyMMdd HH:mm"
							, System.Globalization.CultureInfo.InvariantCulture);
			}
			return dateTime;
		}

		static void Main(string[] args)
		{
			try
			{
				DataTable result = InitializeResultTable();
				SqlConnection testEDIS = new SqlConnection("Data Source=10.19.1.45;Initial Catalog=testEDIS;User ID=sa;Password=dw910770");

				for (int i = 1; i < 2; i++)
				{
					//int day = 0;
					//int night = 0;
					today = DateTime.Today.AddDays(i * -1).ToString("yyyyMMdd");//TradeDate.LastNTradeDate(i).ToString("yyyyMMdd");//"20180831"//
																				//yesterday = TradeDate.LastNTradeDate(i+1).ToString("yyyyMMdd");//"20180831"//
					Console.WriteLine($"Insert OptionVolumeByTime {today}");
					//Console.ReadLine();
					DataTable sumVolume = SumVolume(today);
					string txtfilepath = $".\\{today}";
					string zipfilepath = $"\\\\10.19.1.149\\TickViewerData\\Price\\{today}";
					Console.WriteLine($"Unzip {today} Data...");
					Regex filepattern = new Regex("TXO[0-9]{5}[A-Z]{1}[0-9]{1}.zip|TX1[0-9]{5}[A-Z]{1}[0-9]{1}.zip|TX2[0-9]{5}[A-Z]{1}[0-9]{1}.zip|TX4[0-9]{5}[A-Z]{1}[0-9]{1}.zip|TX5[0-9]{5}[A-Z]{1}[0-9]{1}.zip");
					var zipfiles = from dir in Directory.EnumerateFiles(zipfilepath)
								   where filepattern.IsMatch(dir)
								   select dir;
					Console.WriteLine(zipfiles.Count());
					if (zipfiles.Count() == 0)
						continue;

					Directory.CreateDirectory(txtfilepath);
					foreach (string zip in zipfiles)
					{
						Zipcompress(zip, txtfilepath);
						//Console.WriteLine(zip);
					}
					Console.WriteLine($"Read {today} txt file...");
					var txtfiles = from dir in Directory.EnumerateFiles(txtfilepath)
								   select dir;
					//Console.WriteLine(txtfiles.Count());
					foreach (string txt in txtfiles)
					{
						Console.WriteLine(txt);
						int value;
						var dr = ReadFile(txt).AsEnumerable().Where(r => int.TryParse(r["LastQ"].ToString(), out value) == true && r["LastQ"].ToString() != "0");
						if (dr.Count() == 0)
							continue;
						foreach (DataRow row in dr)
						{
							int rowIndex;
							Console.WriteLine(row["MatchTime"].ToString());
							DateTime temp = CheckTimeInterval(row["MatchTime"].ToString(), today);
							if (temp == DateTime.ParseExact(today + " " + "06" + ":" + "00", "yyyyMMdd HH:mm", System.Globalization.CultureInfo.InvariantCulture))
								continue;
							Console.WriteLine(CheckTimeInterval(row["MatchTime"].ToString(), today));
							var selectRow = sumVolume.Select($"DateTime = '{temp}'");
							if (selectRow.Count() > 0)
								rowIndex = sumVolume.Rows.IndexOf(sumVolume.Select($"DateTime = '{temp}'")[0]);
							else
								continue;
							Console.WriteLine(sumVolume.Rows[rowIndex]["Volume"]);
							Console.WriteLine(row["LastQ"].ToString());
							sumVolume.Rows[rowIndex]["Volume"] = int.Parse(sumVolume.Rows[rowIndex]["Volume"].ToString()) + int.Parse(row["LastQ"].ToString());
							/*
							if (temp.ToString("HH:mm").Substring(3,2) == "45")
								day += int.Parse(row["LastQ"].ToString());
							else
								night += int.Parse(row["LastQ"].ToString());
							*/
							Console.WriteLine(sumVolume.Rows[rowIndex]["Volume"].ToString());
							//Console.WriteLine("day: " + day);
							//Console.WriteLine("night: " + night);
							//Console.ReadLine();
						}
					}

#if !DEBUG
					foreach (DataRow row in sumVolume.Rows)
					{
						string dateTime = DateTime.Parse(row[0].ToString()).ToString("yyyy/MM/dd HH:mm:ss");
						string sqlInsert = $"Insert OptionVolumeByTime Values( '{dateTime}', '{row[1]}', '{row[2].ToString()}', '{row[3].ToString()}')";
						MSSQL.ExecSqlCmd(sqlInsert, testEDIS);
					}
#endif
					Utility.SaveToCSV(sumVolume, $".\\{today}.csv", true);
					//result.Merge(sumVolume);
					Directory.Delete($".\\{today}", true);
				}
				//Utility.SaveToCSV(result, ".\\result.csv", true);
			}
			catch (Exception e)
			{
				MailService ms = new MailService();
				ms.SendMail("jerry.zeng@kgi.com", "10.19.1.45", new string[] { "jerry.zeng@kgi.com" }, null, null, "OptionVolumeByTime Fail", e.Message, false, null);
			}
		}
	}
}
