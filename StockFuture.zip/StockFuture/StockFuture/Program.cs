﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Net;
using System.Data;
using System.Data.SqlClient;
using EDLib;
using EDLib.SQL;
using System.IO;

namespace FutBrokerData
{
	class Program
	{
		static string todayStr = TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");
		
		static List<DataTable> ReadFile(string path)
		{
			int line = File.ReadLines(path).Count();
			//Console.WriteLine(line);
			int linecount = 0;
			int count;
			List<DataTable> futData = new List<DataTable>();
			DataTable dt = new DataTable();
			using (StreamReader sr = new StreamReader(path, Encoding.GetEncoding("Big5")))
			{
				while (!sr.EndOfStream)
				{
					linecount = linecount + 1;
					string[] rows = sr.ReadLine().Split(',');
					//Console.WriteLine(rows[0]);
					//Console.WriteLine(linecount);
					//Console.ReadLine();
					DataRow dr;
					if (rows[0]!= "" && rows[0].ToString() != "期貨商代號")
					{
						dr = dt.NewRow();
						for (int i = 0; i < rows.Length; i++)
						{
							dr[i] = rows[i];
						}
						dt.Rows.Add(dr);
						if(linecount == line)
							futData.Add(dt);
					}
					else if ((rows[0]== "" && dt.Rows.Count != 0))
					{
						futData.Add(dt);
						dt = new DataTable();
						count = 0;
					}
					else if(rows[0].ToString() == "期貨商代號")
					{
						count = 0;
						foreach (string header in rows)
						{
							dt.Columns.Add($"{header}{count}");
                            count += 1;
						}
					}				
				}
			}
			return futData;
		}

		static void SaveToCSV(DataTable oTable, string FilePath)
		{
			string data = "";
			StreamWriter wr = new StreamWriter(FilePath, false, Encoding.GetEncoding("Big5"));
			foreach (DataColumn column in oTable.Columns)
			{
				data += column.ColumnName + ",";
			}
			data += "\n";
			wr.Write(data);
			data = "";

			foreach (DataRow row in oTable.Rows)
			{
				foreach (DataColumn column in oTable.Columns)
				{
					data += row[column].ToString().Trim() + ",";
				}
				data += "\n";
				wr.Write(data);
				data = "";
			}
			data += "\n";
			wr.Dispose();
			wr.Close();
		}

		static DataTable InitializeTables()
		{
			DataTable dt = new DataTable();
			dt.Columns.Add("TDate", typeof(string));
			dt.Columns.Add("BrokerID", typeof(string));
			dt.Columns.Add("BrokerName", typeof(string));
			dt.Columns.Add("FutureID", typeof(string));
			dt.Columns.Add("Qty", typeof(double));
			return dt;
		}

		static DataTable InitializeTablesAll()
		{
			DataTable dt = new DataTable();
			dt.Columns.Add("TDate", typeof(string));
			dt.Columns.Add("BrokerID", typeof(string));
			dt.Columns.Add("BrokerName", typeof(string));
			dt.Columns.Add("FutureID", typeof(string));
			dt.Columns.Add("DayQty", typeof(double));
			dt.Columns.Add("NightQty", typeof(double));
			dt.Columns.Add("TotalQty", typeof(double));
			return dt;
		}

		static void Main(string[] args)
		{
			try
			{
				//抓期交所資料(期貨日盤與全部)
				Console.WriteLine($"Insert {todayStr} FutureVolume Data...");
				WebClient wc = new WebClient();
				wc.DownloadFile("http://www.taifex.com.tw/cht/7/getFCMFile?filename=Daily_FUT_day.csv",
				$".\\FutBrokerDay{todayStr.Substring(0, 6)}Raw.csv");

				wc.DownloadFile("http://www.taifex.com.tw/cht/7/getFCMFile?filename=Daily_FUT.csv",
				$".\\FutBrokerAll{todayStr.Substring(0, 6)}Raw.csv");
				SqlConnection testEDIS = new SqlConnection("Data Source=10.19.1.45;Initial Catalog=testEDIS;User ID=sa;Password=dw910770");

				List<DataTable> futBrokerAll = ReadFile($".\\FutBrokerAll{todayStr.Substring(0, 6)}Raw.csv");
				List<DataTable> futBroker = ReadFile($".\\FutBrokerDay{todayStr.Substring(0, 6)}Raw.csv");
				List<string> DateList = new List<string>();
				int[] allDateIndex;
				DataTable result;
				DataTable dtComAll = new DataTable();
				DataTable dtComDay = new DataTable();
				//SaveToCSV(futBrokerAll[0], ".\\FutBrokerDataTest0.csv");
				//SaveToCSV(futBrokerAll[1], ".\\FutBrokerDataTest1.csv");

				foreach (DataTable dt in futBrokerAll)
				{
					string[] date = string.Join(",", dt.AsEnumerable().Where(r => r["期貨商代號0"].ToString() == "Date").ToArray()[0].ItemArray).Split(',');
					foreach (string s in date)
						if (s != "" && s != "Date" && s.Substring(1, 4) == todayStr.Substring(1, 4))
							DateList.Add(s);
				}

				foreach (DataTable dt in futBrokerAll)
				{
					var Date = dt.AsEnumerable().First().ItemArray;
					allDateIndex = Date.Select((r, i) => r.ToString().Contains(todayStr.Substring(0, 6)) ||
															r.ToString().Contains("99999999") ? i : -1).Where(i => i != -1).ToArray();
					int[] dateIndex = { allDateIndex[allDateIndex.Length - 2], allDateIndex[allDateIndex.Length - 1] };
					result = InitializeTables();
					for (int i = 1; i < dt.Rows.Count; i++) // # of Rows
					{
						for (int j = 0; j < allDateIndex.Length - 1; j++)// dateIndex
						{
							for (int k = allDateIndex[j]; k < allDateIndex[j + 1] - 1; k++) // dateInterval
							{
								DataRow newRow = result.NewRow();
								string TDate = dt.Rows[0][allDateIndex[j]].ToString();
								string BrokerID = dt.Rows[i][0].ToString();
								string BrokerName = dt.Rows[i][1].ToString();
								string FutureID = Regex.Replace(dt.Columns[k].ColumnName.ToString(), @"\d+$", string.Empty);
								double Qty = double.Parse(dt.Rows[i][k].ToString());
								newRow["TDate"] = TDate;
								newRow["BrokerID"] = BrokerID;
								newRow["BrokerName"] = BrokerName;
								newRow["FutureID"] = FutureID;
								newRow["Qty"] = Qty;
								result.Rows.Add(newRow);
							}
						}
					}
					dtComAll.Merge(result);
				}

				foreach (DataTable dt in futBroker)
				{
					var Date = dt.AsEnumerable().First().ItemArray;
					allDateIndex = Date.Select((r, i) => r.ToString().Contains(todayStr.Substring(0, 6)) ||
															r.ToString().Contains("99999999") ? i : -1).Where(i => i != -1).ToArray();
					int[] dateIndex = { allDateIndex[allDateIndex.Length - 2], allDateIndex[allDateIndex.Length - 1] };
					result = InitializeTables();
					for (int i = 1; i < dt.Rows.Count; i++) // # of Rows
					{
						for (int j = 0; j < allDateIndex.Length - 1; j++)// dateIndex
						{
							for (int k = allDateIndex[j]; k < allDateIndex[j + 1] - 1; k++) // dateInterval
							{
								DataRow newRow = result.NewRow();
								string TDate = dt.Rows[0][allDateIndex[j]].ToString();
								string BrokerID = dt.Rows[i][0].ToString();
								string BrokerName = dt.Rows[i][1].ToString();
								string FutureID = Regex.Replace(dt.Columns[k].ColumnName.ToString(), @"\d+$", string.Empty);
								double Qty = double.Parse(dt.Rows[i][k].ToString());
								newRow["TDate"] = TDate;
								newRow["BrokerID"] = BrokerID;
								newRow["BrokerName"] = BrokerName;
								newRow["FutureID"] = FutureID;
								newRow["Qty"] = Qty;
								result.Rows.Add(newRow);
							}
						}
					}
                    dtComDay.Merge(result);
                }

				Utility.SaveToCSV(dtComAll, ".\\FutBrokerDataFinalAll.csv", true);
				Utility.SaveToCSV(dtComDay, ".\\FutBrokerDataFinalDay.csv", true);

				//合併期貨日盤與全部的資料
				var finalresult = from row1 in dtComAll.AsEnumerable()
								  join row2 in dtComDay.AsEnumerable() on
								  new { TDate = row1.Field<string>("TDate"), BrokerID = row1.Field<string>("BrokerID"), FutureID = row1.Field<string>("FutureID") }
								  equals
								  new { TDate = row2.Field<string>("TDate"), BrokerID = row2.Field<string>("BrokerID"), FutureID = row2.Field<string>("FutureID") }
								  into temp
								  from row2 in temp.DefaultIfEmpty()
								  select new
								  {
									  TDate = row1.Field<string>("TDate"),
									  BrokerID = row1.Field<string>("BrokerID"),
									  BrokerName = row1.Field<string>("BrokerName"),
									  FutureID = row1.Field<string>("FutureID"),
									  AllQty = row1.Field<double>("Qty"),
									  DayQty = row2.Field<double>("Qty"),
								  };
				DataTable futBrokerVolumeData = InitializeTablesAll();

				//全部扣掉日盤即為夜盤
				foreach (var row in finalresult)
				{
					DataRow newRow = futBrokerVolumeData.NewRow();
					newRow["TDate"] = row.TDate;
					newRow["BrokerID"] = row.BrokerID;
					newRow["BrokerName"] = row.BrokerName;
					newRow["FutureID"] = row.FutureID;
					newRow["DayQty"] = row.DayQty;
					newRow["NightQty"] = row.AllQty - row.DayQty;
					newRow["TotalQty"] = row.AllQty;
					futBrokerVolumeData.Rows.Add(newRow);
#if !DEBUG
					if (row.TDate == todayStr)
					{
						string sqlInsert = $"Insert FutureVolume Values( '{row.TDate}', '{row.BrokerID}', " +
							$"'{row.BrokerName}', '{row.FutureID}', {row.DayQty}, {row.AllQty} - {row.DayQty}, {row.AllQty})";
						MSSQL.ExecSqlCmd(sqlInsert, testEDIS);
					}
#endif
				}
				testEDIS.Close();
				Utility.SaveToCSV(futBrokerVolumeData, ".\\FutdataDayNight.csv", true);
			}
			catch (Exception e)
			{
				MailService ms = new MailService();
				ms.SendMail("lecheng@kgi.com", "10.19.1.45", new string[] { "lecheng@kgi.com" }, null, null, "FutureVolume Fail", e.Message, false, null);
			}
		}
	}
}
