﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using EDLib;
using EDLib.SQL;
using System.IO.Compression;

namespace StockPriceForWarrnatOverSold
{
	class Program
	{
		static string[] relatedColumns = {"CommodityId", "CommodityNm", "MatchTime", "LastP", "LastQ", "TotalQ", "Bid1P", "Bid1Q",
				"Ask1P", "Ask1Q", "UnderlyingId", "Kind", "InformationSeq", "InformationTime", "MatchSeq",
				"Bid2P", "Bid2Q", "Ask2P", "Ask2Q", "Bid3P", "Bid3Q", "Ask3P", "Ask3Q", "Bid4P", "Bid4Q", "Ask4P", "Ask4Q",
				"Bid5P", "Bid5Q", "Ask5P", "Ask5Q", "Maturity", "Strike", "RecTime" };

		static string timeControl;

		static int[] seconds = { 0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55 };

		static void Zipcompress(string source, string dest)
		{
			if (File.Exists(source))
			{
				using (ZipArchive archive = ZipFile.OpenRead(source))
				{
					foreach (ZipArchiveEntry entry in archive.Entries)
					{
						if (entry.FullName.EndsWith(".txt", StringComparison.OrdinalIgnoreCase))
						{
							string destinationPath = Path.GetFullPath(Path.Combine(dest, entry.FullName));
							if (!File.Exists(destinationPath))
								entry.ExtractToFile(destinationPath);
						}
					}
				}
			}
		}

		static DataTable ReadFile(string path)
		{
			DataTable dt = new DataTable();
			if (File.Exists(path))
			{
				using (StreamReader sr = new StreamReader(path, Encoding.GetEncoding("Big5")))
				{
					foreach (string header in relatedColumns)
					{
						dt.Columns.Add(header);
					}
					while (!sr.EndOfStream)
					{
						List<string> rows = sr.ReadLine().Split(',').ToList();
						DataRow dr = dt.NewRow();
						for (int i = 0; i < relatedColumns.Length; i++)
						{
							if (i < rows.Count())
							{
								if (i != relatedColumns.Length - 1)
									dr[i] = rows[i];
								else
									dr[i] = rows[i].Replace(":", "").Replace(".", "");
							}
							else
								dr[i] = "0";
						}
						dt.Rows.Add(dr);
					}
				}
			}
			return dt;
		}

		public static DataTable UOversold(string sqlqry, SqlConnection conn)
		{
			DataTable uTable;
			uTable = new DataTable();
			SqlCommand cmd = new SqlCommand(sqlqry, conn)
			{
				CommandTimeout = 300
			};
			SqlDataAdapter da = new SqlDataAdapter(cmd);
			da.Fill(uTable);
			return uTable;
		}

		static DataTable InitializeTable()
		{
			DataTable dt = new DataTable();
			dt.Columns.Add("TDate");
			dt.Columns.Add("Time");
			dt.Columns.Add("UID");
			dt.Columns.Add("OversoldAmount");
			dt.Columns.Add("LastP");
			dt.Columns.Add("LastQ");
			return dt;
		}

		static void Main(string[] args)
		{
			try
			{
				for (int i = 1; i < 2; i++)
				{
					DataTable summary = InitializeTable();
					//抓前日程式單賣超
					string beforeydate = TradeDate.LastNTradeDate(i + 1).ToString("yyyyMMdd");
					//抓昨日股價(前日程式單賣超，來看昨日股價變化)
					string ydate = TradeDate.LastNTradeDate(i).ToString("yyyyMMdd");
					Console.WriteLine(beforeydate);

					SqlConnection conn = new SqlConnection("Data Source= 10.19.1.45;Initial Catalog=newEDIS;User=sa;Password=dw910770");
					SqlConnection conntest = new SqlConnection("Data Source= 10.19.1.45;Initial Catalog=testEDIS;User=sa;Password=dw910770");

					//抓前15大Call程式單賣超金額
					string sqlqry = "Select TOP (15) ISNULL(C.TDate, F.TDate) as TDate, ISNULL(C.UID, F.UID) as UID, ISNULL(C.ProgrammingSellingAmount, 0) as SellingAmount, ISNULL(F.ProgrammingBuyingAmount, 0) as BuyingAmount " +
						", ISNULL(F.ProgrammingBuyingAmount, 0) - ISNULL(C.ProgrammingSellingAmount, 0) as OversoldAmount from " +
						" (SELECT cast(D.TDate as Date) as TDate, E.UID , SUM(D.LastPx* D.LastQty) as ProgrammingBuyingAmount FROM [newEDIS].[dbo].[WarrantTradingBroker] as D left join WarrantTrading as E on cast(D.TDate as Date) = E.TDate and D.WID = E.WID " +
					  $" where cast(D.TDate as Date) = '{beforeydate}' and RanOver<> 'Normal' and BrokerSellFlag = 'MM' and E.WClass = 'c' " +
						" and E.UID in (SELECT [Underlying] FROM [10.60.0.37].[TsQuote].[dbo].[CodeMap] where ProdKind = 'S' and CommodityKind = 'Future') " +
						" group by cast(D.TDate as Date), E.UID) as F left join" +
						" (SELECT cast(A.TDate as Date) as TDate, B.UID, SUM(A.LastPx * A.LastQty) as ProgrammingSellingAmount FROM [newEDIS].[dbo].[WarrantTradingBroker] as A left join WarrantTrading as B on cast(A.TDate as Date) = B.TDate and A.WID = B.WID " +
					  $" where cast(A.TDate as Date) = '{beforeydate}' and RanOver <> 'Normal' and BrokerBuyFlag = 'MM' and B.WClass = 'c' " +
						" and B.UID in (SELECT [Underlying] FROM [10.60.0.37].[TsQuote].[dbo].[CodeMap] where ProdKind = 'S' and CommodityKind = 'Future') group by cast(A.TDate as Date), B.UID) as C" +
						" on C.UID = F.UID order by ISNULL(F.ProgrammingBuyingAmount, 0) - ISNULL(C.ProgrammingSellingAmount, 0) desc";

					DataTable uOversold = UOversold(sqlqry, conn);
					//Utility.SaveToCSV(uOversold, ".\\u.csv", true);

					foreach (DataRow row in uOversold.Rows)
					{
						string uid = row["UID"].ToString();
						Console.WriteLine(uid);
						string source = $"\\\\10.19.1.149\\TickViewerData\\Price\\{ydate}\\{uid}.zip";
						string dest = $".\\";
						Zipcompress(source, dest);
						DataTable uTable = ReadFile($".\\{uid}.txt");
						if (uTable.Rows.Count == 0)
							continue;
						File.Delete($".\\{uid}.txt");

						EnumerableRowCollection<DataRow> temp;

						//先找我們自己紀錄的時間，若有空值則找交易所的時間
						if (uTable.AsEnumerable().Where(r => r["RecTime"].ToString() == "").Count() == 0)
						{
							timeControl = "RecTime";
							temp = uTable.AsEnumerable().Where(r => r["RecTime"].ToString().Substring(0, 2) == "09" && int.Parse(r["RecTime"].ToString().Substring(2, 2)) >= 0
								&& int.Parse(r["RecTime"].ToString().Substring(2, 2)) <= 30);
						}
						else
						{
							timeControl = "MatchTime";
							temp = uTable.AsEnumerable().Where(r => r["MatchTime"].ToString().Substring(0, 2) == "09" && int.Parse(r["MatchTime"].ToString().Substring(2, 2)) >= 0
								&& int.Parse(r["MatchTime"].ToString().Substring(2, 2)) <= 30);
						}

						if (temp.Count() == 0)
							continue;

						//取每五秒一筆的成交價格(09:00~09:30)

						for (int j = 0; j < 31; j++)
						{
							//Console.WriteLine(j);							
							var minuteTable = temp.Where(r => int.Parse(r[timeControl].ToString().Substring(2, 2)) == j
								&& r["LastP"].ToString() != "0" && r["LastQ"].ToString() != "0");

							if (minuteTable.Count() > 0)
							{
								foreach(int k in seconds)
								{
									List<DataRow> subtemp = minuteTable.AsEnumerable().Where(r => int.Parse(r[timeControl].ToString().Substring(4, 2)) >= k && int.Parse(r[timeControl].ToString().Substring(4, 2)) < k+5).ToList();
									if(subtemp.Count > 0)
									{
										DataRow newRow = summary.NewRow();
										newRow["TDate"] = beforeydate;
										newRow["Time"] = "09:" + j.ToString().PadLeft(2, '0') + ":" + k.ToString().PadLeft(2, '0');
										newRow["UID"] = uid;
										newRow["OversoldAmount"] = row["OversoldAmount"].ToString();
										newRow["LastP"] = subtemp[0]["LastP"].ToString();
										newRow["LastQ"] = subtemp[0]["LastQ"].ToString();
										summary.Rows.Add(newRow);
									}
								}
							}
						}
					}
					Utility.SaveToCSV(summary, ".\\s.csv", true);
#if !DEBUG
					foreach (DataRow row in summary.Rows)
					{
						string date = row["TDate"].ToString().Substring(0,4) + "-" + row["TDate"].ToString().Substring(4, 2) + "-" + row["TDate"].ToString().Substring(6, 2);
						string sqlInsert = $"Insert WarrantOversold Values( '{date}', '{row["Time"]}', '{row["UID"]}', '{row["OversoldAmount"]}', '{row["LastP"]}', '{row["LastQ"]}')";
						MSSQL.ExecSqlCmd(sqlInsert, conntest);
					}
#endif
				}
			}
			catch (Exception e)
			{
			MailService ms = new MailService();
				ms.SendMail("jerry.zeng@kgi.com", "10.19.1.45", new string[] { "jerry.zeng@kgi.com" }, null, null, "WarrantOversold", e.Message, false, null);
			}
		}
	}
}
