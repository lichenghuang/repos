﻿using System;
using System.Linq;
using EDLib;
using EDLib.SQL;
using System.Data;
using System.Data.SqlClient;

namespace ETFVolume
{
	class Program
	{
		static DataTable summary;

		static string lastTDate = TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");//"20170713";//

		static void Main(string[] args)
		{
			//for (int i = 991; i >= 1; i--)
			//{
			//lastTDate = TradeDate.LastNTradeDate(i).ToString("yyyyMMdd");//"20140923";//
			Console.WriteLine(lastTDate);
			try
			{
			string sqlStr = "SELECT 日期, 股票代號, 股票名稱, 成交量, [成交金額(千)] * 1000 as 成交金額 from 日收盤表排行 "
			+ $" where 日期 = '{lastTDate}' and 股票代號 in (SELECT 股票代號 from ETF基本資料表 where 年度='{lastTDate.Substring(0, 4)}')";

				summary = CMoney.ExecCMoneyQry(sqlStr);

				Utility.SaveToCSV(summary, ".\\etfVolume.csv", true);
#if !DEBUG
					using (SqlConnection conn = new SqlConnection("Data Source=10.19.1.45;Initial Catalog=testEDIS;User ID=sa;Password=dw910770"))
					{
						conn.Open();
						MSSQL.ExecSqlCmd($"DELETE FROM ETFVolume WHERE TDate>='{lastTDate}' and TDate<='{lastTDate} 23:59'", conn);
						Console.WriteLine($"Inserting ETFVolume of {lastTDate}");
						foreach (DataRow row in summary.Rows)
						{
							string SQLcmd = $@"Insert into ETFVolume(TDate, ETFID,  ETFName, Volume, Amount) Values("
									+ $"'{row[0].ToString()}','{row[1].ToString()}', '{row[2].ToString()}', {row[3].ToString()}, {row[4].ToString()})";
						   //Console.WriteLine(SQLcmd);
						    MSSQL.ExecSqlCmd(SQLcmd, conn);
						}
					}
#endif
			}
			catch (Exception e)
			{
				//Console.ReadLine();
				MailService ms = new MailService();
				ms.SendMail("jerry.zeng@kgi.com", "10.19.1.45 ERROR", new string[] { "jerry.zeng@kgi.com" }, null, null, $"{lastTDate}ETFTradingVolume ERROR!", e.ToString(), false, null);
			}
			//}
		}
	}
}

