import pandas as pd
from os import listdir
from os.path import join

statpath = 'C:/Users/user/Desktop/taifex-parser-master/futuresData'
statfiles = listdir(statpath)
important=pd.DataFrame(columns=['日期','期貨商名稱','標的','是否交易','次數'])

for f in statfiles:
    statfullpath= join(statpath,f)
    practice=pd.read_csv(statfullpath,encoding='cp950',sep=",",header=0)
    corp=practice.groupby('期貨商名稱')
    date=practice['交易日期'].loc[1]
    size=practice.groupby('契約名稱').size()
    size=pd.DataFrame(size)
    size.columns=['交易次數']
    for i in corp:
        firm=i[0]
        a=i[1]
        b=a.groupby('契約名稱').size()
        temp=pd.DataFrame(b)
        temp.columns=[firm]
        print(firm)
        print(practice['交易日期'].loc[1])
        print('\n')            
        size=size.join(temp)
        firm=size.columns
        target=size.index
    for j in target:
        for h in firm.drop('交易次數'):
            if pd.isnull(size[h][j]) == False:                                            
                TON=pd.DataFrame({'日期':str(practice['交易日期'].loc[1]),
                                  '期貨商名稱':h,'標的':j,'是否交易':'是',
                                  '次數':size[h][j]},index=[0])
                temp=pd.DataFrame(TON)
                frames = [important,TON]  
                important=pd.concat(frames)
            if pd.isnull(size[h][j]) == True :
                TONO = pd.DataFrame({'日期':str(practice['交易日期'].loc[1]),
                                     '期貨商名稱':h,'標的':j,'是否交易':'否',
                                     '次數':'0'},index=[0])
                temp=pd.DataFrame(TONO)
                frames = [important,TONO]   
                important=pd.concat(frames)
important.to_csv('C:/Users/user/Desktop/taifex-parser-master/TradeOrNot.csv',encoding="cp950",index = False)
        
                    
                    
                    
                    
                
            
    
    
    

    
        
   

    
    
    
    
    
        
    
    










    

  
    










 




