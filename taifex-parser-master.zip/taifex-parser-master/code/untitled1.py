import rfc6266
import requests
import shutil
from bs4 import BeautifulSoup
import pandas as pd
import os
import time
from os import listdir
from os.path import join
import captchaSolver
import calendar
from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta
import math 
import numpy as np
import random





important=pd.DataFrame(columns=['日期','期貨商名稱','標的','是否交易','次數','買進','賣出'])
path = 'C:/Users/user/Desktop/taifex-parser-master/futuresData'
files = listdir(path)
for f in files:
    fullpath = join(path,f)
    futures = pd.read_csv(fullpath,encoding="CP950",sep="," , header=0, error_bad_lines=False)
    tradedate = str(futures['交易日期'][1])
    Year = int(tradedate[0:4])
    Month = int(tradedate[4:6])
    Day = int (tradedate[6:8])
    Settlement = calendar.Calendar(2).monthdatescalendar(Year,Month)[3][0]
    today = date(Year,Month,Day)
    if  (today > Settlement) == True:
        far = Settlement + relativedelta(months=2)
        farmonth =  int(str(far)[0:4]+str(far)[5:7])
    else:
        far = Settlement + relativedelta(months=1)
        farmonth = int(str(far)[0:4]+str(far)[5:7])
    
    futures['translate'] = ((futures['到期月份'] == farmonth) & (futures['成交價格'] != np.ceil(futures['成交價格'])))
    practice = futures[futures['translate'] == False]
    
    corp=practice.groupby('期貨商名稱')
    size=practice.groupby('契約名稱').size()
    size=pd.DataFrame(size)
    size.columns=['交易次數']
    times = practice.groupby(['期貨商名稱','買進/賣出','契約名稱']).size()
    times = pd.DataFrame(times)
    
    for i in corp:
        firm=i[0]
        a=i[1]
        b=a.groupby('契約名稱').size()
        temp=pd.DataFrame(b)
        temp.columns=[firm]
        print(firm)
        print(tradedate)
        print('\n')            
        size=size.join(temp)
        firm=size.columns
        target=size.index
        count=practice.drop(columns=['到期月份','成交價格'])
    for j in target:
        for h in firm.drop('交易次數'):
            if pd.isnull(size[h][j]) == False:
                a=times.loc[h,'買進',j][0] if(h,'買進',j) in times.index else 0
                b=times.loc[h,'賣出',j][0] if(h,'賣出',j) in times.index else 0
                TON=pd.DataFrame({'日期':tradedate,'期貨商名稱':h,'標的':j,
                                  '是否交易':'是','次數':size[h][j],'買進':a,
                                  '賣出':b},index=[0])
                temp=pd.DataFrame(TON)
                frames = [important,TON]  
                important=pd.concat(frames)                    
            else:
                TONO = pd.DataFrame({'日期':tradedate,'期貨商名稱':h,'標的':j,
                                     '是否交易':'否','次數':'0','買進':'0',
                                     '賣出':'0'},index=[0])
                temp=pd.DataFrame(TONO)
                frames = [important,TONO]   
                important=pd.concat(frames)               
                
                
important.to_csv('C:/Users/user/Desktop/taifex-parser-master/test.csv',encoding="cp950",index = False)