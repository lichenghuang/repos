import pandas as pd
from os import listdir
from os.path import join

statpath = 'C:/Users/user/Desktop/taifex-parser-master/optionData'
statfiles = listdir(statpath)
important=pd.DataFrame(columns=['日期','期貨商名稱','標的','是否交易','次數','買進','賣出'])
for f in statfiles:
    statfullpath= join(statpath,f)
    practice=pd.read_csv(statfullpath,encoding='cp950',sep=",",header=0)
    corp=practice.groupby('期貨商名稱')
    date=practice['交易日期'].loc[1]
    size=practice.groupby('契約名稱').size()
    size=pd.DataFrame(size)
    size.columns=['交易次數']
    times = practice.groupby(['期貨商名稱','買進/賣出','契約名稱']).size()
    times=pd.DataFrame(times)
    
    for i in corp:
        firm=i[0]
        a=i[1]
        b=a.groupby('契約名稱').size()
        temp=pd.DataFrame(b)
        temp.columns=[firm]
        print(firm)
        print(practice['交易日期'].loc[1])
        print('\n')            
        size=size.join(temp)
        firm=size.columns
        target=size.index
        count=practice.drop(columns=['到期月份','成交價格'])
    for j in target:
        for h in firm.drop('交易次數'):
            if pd.isnull(size[h][j]) == False:
                a=times.loc[h,'買進',j][0] if(h,'買進',j) in times.index else 0
                b=times.loc[h,'賣出',j][0] if(h,'賣出',j) in times.index else 0
                TON=pd.DataFrame({'日期':str(practice['交易日期'].loc[1]),
                                  '期貨商名稱':h,'標的':j,'是否交易':'是',
                                  '次數':size[h][j],'買進':a,'賣出':b},index=[0])
                temp=pd.DataFrame(TON)
                frames = [important,TON]  
                important=pd.concat(frames)                    
            else:
                TONO = pd.DataFrame({'日期':str(practice['交易日期'].loc[1]),
                                     '期貨商名稱':h,'標的':j,'是否交易':'否',
                                     '次數':'0','買進':'0','賣出':'0'},index=[0])
                temp=pd.DataFrame(TONO)
                frames = [important,TONO]   
                important=pd.concat(frames)
important.to_csv('C:/Users/user/Desktop/taifex-parser-master/TradeOrNotiption.csv',encoding="cp950",index = False)