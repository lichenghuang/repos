from os import listdir
from os.path import join
import pandas as pd

path = 'C:/Users/user/Desktop/Option'
files = listdir(path)
fout = open("save.csv","a+")
SaveFile_name=r'save.csv'


for f in files:

    fullpath = join(path,f)
    option = pd.read_csv(fullpath,encoding="cp950",sep="," , header=1)
    information = pd.read_csv(fullpath,encoding="cp950",header=None,error_bad_lines=False)  
    newcol=information[0].str.split(expand=True)
    Date=newcol[0].str.split(':',expand=True).T
    Code=newcol[1].str.split(':',expand=True).T
    Name=newcol[2].str.split(':',expand=True).T
    Maturity=newcol[3].str.split(':',expand=True).T
    Callput=newcol[4].str.split(':',expand=True).T
    option['交易日期']=Date.loc[1,0]
    option['契約代號']=Code.loc[1,0]
    option['契約名稱']=Name.loc[1,0]
    option['到期月份']=Maturity.loc[1,0]
    option['買/賣權']=Callput.loc[1,0]
    
    
    if files[0] == f :        
       option.to_csv(path+'\\'+SaveFile_name,encoding="cp950", index = False , mode='a+')
    else :
       option.to_csv(path+'\\'+SaveFile_name,encoding="cp950", index = False , header= False,mode='a+')
    


