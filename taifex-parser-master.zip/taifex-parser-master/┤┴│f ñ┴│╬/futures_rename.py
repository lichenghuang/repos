from os import listdir
from os.path import join
import pandas as pd

path = 'C:/Users/user/Desktop/FUTURES'
files = listdir(path)
fout = open("all.csv","a+")
SaveFile_name=r'all.csv'


for f in files:

    fullpath = join(path,f)
    futures = pd.read_csv(fullpath,encoding="cp950",sep="," , header=1)
    information = pd.read_csv(fullpath,encoding="cp950",header=None,error_bad_lines=False)  
    newcol=information[0].str.split(expand=True)
    Date=newcol[0].str.split(':',expand=True).T
    Code=newcol[1].str.split(':',expand=True).T
    Name=newcol[2].str.split(':',expand=True).T
    Maturity=newcol[3].str.split(':',expand=True).T
    futures['交易日期']=Date.loc[1,0]
    futures['契約代號']=Code.loc[1,0]
    futures['契約名稱']=Name.loc[1,0]
    futures['到期月份']=Maturity.loc[1,0]
    
    if files[0] == f :        
       futures.to_csv(path+'\\'+SaveFile_name,encoding="cp950", index = False , mode='a+')
    else :
       futures.to_csv(path+'\\'+SaveFile_name,encoding="cp950", index = False , header= False,mode='a+')
    
