﻿using System;
using System.Linq;
using EDLib;
using EDLib.SQL;
using System.Data;
using System.Data.SqlClient;

namespace CMoneyQuery
{
    class Program
    {
        static DataTable summary;
        static DataTable avgVolume;

        static string lastTDate = TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");//"20170713";//

        static DataTable InitializeTables()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("StockNo", typeof(string));
            dt.Columns.Add("StockName", typeof(string));
            dt.Columns.Add("Price", typeof(double));
            dt.Columns.Add("AVGVolume", typeof(double));
            return dt;
        }

        static void Main(string[] args)
        {
            //for (int i = 991; i >= 1; i--)
            //{
            //lastTDate = TradeDate.LastNTradeDate(i).ToString("yyyyMMdd");//"20140923";//
            Console.WriteLine(lastTDate);
            try
            {
                DataTable dt1 = new DataTable();
                DataTable dt2 = new DataTable();
                DataTable dt3 = new DataTable();
                DataTable dt4 = new DataTable();
                //string sqlStr = "SELECT 日期, 股票代號, 股票名稱, 成交量, [成交金額(千)] * 1000 as 成交金額 from 日收盤表排行 "
                //+ $" where 日期 = '{lastTDate}' and 股票代號 in (SELECT 股票代號 from ETF基本資料表 where 年度='{lastTDate.Substring(0, 4)}')";
                string date = DateTime.Today.ToString("yyyyMMdd");//Console.ReadLine();

   

                //string sqlStr = "SELECT A.[年季], A.[股票代號], A.[股票名稱], G.[上市上櫃], G.[產業名稱], F.[收盤價], A.[每股稅後盈餘(元)], E.[流動比率(%)], E.[負債比率(%)], E.[期末股價淨值比], F.[本益比], F.[股價淨值比], "
                //            + " A.[公告基本每股盈餘(元)] as 每股盈餘EPS1, B.[公告基本每股盈餘(元)] as 每股盈餘EPS2, C.[公告基本每股盈餘(元)] as 每股盈餘EPS3, D.[公告基本每股盈餘(元)] as 每股盈餘EPS4, "
                //            + " (A.[公告基本每股盈餘(元)]+B.[公告基本每股盈餘(元)]+C.[公告基本每股盈餘(元)]+D.[公告基本每股盈餘(元)]) as 近四季每股盈餘, "
                //            + " H.[淨值(千)], G.[交易所普通股股本(千)], G.[普通股每股面額(元)], I.[資使用率], J.[全體及其關係人設質比例(%)] from [季IFRS財報(損益單季)] A "
                //            + " left join [季IFRS財報(損益單季)] as B on A.[股票代號] = B.[股票代號]  "
                //            + " left join [季IFRS財報(損益單季)] as C on A.[股票代號] = C.[股票代號]  "
                //            + " left join [季IFRS財報(損益單季)] as D on A.[股票代號] = D.[股票代號]  "
                //            + " left join [季IFRS財報(財務比率)] as E on A.[股票代號] = E.[股票代號]  "
                //            + " left join [日收盤還原表排行] as F on A.[股票代號] = F.[股票代號] "
                //            + " left join [上市櫃公司基本資料] as G on A.[股票代號] = G.[股票代號] "
                //            + " left join [月營收(成長與達成率)] as H on A.[股票代號] = H.[股票代號] "
                //            + " left join [日融資券排行] as I on A.[股票代號] = I.[股票代號] "
                //            + " left join [月董監股權與設質統計表] as J on A.[股票代號] = J.[股票代號] "
                //            + " where A.[年季] = '201803' and B.[年季] = '201802' and C.[年季] = '201801' and D.[年季] = '201704' and E.[年季] = '201803' "
                //            + " and F.[日期]='20190215' and G.[年度]='2019' and H.[年月] = '201901' and I.[日期]='20190215' and J.[年月]='201901' "
                //            + " and (A.[股票代號] in <CM代號,1> or A.[股票代號] in <CM代號,2>) ";

                string sqlStr1 = "SELECT A.[股票代號], A.[股票名稱], AVG(A.[成交量]) as 日均量 from [日收盤還原表排行] A where A.[日期]<='20190219' and A.[日期]>='20190102' and A.[股票代號] in <CM特殊,1>  group by A.[股票代號], A.[股票名稱] order by A.[股票代號] asc";

                //string sqlStr = "SELECT * from [季IFRS財報(財務比率)] A where A.[年季] = '201803' and A.[財報類別]='合併' ";

                //string sqlStr = "SELECT A.[日期],A.[股票代號],A.[股票名稱],A.[券商代號],A.[券商名稱],B.[標的代號],B.[標的名稱],A.[買張],A.[賣張],A.[買均價],A.[賣均價] from [個股券商分點進出明細] A "
                //            + " left join [權證基本資料表] as B on A.股票代號 = B.代號 where B.年度 = '2019' and A.[日期]='20190218' ";

                //string sqlStr = "SELECT TOP 100 * from [個股券商分點進出明細] A ";
                //string sqlStr = "SELECT TOP 100 * from [權證基本資料表] A ";
                string sqlStr = "SELECT A.[股票代號], A.[股票名稱], A.[產業名稱], A.[上市上櫃], A.[實收資本額(百萬)], A.[普通股每股面額(元)] from [上市櫃公司基本資料] A where A.[股票代號] in <CM特殊,2011> and A.[年度]='2019' ";
                //string sqlStr_HighRiskStock = "SELECT * from [上市櫃公司基本資料] A where A.[年度]='2019' and (A.[產業名稱]='生技醫療' or A.[產業名稱]='文化創意' or (A.[股票名稱] like '%KY' and A.[實收資本額(百萬)]/100 < 10.0)) and A.[股票代號] in <CM特殊,2011> ";
                //string sqlStr_Biological = "SELECT * from [上市櫃公司基本資料] A where A.[年度]='2019' and A.[產業名稱]='生技醫療' ";
                //string sqlStr_Cultural = "SELECT * from [上市櫃公司基本資料] A where A.[年度]='2019' and A.[產業名稱]='文化創意' ";
                //string sqlStr_KY = "SELECT * from [上市櫃公司基本資料] A where A.[年度]='2019' and A.[股票名稱] like '%KY' and A.[實收資本額(百萬)]/100 < 10.0 ";
                //string sqlStr = "SELECT TOP 100 * from [月營收(成長與達成率)] A ";
                //string sqlStr = "SELECT * from [權證標的證券(季)] A where A.[年季]='201901' ";
                string sqlStr_Price = "SELECT * from [日收盤還原表排行] A where A.[日期]='20190226' ";
                //string sqlStr = "SELECT TOP 100 * from [日融資券排行] A ";
                //string sqlStr = "SELECT TOP 100 * from [月董監股權與設質統計表] A ";

                dt1 = CMoney.ExecCMoneyQry(sqlStr);
                dt1.Columns.Add("收盤價", typeof(double));
                //dt2 = CMoney.ExecCMoneyQry(sqlStr1);
                //dt3 = CMoney.ExecCMoneyQry(sqlStr_HighRiskStock);
                dt4 = CMoney.ExecCMoneyQry(sqlStr_Price);

                object temp2 = dt4.Select("股票代號='1101'")[0]["收盤價"];
                Console.WriteLine("特定篩選:" + temp2.ToString() + "");


                //object temp2 = dt4.Compute("count(股票代號)", "股票代號='1101'");
                //Console.WriteLine("筆數計算:" + temp2.ToString() + "");

                //object temp2 = dt4.Compute("sum(收盤價)", "");
                //Console.WriteLine("欄位總和計算:" + temp2.ToString() + "");

                //object temp2 = dt4.Compute("avg(收盤價)", "");
                //Console.WriteLine("欄位平均計算:" + temp2.ToString() + "");

                //object temp2 = dt4.Compute("min(收盤價)", "");
                //Console.WriteLine("欄位最小值:" + temp2.ToString() + "");

                //object temp2 = dt4.Compute("max(收盤價)", "");
                //Console.WriteLine("欄位最大值:" + temp2.ToString() + "");

                foreach (DataRow row in dt1.Rows)
                {
                    var temp1 = dt4.Select($"股票代號 = '{row["股票代號"]}'");
                    
                    if (temp1.Length != 0)
                        row["收盤價"] = temp1[0]["收盤價"];
                    else
                        row["收盤價"] = 0;
                }

                //Utility.SaveToCSV(dt1, ".\\權證標的.csv", true);
                //Utility.SaveToCSV(dt4, ".\\日收盤還原表排行.csv", true);
                //Utility.SaveToCSV(dt2, ".\\平均成交量.csv", true);
                //Utility.SaveToCSV(dt3, ".\\HighRiskStock_in_CanIssueWarrantList.csv", true);
                Utility.SaveToCSV(dt1, ".\\標的基本資料.csv", true);

                //合併dt1與dt2的資料

                var finalresult = from row1 in dt1.AsEnumerable()
                                  join row2 in dt2.AsEnumerable() on
                                  row1.Field<string>("股票代號") equals row2.Field<string>("股票代號")
                                  into temp
                                  from row2 in temp.DefaultIfEmpty()
                                  select new
                                  {
                                      StockNo=row1.Field<string>("股票代號"),
                                      StockName=row1.Field<string>("股票名稱"),
                                      Price=row1.Field<double>("收盤價"),
                                      AVGVolume=row2.Field<double>("日均量"),
                                  };

                DataTable futBrokerVolumeData = InitializeTables();
                foreach (var row in finalresult)
                {
                    //Console.WriteLine("StockNo:{0}, StockName:{1}, Section:{2}, Industry:{3}, Price:{4},, AVGVolume:{5}",
                    //    row["股票代號"], row["股票名稱"], row["上市上櫃"], row["產業名稱"], row["收盤價"], row["日均量"]);
                    DataRow newRow = futBrokerVolumeData.NewRow();
                    newRow["StockNo"] = row.StockNo;
                    newRow["StockName"] = row.StockName;
                    newRow["Price"] = row.Price;
                    newRow["AVGVolume"] = row.AVGVolume;
                    futBrokerVolumeData.Rows.Add(newRow);
                }
                Utility.SaveToCSV(futBrokerVolumeData, ".\\合併IFRS_日均量.csv", true);
#if !DEBUG
					using (SqlConnection conn = new SqlConnection("Data Source=10.19.1.45;Initial Catalog=testEDIS;User ID=sa;Password=dw910770"))
					{
						conn.Open();
						MSSQL.ExecSqlCmd($"DELETE FROM ETFVolume WHERE TDate>='{lastTDate}' and TDate<='{lastTDate} 23:59'", conn);
						Console.WriteLine($"Inserting ETFVolume of {lastTDate}");
						foreach (DataRow row in summary.Rows)
						{
							string SQLcmd = $@"Insert into ETFVolume(TDate, ETFID,  ETFName, Volume, Amount) Values("
									+ $"'{row[0].ToString()}','{row[1].ToString()}', '{row[2].ToString()}', {row[3].ToString()}, {row[4].ToString()})";
						   //Console.WriteLine(SQLcmd);
						    MSSQL.ExecSqlCmd(SQLcmd, conn);
						}
					}
#endif
            }
            catch (Exception e)
            {
                //Console.ReadLine();
                MailService ms = new MailService();
                ms.SendMail("licheng@kgi.com", "10.19.1.45 ERROR", new string[] { "licheng@kgi.com" }, null, null, $"{lastTDate}IFRS_StockMonitor ERROR!", e.ToString(), false, null);
            }
            //}
        }
    }
}
