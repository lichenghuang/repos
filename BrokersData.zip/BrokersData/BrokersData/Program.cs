﻿using System.Data;
using EDLib.SQL;
using EDLib;
using EDLib.Pricing.Option;
using System;
using System.IO;
using System.IO.Compression;
using SharpCompress.Readers;
using SharpCompress.Readers.Rar;
using GenericParsing;
using System.Text;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Drawing;
using System.Linq;
using System.Diagnostics;

namespace BrokersData
{

    public static class Program
    {
        static DataTable brokers;  // CMoney data
        static DataTable propAndMM; // CMoney data
        static Dictionary<string, string> codeBrokers = new Dictionary<string, string>(); // BrokerID, BrokerName

        static DataTable warrantTrading; // From 10.19.1.45 newEDIS.WarrantTrading

        static DataTable twse;
        static DataTable twseCD;
        static object lockTWSE = new object();
        static DataTable otc;
		static object lockOTC = new object();
		static object lockTWSEVol = new object();
		static object lockallSnapShot = new object();
		//static DataTable twseVol;

		enum Exchange:int
        {
            TWSE,
            OTC
        }

        //static DataTable otcB;
#if DEBUG
        static StreamWriter log = new StreamWriter(".\\log.txt");
#endif
        static string todayStr = "20180503"; //DateTime.Today.ToString("yyyyMMdd");
        static readonly double intRate = 0.025;

        static string[] relatedColumns = { "RecordTime.w","Symbol.w","ReferencePrice.w","UpLimitPrice.w","DownLimitPrice.w","OpenPx.w","HighPx.w","LowPx.w","LastPx.w","PreClosePx.w",
            "LastShares.w","CumQty.w","Bid1Px.w","Bid1Shares.w","Bid2Px.w","Bid2Shares.w","Bid3Px.w","Bid3Shares.w","Bid4Px.w","Bid4Shares.w","Bid5Px.w","Bid5Shares.w","Ask1Px.w",
            "Ask1Shares.w","Ask2Px.w","Ask2Shares.w","Ask3Px.w","Ask3Shares.w","Ask4Px.w","Ask4Shares.w","Ask5Px.w","Ask5Shares.w","NetChg.w","NetChgPct.w","Matched.w","MatchStatus.w","MatchTime.w","MatchIndex.w",
            "RecordTime.u","Symbol.u","ReferencePrice.u","UpLimitPrice.u","DownLimitPrice.u","OpenPx.u","HighPx.u","LowPx.u","LastPx.u","PreClosePx.u","LastShares.u","CumQty.u","Bid1Px.u",
            "Bid1Shares.u","Bid2Px.u","Bid2Shares.u","Bid3Px.u","Bid3Shares.u","Bid4Px.u","Bid4Shares.u","Bid5Px.u","Bid5Shares.u","Ask1Px.u","Ask1Shares.u","Ask2Px.u","Ask2Shares.u",
            "Ask3Px.u","Ask3Shares.u","Ask4Px.u","Ask4Shares.u","Ask5Px.u","Ask5Shares.u","NetChg.u","NetChgPct.u","Matched.u","MatchStatus.u","MatchTime.u",
            "Last.RecordTime.u","Last.Bid1Px.u","Last.Bid1Shares.u","Last.Ask1Px.u","Last.Ask1Shares.u","Last.MatchTime.u","MatchIndex.u",
            "RecordTime.f","Symbol.f","ReferencePrice.f","UpLimitPrice.f","DownLimitPrice.f","OpenPx.f","HighPx.f","LowPx.f","LastPx.f","PreClosePx.f","LastShares.f","CumQty.f",
            "Bid1Px.f","Bid1Shares.f","Bid2Px.f","Bid2Shares.f","Bid3Px.f","Bid3Shares.f","Bid4Px.f","Bid4Shares.f","Bid5Px.f","Bid5Shares.f","Ask1Px.f","Ask1Shares.f","Ask2Px.f","Ask2Shares.f",
            "Ask3Px.f","Ask3Shares.f","Ask4Px.f","Ask4Shares.f","Ask5Px.f","Ask5Shares.f","NetChg.f","NetChgPct.f","Matched.f","MatchStatus.f","MatchTime.f","SettlePx.f","OI.f","ContractMultiplier.f",
            "", "", "", "UniqueID"};

		static string[] buySellSide = { "Buy", "Sell" };

		static DataTable InitializeTables() {
            DataTable dt = new DataTable();
            dt.Columns.Add("WID", typeof(string));
            dt.Columns.Add("BrokerCode", typeof(string));
            dt.Columns.Add("Broker", typeof(string));
            dt.Columns.Add("Price", typeof(double));
            dt.Columns.Add("Buy", typeof(int));
            dt.Columns.Add("Sell", typeof(int));
            dt.Columns.Add("Flag", typeof(string));
			dt.Columns.Add("BuyUsed", typeof(string));
			dt.Columns.Add("SellUsed", typeof(string));
			dt.Columns.Add("BuyQtyAdj", typeof(int));
			dt.Columns.Add("SellQtyAdj", typeof(int));
			return dt;
        }

		static DataTable InitializeSnapshotTables()
		{
			DataTable dt = new DataTable();
			foreach (string i in relatedColumns)
				dt.Columns.Add(i);
			dt.Columns.Add("Qty");
			dt.Columns.Add("Price");
			dt.Columns.Add("BidDiff");
			dt.Columns.Add("AskDiff");
			dt.Columns.Add("BuySide");
			dt.Columns.Add("SellSide");
			dt.Columns.Add("BuySideFlag");
			dt.Columns.Add("SellSideFlag");
			dt.Columns.Add("BuyAccuracy");
			dt.Columns.Add("SellAccuracy");
			return dt;
		}

		static void InitializeVolTable(DataTable dt)
		{
			dt = new DataTable();
			dt.Columns.Add("WID", typeof(string));
			dt.Columns.Add("Buy", typeof(double));
			dt.Columns.Add("Sell", typeof(double));
			dt.Columns.Add("Volume", typeof(string));
		}

        static DataTable ParseTWSE(string fileName) {

            if (new FileInfo(fileName).LastWriteTime.ToString("yyyyMMdd") != todayStr) {
                Console.WriteLine($"Date of {fileName} is wrong.");
                throw new Exception($"Date of {fileName} is wrong.");
            }

            DataTable dt = InitializeTables();
            using (GenericParser parser = new GenericParser(fileName, Encoding.Default)) {
                parser.ColumnDelimiter = ',';
                parser.FirstRowHasHeader = true;
                parser.MaxBufferSize = 4096;

                while (parser.Read()) {
                    int tmp;
                    if ((tmp = int.Parse(parser[3].ToString())) != 0)
                        dt.Rows.Add(new object[] { parser[0], parser[1].Substring(1, 4), codeBrokers[parser[1].Substring(1, 4)], parser[2], tmp / 1000, 0, "", "", "", tmp / 1000, 0 });
                    if ((tmp = int.Parse(parser[4].ToString())) != 0)
                        dt.Rows.Add(new object[] { parser[0], parser[1].Substring(1, 4), codeBrokers[parser[1].Substring(1, 4)], parser[2], 0, tmp / 1000, "", "", "", 0, tmp / 1000 });
                    //dt.Rows.Add(new object[] { parser[0], parser[1].Substring(1, 4), codeBrokers[parser[1].Substring(1, 4)], parser[2], int.Parse(parser[3].ToString()) / 1000, int.Parse(parser[4].ToString()) / 1000, "" });
                }
            }
            return dt;
        }

        static DataTable ParseOTCNew(string fileName) {
            DataTable dt = InitializeTables();
            using (GenericParser parser = new GenericParser(fileName, Encoding.Default)) {
                parser.ColumnDelimiter = ',';
                parser.FirstRowHasHeader = false;
                parser.MaxBufferSize = 4096;

                //Read first row and check date for validity
                parser.Read();
                if (parser[0].ToString() != todayStr) {
                    Console.WriteLine($"Date of {fileName} is wrong.");
                    throw new Exception($"Date of {fileName} is wrong.");
                }

                while (parser.Read()) {
                    int tmp;
                    if ((tmp = int.Parse(parser[4].ToString())) != 0)
                        dt.Rows.Add(new object[] { parser[0], parser[1], codeBrokers[parser[1]], parser[3], tmp / 1000, 0, "" });
                    if ((tmp = int.Parse(parser[5].ToString())) != 0)
                        dt.Rows.Add(new object[] { parser[0], parser[1], codeBrokers[parser[1]], parser[3], 0, tmp / 1000, "" });
                    //dt.Rows.Add(new object[] { parser[0], parser[1].Substring(1, 4), codeBrokers[parser[1].Substring(1, 4)], parser[2], int.Parse(parser[3].ToString()) / 1000, int.Parse(parser[4].ToString()) / 1000, "" });
                }
            }
            return dt;
        }

        static DataTable ParseRelated(string fileName) {
            DataTable dt = new DataTable();
            foreach (string i in relatedColumns)
                dt.Columns.Add(i);
            using (StreamReader reader = new StreamReader(fileName)) {
                string[] lastLine = null;
                string[] thisLine = null;
                while (!reader.EndOfStream) {
                    lastLine = thisLine;
                    thisLine = reader.ReadLine().Split(',');
                    if (lastLine == null || thisLine[11] != lastLine[11])
                        dt.Rows.Add(thisLine);
                }
            }

            //Adjustment of the reversed CumQty problem
            bool changed = true;
            while (changed) {
                changed = false;
                for (int i = dt.Rows.Count - 1; i > 0; i--) {
                    if (int.Parse(dt.Rows[i]["CumQty.w"].ToString()) < int.Parse(dt.Rows[i - 1]["CumQty.w"].ToString())) {
                        //Console.WriteLine(fileName);
                        DataRow oldRow = dt.NewRow();
                        oldRow.ItemArray = dt.Rows[i].ItemArray;
                        dt.Rows.RemoveAt(i);
                        dt.Rows.InsertAt(oldRow, i - 1);
                        changed = true;
                    }
                }
            }

            dt.Columns.Add("Qty");
            dt.Rows[0]["Qty"] = dt.Rows[0]["CumQty.w"];
            for (int i = 1; i < dt.Rows.Count; i++)
                dt.Rows[i]["Qty"] = int.Parse(dt.Rows[i]["CumQty.w"].ToString()) - int.Parse(dt.Rows[i - 1]["CumQty.w"].ToString());

            return dt;
        }

        /*static DataTable ParseOTC(string fileName) {
            DataTable dt = null;
            using (var read = File.OpenRead(fileName)) {
                byte[] todayDate = new byte[8];
                read.Read(todayDate, 0, 8);

                if (Encoding.UTF8.GetString(todayDate) != todayStr) {
                    Console.Write(Encoding.UTF8.GetString(todayDate));
                    Console.WriteLine($"Date of {fileName} is wrong.");
                    throw new Exception($"Date of {fileName} is wrong.");
                }
                dt = InitializeTables();

                byte[] unused = new byte[54];
                read.Read(unused, 0, 54);

                byte[] UID = new byte[6];
                byte[] brokerCode = new byte[4];
                byte[] broker = new byte[10];
                byte[] info = new byte[24];
                while (read.Read(UID, 0, 6) > 0) {
                    read.Read(unused, 0, 16);//UName
                    read.Read(brokerCode, 0, 4);
                    read.Read(broker, 0, 10);
                    read.Read(info, 0, 24);
                    read.Read(unused, 0, 2);//crlf

                    string WID = Encoding.UTF8.GetString(UID).TrimEnd(' ');
                    if (WID.Length < 6 || !WID.StartsWith("7"))
                        continue;

                    string infoString = Encoding.UTF8.GetString(info);
                    double price = double.Parse(infoString.Substring(0, 6)) / 100.0;
                    double buy = double.Parse(infoString.Substring(6, 9)) / 1000.0;
                    double sell = double.Parse(infoString.Substring(15, 9)) / 1000.0;

                    string brokerName = Encoding.GetEncoding("Big5").GetString(broker).TrimEnd(' ');
                    if (codeBrokers.ContainsKey(Encoding.UTF8.GetString(brokerCode)))
                        dt.Rows.Add(new object[] { WID, Encoding.UTF8.GetString(brokerCode),
                        codeBrokers[Encoding.UTF8.GetString(brokerCode)], price, buy, sell, ""});
                    else {
                        dt.Rows.Add(new object[] { WID, Encoding.UTF8.GetString(brokerCode),
                        brokerName, price, buy, sell, ""});
                        //Console.WriteLine(Encoding.UTF8.GetString(brokerCode) + " " + brokerName);
                    }
                }
            }
            return dt;
        }

        static void UpdateOTCPrice(DataRow dataRow, double price) {
            int index = otc.Rows.IndexOf(dataRow);
            otc.Rows[index]["Price"] = price;
            otc.Rows[index]["Flag"] = otc.Rows[index]["Flag"].ToString().TrimEnd('\'');
        }
        */

        static bool ForceSplitRow(IEnumerable<DataRow> result, string buySell, bool isIssuer, int buyQty, DataRow[] twseBroker) {
            foreach (var twseRow in result) {
                lock (lockTWSE) {
                    int index = twse.Rows.IndexOf(twseRow);
                    twse.Rows[index]["Flag"] = isIssuer ? "MM2" : "Prop2";
                }

                if (buyQty <= int.Parse(twseRow[buySell].ToString())) {
                    if (buyQty != int.Parse(twseRow[buySell].ToString())) {
                        DataRow newRow = twse.NewRow();
                        newRow.ItemArray = twseRow.ItemArray;
                        newRow["Flag"] = "RetailInvestor";
                        newRow[buySell] = int.Parse(twseRow[buySell].ToString()) - buyQty;
                        lock (lockTWSE) {
                            int index = twse.Rows.IndexOf(twseRow);
                            twse.Rows[index][buySell] = buyQty;
                            twse.Rows.InsertAt(newRow, index);
                        }
                    }
                    SetRetail(twseBroker);
                    return true;
                }

                buyQty -= int.Parse(twseRow[buySell].ToString());
            }
            return false;
        }

        // Set remains to retail
        static void SetRetail(DataRow[] twseBroker) {
            var twseBlank = (from sampleRow in twseBroker
                             where string.IsNullOrWhiteSpace(sampleRow["Flag"].ToString())
                             select sampleRow).ToArray();

            foreach (DataRow twseRow in twseBlank) {
                lock (lockTWSE) {
                    int index = twse.Rows.IndexOf(twseRow);
                    twse.Rows[index]["Flag"] = "RetailInvestor";
                }
            }
        }
        // Separate Prop and MM
        static void CheckPropMM(string buySell, int buyQty, int buyCount, DataRow[] twseWID, string brokerCode, bool isIssuer) {

            var twseBrokerLEQty = (from sampleRow in twseWID
                                   where sampleRow["BrokerCode"].ToString() == brokerCode
                                   && sampleRow[buySell].ToString() != "0"
                                   && int.Parse(sampleRow[buySell].ToString()) <= buyQty
                                   select sampleRow).ToArray();

            var twseBroker = (from sampleRow in twseWID
                              where sampleRow["BrokerCode"].ToString() == brokerCode
                              && sampleRow[buySell].ToString() != "0"
                              select sampleRow).ToArray();

            if (twseBrokerLEQty.Sum(p => int.Parse(p[buySell].ToString())) == buyQty) {
                foreach (DataRow twseRow in twseBrokerLEQty) {
                    lock (lockTWSE) {
                        int index = twse.Rows.IndexOf(twseRow);
                        twse.Rows[index]["Flag"] = isIssuer ? "MM" : "Prop";
                    }
                }

                SetRetail(twseBroker);

            } else {
                bool found = false;
				buyCount = buyCount > 0 ? buyCount : 1;
				if (twseBrokerLEQty.Count() < buyCount)
					//Console.WriteLine($"'{buyCount}' +  '{twseBrokerLEQty.Count()}'");
                for (; buyCount < twseBrokerLEQty.Count() && !found; buyCount++)
                    if (buyCount < twseBrokerLEQty.Count() && PermutationsAndCombinations.nCr(twseBrokerLEQty.Count(), buyCount) < 2000 && twseBrokerLEQty.Count() <= 27) {
                        var twseBrokerLEQtyCombs = Utility.DifferentCombinations(twseBrokerLEQty, buyCount);
                        foreach (var result in twseBrokerLEQtyCombs) {
                            if (result.Sum(p => int.Parse(p[buySell].ToString())) == buyQty) {
                                foreach (DataRow twseRow in result) {
                                    lock (lockTWSE) {
                                        int index = twse.Rows.IndexOf(twseRow);
                                        twse.Rows[index]["Flag"] = isIssuer ? "MM1" : "Prop1";
                                    }
                                }
                                SetRetail(twseBroker);

                                found = true;
                                break;
                            }
                        }

                        /*if (!found && (twseBrokerLEQtyCombs.Where(x => x.Sum(p => int.Parse(p[buySell].ToString())) > buyQty)).Count() > 0) {
                            var result = twseBrokerLEQtyCombs.Where(x => x.Sum(p => int.Parse(p[buySell].ToString())) > buyQty).OrderBy(x => x.Sum(p => int.Parse(p[buySell].ToString()))).First();
                            found = ForceSplitRow(result.OrderByDescending(p => p[buySell].ToString()), buySell, isIssuer, buyQty, twseBroker);
                        }*/
                    }

                if (!found) {
                    found = ForceSplitRow(twseBroker.OrderByDescending(x => x[buySell].ToString()), buySell, isIssuer, buyQty, twseBroker);
                }
            }

            var twseBrokerBlank = (from sampleRow in twseWID
                                   where sampleRow["BrokerCode"].ToString() == brokerCode
                                       && sampleRow[buySell].ToString() != "0"
                                       && string.IsNullOrWhiteSpace(sampleRow["Flag"].ToString())
                                   select sampleRow).ToArray();

            foreach (DataRow twseRow in twseBrokerBlank) {
                lock (lockTWSE) {
                    int index = twse.Rows.IndexOf(twseRow);
                    twse.Rows[index]["Flag"] = isIssuer ? "MM'" : "Prop'";
                }
            }
        }

		// 1360 Missing
		static void SetMissingProp(DataRow[] twseWID, DataTable relatedSnapshot)
		{
			if (twseWID.Sum(p => int.Parse(p["Buy"].ToString())) != relatedSnapshot.AsEnumerable().Sum(q => int.Parse(q["Qty"].ToString())))
			{	
				foreach (double p in twseWID.Select(x => x.Field<double>("Price")).Distinct())
				{
					int twseBuyQty = twseWID.Where(r => r["Price"].ToString() == p.ToString()).Sum(q => int.Parse(q["Buy"].ToString()));
					int twseSellQty = twseWID.Where(r => r["Price"].ToString() == p.ToString()).Sum(q => int.Parse(q["Sell"].ToString()));
					int snapShotQty = relatedSnapshot.Select($"LastPx.w = '{p.ToString()}'").Sum(q => int.Parse(q["Qty"].ToString()));
					//Console.WriteLine(snapShotQty);
					if (twseBuyQty < snapShotQty)
					{
						lock (lockTWSE)
						{
							DataRow newRow = twse.NewRow();
							newRow.ItemArray = twseWID[1].ItemArray;
							newRow["BrokerCode"] = "1360";
							newRow["Broker"] = codeBrokers["1360"];
							newRow["Price"] = p;
							newRow["Buy"] = snapShotQty - twseBuyQty;
							newRow["Sell"] = 0;
							newRow["Flag"] = "Prop''";
							twse.Rows.Add(newRow);
							//twse.Rows.InsertAt(newRow, twse.Rows.IndexOf(twseWID[twseWID.Count() - 1]));
						}
					}

					if (twseSellQty < snapShotQty)
					{
						lock (lockTWSE)
						{
							DataRow newRow = twse.NewRow();
							newRow.ItemArray = twseWID[1].ItemArray;
							newRow["BrokerCode"] = "1360";
							newRow["Broker"] = codeBrokers["1360"];
							newRow["Price"] = p;
							newRow["Buy"] = 0;
							newRow["Sell"] = snapShotQty - twseSellQty;
							newRow["Flag"] = "Prop''";
							twse.Rows.Add(newRow);
							//twse.Rows.InsertAt(newRow, twse.Rows.IndexOf(twseWID[twseWID.Count() - 1]));
						}
					}
				}
			}
		}

		// Match only one SnapShot or Broker
		static void MatchOne(DataRow[] twseWID, DataTable relatedSnapshot)
		{
			foreach (string side in buySellSide)
			{
				//Console.WriteLine(side);
				var relatedSnapshotQty = relatedSnapshot.AsEnumerable().Where(x => x["Qty"].ToString() != "0" && x.Field<string>($"{side}Side") == null).ToArray();
				if (relatedSnapshotQty.Count() == 0)
					continue;
				//Console.WriteLine(relatedSnapshotQty.Count());
				//Console.WriteLine(relatedSnapshotQty.Select(r => double.Parse(r.Field<string>("LastPx.w"))).Count());
;				foreach (double p in relatedSnapshotQty.Select(r => double.Parse(r.Field<string>("LastPx.w"))).Distinct())
				{
					//Console.WriteLine(p);
					var relatedSnapshotQtyPrice = relatedSnapshotQty.Where(r => double.Parse(r.Field<string>("LastPx.w")) == p).ToArray();
					var twseWIDPrice = twseWID.Where(x => x.Field<int>($"{side}QtyAdj") != 0 && x.Field<double>("Price") == p && x.Field<string>($"{side}Used") != "1").ToArray();
					if (twseWIDPrice.Count() == 0)
						continue; 
					if (twseWIDPrice.Count() == 1)
					{
						//Console.WriteLine(twseWID.First()["WID"].ToString() + "twse" + p);
						//Console.Write(twseWIDPrice.Select(r => r.Field<int>($"{side}")));
						//Console.WriteLine(relatedSnapshotPrice.Where(r => double.Parse(r.Field<string>("LastPx.w")) == p).Sum(x => int.Parse(x["Qty"].ToString())));
						if (twseWIDPrice.First()[$"{side}QtyAdj"].ToString() == relatedSnapshotQtyPrice.Sum(x => int.Parse(x["Qty"].ToString())).ToString())
						{
						
							foreach (DataRow row in relatedSnapshotQtyPrice)
							{
								//Console.WriteLine(side + twseWIDPrice.Select(r => r.Field<string>("BrokerCode")).ToList()[0] + twseWIDPrice.Select(r => r.Field<string>("Flag")).ToList()[0]);
								int snapshotRowIndex = relatedSnapshot.Rows.IndexOf(row);
								//Console.WriteLine("snapshotRowIndex1 :" + snapshotRowIndex + "" + "Row" + ":" + relatedSnapshot.Rows.Count);
								relatedSnapshot.Rows[snapshotRowIndex][$"{side}Side"] = twseWIDPrice.Select(r => r.Field<string>("BrokerCode")).ToList()[0];
								relatedSnapshot.Rows[snapshotRowIndex][$"{side}SideFlag"] = twseWIDPrice.Select(r => r.Field<string>("Flag")).ToList()[0];
								relatedSnapshot.Rows[snapshotRowIndex][$"{side}Accuracy"] = "0";
							}
							
							lock(lockTWSE)
							{
								int twseRowIndex = twse.Rows.IndexOf(twseWIDPrice.First());
								//Console.WriteLine("twseRowIndex" + twseRowIndex + "Rows" + twse.Rows.Count);
								twse.Rows[twseRowIndex][$"{side}Used"] = "1";
								twse.Rows[twseRowIndex][$"{side}QtyAdj"] = 0;
							}
						}
					}

					if (relatedSnapshotQtyPrice.Count() == 1 && twseWIDPrice.Count() != 1 && twseWIDPrice.Sum(r => r.Field<int>($"{side}QtyAdj")) == relatedSnapshotQty.Sum(x => int.Parse(x["Qty"].ToString())))
					{
						//Console.WriteLine(twseWIDPrice.Count() != 1);
						//Console.WriteLine(relatedSnapshotQty.First()["Symbol.w"].ToString() + "Snap" + p);
						int snapshotRowIndex = relatedSnapshot.Rows.IndexOf(relatedSnapshotQtyPrice.First());
						//Console.WriteLine("snapshotRowIndex2 :" + snapshotRowIndex);
						foreach (DataRow row in twseWIDPrice)
						{
							DataRow newRow = relatedSnapshot.NewRow();
							newRow.ItemArray = relatedSnapshotQtyPrice.First().ItemArray.Clone() as object[];
							newRow[$"Qty"] = row[$"{side}QtyAdj"];
							newRow[$"{side}Side"] = row["BrokerCode"];
							newRow[$"{side}SideFlag"] = row["Flag"];
							newRow[$"{side}Accuracy"] = 0;
							relatedSnapshot.Rows.Add(newRow);
						}
						relatedSnapshot.Rows.RemoveAt(snapshotRowIndex);
						
						lock (lockTWSE)
						{
							foreach (DataRow row in twseWIDPrice)
							{
								int twseWIDPriceIndex = twse.Rows.IndexOf(row);
								//Console.WriteLine("twseWIDPriceIndex" + twseWIDPriceIndex + "Rows" + ":" + twse.Rows.Count);
								twse.Rows[twseWIDPriceIndex][$"{side}Used"] = "1";
								twse.Rows[twseWIDPriceIndex][$"{side}QtyAdj"] = 0;
							}
						}
					}		
				}
			}
		}

		static void VolumeSort(DataRow[] twseWID, DataTable relatedSnapshot)
		{
			foreach (string side in buySellSide)
			{
				//Console.WriteLine(side);
				var relatedSnapshotQty = relatedSnapshot.AsEnumerable().Where(x => x["Qty"].ToString() != "0" && x.Field<string>($"{side}Side") == null).ToArray();
				if (relatedSnapshotQty.Count() == 0)
					continue;
				foreach (double p in relatedSnapshotQty.Select(r => double.Parse(r.Field<string>("LastPx.w"))).Distinct())
				{
					//Console.WriteLine(p);
					var relatedSnapshotQtyPrice = relatedSnapshotQty.Where(r => double.Parse(r.Field<string>("LastPx.w")) == p).OrderByDescending(x => x["Qty"]).ToArray();
					var twseWIDPrice = twseWID.Where(x => x.Field<int>($"{side}QtyAdj") != 0 && x.Field<double>("Price") == p && x.Field<string>($"{side}Used") != "1").OrderByDescending(x => x[$"{side}QtyAdj"]).ToArray();
					//Console.WriteLine("Count:" +  twseWIDPrice.Count());
					if (twseWIDPrice.Count() <= 1)
						continue;
					//Console.WriteLine(relatedSnapshotQtyPrice.Count().ToString() + "/" + twseWIDPrice.Count().ToString() + "/" + relatedSnapshotQtyPrice[0]["Qty"].ToString() + "/" + twseWIDPrice[0][$"{side}QtyAdj"].ToString() + "/" + twseWIDPrice[1][$"{side}QtyAdj"].ToString());
					//Console.WriteLine(relatedSnapshotQtyPrice.Count() > 1 && twseWIDPrice.Count() > 1 && int.Parse(relatedSnapshotQtyPrice[0]["Qty"].ToString()) <= int.Parse(twseWIDPrice[0][$"{side}QtyAdj"].ToString()) && int.Parse(relatedSnapshotQtyPrice[0]["Qty"].ToString()) > int.Parse(twseWIDPrice[1][$"{side}QtyAdj"].ToString()));
					while (relatedSnapshotQtyPrice.Count() > 1 && twseWIDPrice.Count() > 1 && int.Parse(relatedSnapshotQtyPrice[0]["Qty"].ToString()) <= int.Parse(twseWIDPrice[0][$"{side}QtyAdj"].ToString()) && int.Parse(relatedSnapshotQtyPrice[0]["Qty"].ToString()) > int.Parse(twseWIDPrice[1][$"{side}QtyAdj"].ToString()))
					{
						int snapshotRowIndex = relatedSnapshot.Rows.IndexOf(relatedSnapshotQtyPrice[0]);
						//Console.WriteLine("snapIndex:" + snapshotRowIndex);
						//Console.WriteLine("snapshotRowIndex1 :" + snapshotRowIndex + "" + "Row" + ":" + relatedSnapshot.Rows.Count);
						relatedSnapshot.Rows[snapshotRowIndex][$"{side}Side"] = twseWIDPrice[0]["BrokerCode"].ToString();
						relatedSnapshot.Rows[snapshotRowIndex][$"{side}SideFlag"] = twseWIDPrice[0]["Flag"].ToString();
						relatedSnapshot.Rows[snapshotRowIndex][$"{side}Accuracy"] = "0.1";
						lock (lockTWSE)
						{
							int twseWIDPriceIndex = twse.Rows.IndexOf(twseWIDPrice[0]);
							//Console.WriteLine("twseIndex:" + twseWIDPriceIndex);
							//Console.WriteLine("twseWIDPriceIndex" + twseWIDPriceIndex + "Rows" + ":" + twse.Rows.Count);
							if (relatedSnapshotQtyPrice[0]["Qty"].ToString() == twseWIDPrice[0][$"{side}QtyAdj"].ToString())
							{
								twse.Rows[twseWIDPriceIndex][$"{side}Used"] = "1";
								twse.Rows[twseWIDPriceIndex][$"{side}QtyAdj"] = 0;
								twseWIDPrice = twseWIDPrice.Where(r => r != twseWIDPrice[0]).OrderByDescending(r => r[$"{side}QtyAdj"]).ToArray();
							}
							else
							{
								twse.Rows[twseWIDPriceIndex][$"{side}QtyAdj"] = int.Parse(twseWIDPrice[0][$"{side}QtyAdj"].ToString()) - int.Parse(relatedSnapshotQtyPrice[0]["Qty"].ToString());
								twseWIDPrice = twseWIDPrice.OrderByDescending(r => r[$"{side}QtyAdj"]).ToArray();
							}
						}
						relatedSnapshotQtyPrice = relatedSnapshotQtyPrice.Where(r => r != relatedSnapshotQtyPrice[0]).OrderByDescending(x => x["Qty"]).ToArray();
					}
				}
			}
		}

		

		/*
		static void CheckVolume(DataRow[] twseWID, DataTable relatedSnapshot)
		{
			lock (lockTWSEVol)
			{
				DataRow newRow = twseVol.NewRow();
				newRow["WID"] = twseWID[0]["WID"];
				newRow["Buy"] = twseWID.Sum(r => int.Parse(r["Buy"].ToString()));
				newRow["Sell"] = twseWID.Sum(r => int.Parse(r["Sell"].ToString()));
				newRow["Volume"] = relatedSnapshot.AsEnumerable().Sum(r => int.Parse(r["Qty"].ToString()));
				twseVol.Rows.Add(newRow);
			}
		}
		*/

        static void Main(string[] args) {
            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();

			DataTable allRelatedSnapshot = InitializeSnapshotTables();

			#region Load CMoney data            
			Console.WriteLine("Loading Cmoney data......");
            brokers = CMoney.ExecCMoneyQry($"SELECT * FROM [日券商分點分價排行Top15] WHERE 日期 = '{todayStr}' AND 股票代號 IN <CM代號,權證> ORDER BY 股票代號");

            string sqlStr = "SELECT A.股票代號 as WID ,E.總公司代號 as BrokerCode , Sum(A.買張)-isnull(C.買張,0) as Buy , Sum(A.賣張)-isnull(C.賣張,0) as Sell, Sum(A.買筆數)-isnull(C.買筆數,0) as BuyCount , Sum(A.賣筆數)-isnull(C.賣筆數,0) as SellCount "
           + " ,Sum(A.[買金額(千)])-isnull(C.[買金額(千)],0) as BuyA, Sum(A.[賣金額(千)])-isnull(C.[賣金額(千)],0) as SellA "
           //+ " , B.權證成交量,B.[權證成交金額(千)], D.發行機構代號, left(D.發行機構名稱,2) as Name2, D.名稱 "
           + " from 個股券商分點進出明細 as A "
           + " left join 權證評估表 as B on A.股票代號=B.代號 and A.日期=B.日期 "
           + " left join 權證基本資料表 as D on D.代號=A.股票代號 "
           + " left join 券商公司基本資料表 as E on A.券商代號=E.代號 "
           + " left join 個股券商進出明細 as C on C.股票代號=A.股票代號 and E.總公司代號=C.券商代號 and A.日期=C.日期"
           + $" where A.日期='{todayStr}' and B.權證成交量 is not null and D.年度='{todayStr.Substring(0, 4)}' and E.年度='{todayStr.Substring(0, 4)}'"
           + " group by A.股票代號, E.總公司代號, C.買張 , C.賣張, C.[買金額(千)], C.[賣金額(千)], C.買筆數, C.賣筆數"
           + " having Sum(A.買張)-isnull(C.買張,0)<>0 or Sum(A.賣張)-isnull(C.賣張,0)<>0 "
           + " order by A.股票代號 ";
            //"SELECT 日期, 股票代號, 股票名稱, 券商代號, 買張, 賣張 FROM 個股券商進出明細 WHERE 日期 = '" + todayStr + "' AND 股票代號 IN <CM代號,權證> ORDER BY 股票代號"
            propAndMM = CMoney.ExecCMoneyQry(sqlStr);
            using (DataTable brokersCodes = CMoney.ExecCMoneyQry($"SELECT 券商代號, replace(名稱, '-', '') FROM 券商公司基本資料表 where 年度 = '{todayStr.Substring(0, 4)}' and 開業日 < GETDATE()"))
                foreach (DataRow row in brokersCodes.Rows) {
                    try {
                        codeBrokers.Add((string) row[0], (string) row[1]);
                    } catch (ArgumentException) { continue; }
                }
            #endregion

            #region Load WarrantTrading Data            
            Console.WriteLine("Loading WarrantTrading data......");
            warrantTrading = MSSQL.ExecSqlQry("SELECT A.*, CASE WHEN C.MMVol is null THEN B.BaseLineVol ELSE C.MMVol/100 END as VOL "
                                            + " FROM[dbo].[WarrantTrading] as A "
                                            + " left join [10.101.10.5].[WMM3].[dbo].[BaseLineVol] as B on A.TDate = B.Date and  A.WID = B.WarrantID "
                                            + " left join [10.101.10.5].[WMM3].[dbo].[MMVolHistory] as C on A.TDate = C.TDate and A.WName = SUBSTRING(C.WarrantKey, 0, CHARINDEX('.', C.WarrantKey)) "
                                            + $" where A.TDate = '{todayStr}'", "Server=10.19.1.45;DataBase=newEDIS;Uid=readuser;pwd=readuser;");

            warrantTrading.Columns.Add("Delta.r");
            for (int i = 0; i < warrantTrading.Rows.Count; i++) {
                double S = double.Parse(warrantTrading.Rows[i]["UBidPrice"].ToString());
                double X = double.Parse(warrantTrading.Rows[i]["StrikePrice"].ToString());
                double sigma = double.Parse(warrantTrading.Rows[i]["HedgeVol"].ToString());
                double T = double.Parse(warrantTrading.Rows[i]["TtoM"].ToString()) / 256.0;

                switch (warrantTrading.Rows[i]["WClass"].ToString()) {
                    case "c":
                        warrantTrading.Rows[i]["Delta.r"] = PlainVanilla.CallDelta(S, X, intRate, sigma, T);
                        break;
                    case "p":
                        warrantTrading.Rows[i]["Delta.r"] = PlainVanilla.PutDelta(S, X, intRate, sigma, T);
                        break;
                    case "xcdo":
                    case "cdo":
                        warrantTrading.Rows[i]["Delta.r"] = 1;
                        break;
                    case "xpuo":
                    case "puo":
                        warrantTrading.Rows[i]["Delta.r"] = -1;
                        break;
                    case "cuo":
                        break;
                    case "pdo":
                        break;
                }
            }
            #endregion

            Console.WriteLine("Writing data......");
            Utility.SaveToCSV(warrantTrading, ".\\WT.csv", true);//
            Utility.SaveToCSV(brokers, ".\\brokers.csv", true);//
            Utility.SaveToCSV(propAndMM, ".\\PropAndMM.csv", true);//

            #region Unzip Files
            //Unzip OTC and TWSE files   
            Console.WriteLine("Unzipping data......");
            using (Stream stream = File.OpenRead($"\\\\10.19.1.203\\Warrant\\QuoteData\\JQuote\\{todayStr}\\{todayStr}STKRPQWRNT(OTC).rar")) {
                var reader2 = RarReader.Open(stream, new ReaderOptions() { LookForHeader = true });
                reader2.WriteAllToDirectory(@".\", new ExtractionOptions() { ExtractFullPath = true, Overwrite = true });
            }
            if (File.Exists(".\\33.csv"))
                File.Delete(".\\33.csv");
            if (File.Exists(".\\33EXCD.csv"))
                File.Delete(".\\33EXCD.csv");
            ZipFile.ExtractToDirectory($"\\\\10.19.1.203\\Warrant\\QuoteData\\JQuote\\{todayStr}\\{todayStr}TSECD.zip", ".\\");
            ZipFile.ExtractToDirectory($"\\\\10.19.1.203\\Warrant\\QuoteData\\JQuote\\{todayStr}\\{todayStr}TSE.zip", ".\\");
            #endregion

            #region Parse Files
            //Parse TWSE and OTC files
            Console.WriteLine("Parsing TWSE and OTC files......");
            twse = ParseTWSE(".\\33.csv");
			twseCD = ParseTWSE(".\\33EXCD.csv");
            otc = ParseOTCNew(".\\STKRPQWRNT.CSV");
			//otc = ParseOTC(".\\STKDBRKPRVOL.txt");
			//otcB = ParseOTC(".\\STKDBRKPRVOLB.txt");
			#endregion

			/*
			#region InitializeVolTable
			InitializeVolTable(twseVol);
			#endregion
			*/

			// Begin iterating through each row in WarrantTrading table
			Console.WriteLine("Begin iterating through each row in WarrantTrading table......");

			Parallel.ForEach(warrantTrading.AsEnumerable(), row => {
			//foreach (DataRow row in warrantTrading.Rows) {
			string WID = (string) row["WID"];
			
                //Console.WriteLine(WID);

                var brokerSelect = (from DataRow sampleRow in brokers.AsEnumerable()
                                    where sampleRow["股票代號"].ToString() == WID
                                    select sampleRow).ToArray();
                if (brokerSelect.Count() <= 0)
                    return;
					//continue;

                //Read in related data and check for integrity 
                if (!File.Exists($"\\\\10.19.1.203\\Warrant\\QuoteData\\JQuote\\{todayStr}\\RelatedSnapshotFullRefresh\\{WID}.txt")) {
                    Console.WriteLine($"\\\\10.19.1.203\\Warrant\\QuoteData\\JQuote\\{todayStr}\\RelatedSnapshotFullRefresh\\{WID}.txt not found");
                    return;
                    //continue;
                }

				DataTable relatedSnapshot;
				relatedSnapshot = ParseRelated($"\\\\10.19.1.203\\Warrant\\QuoteData\\JQuote\\{todayStr}\\RelatedSnapshotFullRefresh\\{WID}.txt");
				//relatedSnapshot.DefaultView.Sort = "RecordTime.w, CumQty.w";                
				relatedSnapshot.Columns.Add("Price");
				relatedSnapshot.Columns.Add("BidDiff");
				relatedSnapshot.Columns.Add("AskDiff");
				relatedSnapshot.Columns.Add("BuySide");
				relatedSnapshot.Columns.Add("SellSide");
				relatedSnapshot.Columns.Add("BuySideFlag");
				relatedSnapshot.Columns.Add("SellSideFlag");
				relatedSnapshot.Columns.Add("BuyAccuracy");
				relatedSnapshot.Columns.Add("SellAccuracy");
				
                //Utility.SaveToCSV(relatedSnapshot, ".\\testRelated2.csv", Encoding.UTF8, true);//

                if (!WID.StartsWith("7")) { // TWSE 

                    var propAndMMSelect = (from sampleRow in propAndMM.AsEnumerable()
                                           where sampleRow["WID"].ToString() == WID
                                           select sampleRow).ToArray();
                    DataRow[] twseWID;
                    lock (lockTWSE) {
                        twseWID = (from sampleRow in twse.AsEnumerable()
                                   where sampleRow["WID"].ToString() == WID
                                   select sampleRow).ToArray();
                    }

                    // Set flag
                    foreach (DataRow row1 in propAndMMSelect) {
                        int count = 0;
                        int qty = 0;
					if ((qty = int.Parse(row1["Buy"].ToString())) > 0 && (count = int.Parse(row1["BuyCount"].ToString())) > 0)
						CheckPropMM("Buy", qty, count, twseWID, row1["BrokerCode"].ToString(), row1["BrokerCode"].ToString() == row["IssuerName"].ToString());

					if ((qty = int.Parse(row1["Sell"].ToString())) > 0 && (count = int.Parse(row1["SellCount"].ToString())) > 0)
						CheckPropMM("Sell", qty, count, twseWID, row1["BrokerCode"].ToString(), row1["BrokerCode"].ToString() == row["IssuerName"].ToString());

                    }
					
                    lock (lockTWSE) {
                        twseWID = (from sampleRow in twse.AsEnumerable()
                                   where sampleRow["WID"].ToString() == WID
                                   select sampleRow).ToArray();
                    }

					SetRetail(twseWID);
					//SetMissingProp(twseWID, relatedSnapshot);

					lock (lockTWSE)
					{
						twseWID = (from sampleRow in twse.AsEnumerable()
								   where sampleRow["WID"].ToString() == WID
								   select sampleRow).ToArray();
					}
					//Match only one Broker or one Snapshot
					MatchOne(twseWID, relatedSnapshot);

					lock (lockTWSE)
					{
						twseWID = (from sampleRow in twse.AsEnumerable()
								   where sampleRow["WID"].ToString() == WID
								   select sampleRow).ToArray();
					}
					//Match by Volume Order
					VolumeSort(twseWID, relatedSnapshot);





					lock (lockallSnapShot)
						allRelatedSnapshot.Merge(relatedSnapshot);
					
					//CheckVolume(twseWID, relatedSnapshot);

					// TODO ......

				} else { // OTC
                    DataRow[] otcSelect;
                    lock (lockOTC) {
                        otcSelect = (from sampleRow in otc.AsEnumerable()
                                     where sampleRow["WID"].ToString() == WID
                                     select sampleRow).ToArray();
                    }
					#region OTCPrice
					//List<string> endWith0 = new List<string>();
					/*
                    foreach (DataRow row1 in otcSelect) {
                        string brokerCode = row1["BrokerCode"].ToString();

                        // Set Flag
                        if (brokerCode.EndsWith("0")) {

                            lock (lockOTC)
                                otc.Rows[otc.Rows.IndexOf(row1)]["Flag"] = (brokerCode) == row["IssuerName"].ToString() ? "MM" : "Prop";

                        } else
                            lock (lockOTC)
                                otc.Rows[otc.Rows.IndexOf(row1)]["Flag"] = "RetailInvestors";
						
                        // TODO ......
                        #region oldCode
                        /*if (brokerCode.EndsWith("T")) {
                            //Set Flag
                            if ((brokerCode = brokerCode.Replace("T", "0")) == row["IssuerName"].ToString())
                                lock (lockOTC)
                                    otc.Rows[otc.Rows.IndexOf(row1)]["Flag"] = "MM";
                            else
                                lock (lockOTC)
                                    otc.Rows[otc.Rows.IndexOf(row1)]["Flag"] = "Prop";

                            if (endWith0.Contains(brokerCode)) {
                                lock (lockOTC)
                                    otc.Rows[otc.Rows.IndexOf(row1)]["Flag"] += "'";
                                continue;
                            }

                            #region Reassign the quantity
                            //Reassign the quantity                           
                            List<int> qty = new List<int>();
                            int offset;
                            string buySell;
                            int brokerSelectRow;
                            if (row1["Buy"].ToString() == "0") {
                                offset = 22;
                                buySell = "Sell";
                                brokerSelectRow = 6;
                            } else {
                                offset = 7;
                                buySell = "Buy";
                                brokerSelectRow = 5;
                            }
                            for (int j = 0; j < Math.Min(int.Parse(brokerSelect.First()[brokerSelectRow].ToString()), 15); j++)
                                if (brokerSelect.First()[offset + 30 + j].ToString() == codeBrokers[brokerCode])
                                    qty.Add(int.Parse(brokerSelect.First()[offset + j].ToString()));

                            int sumQty = qty.Sum();
                            int totalQty = int.Parse(row1[buySell].ToString());
                            lock (lockOTC) {
                                int index = otc.Rows.IndexOf(row1);
                                if (sumQty < totalQty) {
                                    otc.Rows[index][buySell] = totalQty - sumQty;
                                    for (int j = 0; j < qty.Count; j++) {
                                        DataRow newRow = otc.NewRow();
                                        newRow.ItemArray = row1.ItemArray;
                                        newRow[buySell] = qty[j];
                                        otc.Rows.InsertAt(newRow, index);
                                    }
                                    if (int.Parse(otc.Rows[index + qty.Count][buySell].ToString()) != 1)
                                        otc.Rows[index + qty.Count]["Flag"] += "'";

                                } else if (sumQty == totalQty) {
                                    otc.Rows[index][buySell] = qty[0];
                                    for (int j = 1; j < qty.Count; j++) {
                                        DataRow newRow = otc.NewRow();
                                        newRow.ItemArray = row1.ItemArray;
                                        newRow[buySell] = qty[j];
                                        otc.Rows.InsertAt(newRow, index);
                                    }

                                } else {
                                    Console.WriteLine("Something is wrong with WID = " + WID + " brokerCode " + brokerCode);
                                    for (int j = 0; j < qty.Count; j++) {
                                        Console.Write(qty[j] + " ");
                                    }
                                    Console.WriteLine(totalQty);
                                }
                            }

                            #endregion

                        } else if (brokerCode.EndsWith("0")) {
                            endWith0.Add(brokerCode);
                            lock (lockOTC)
                                otc.Rows[otc.Rows.IndexOf(row1)]["Flag"] = "RetailInvestors";
                        } else
                            lock (lockOTC)
                                otc.Rows[otc.Rows.IndexOf(row1)]["Flag"] = "RetailInvestors";
                    }*/


					//OTCPrice("Buy", WID, relatedSnapshot);
					//OTCPrice("Sell", WID, relatedSnapshot);

					//}
					#endregion
				}

			});

            Utility.SaveToCSV(twse, $".\\Patwse{todayStr}.csv", true);//
			Utility.SaveToCSV(allRelatedSnapshot, $".\\PaallRelatedSnapShot{todayStr}.csv", true);//
			//Utility.SaveToCSV(twseVol, ".\\twseVol.csv", true);//
	        //Utility.SaveToCSV(twseCD, ".\\twseCD.csv", true);//
			Utility.SaveToCSV(otc, ".\\otc.csv", Encoding.UTF8, true);//
            //Utility.SaveToCSV(otcB, ".\\otcB.csv", Encoding.UTF8, true);//
            stopWatch.Stop();
            Console.WriteLine("Done in " + stopWatch.Elapsed);
            log.Close();
            Console.ReadKey();
        }
    }
}


























/*static void OTCPrice(string buySell, string WID, DataTable relatedSnapshot) {
          //Get Price and aggregated Qty
          var relatedPrice = from relatedQty in
                            (from sampleRow in relatedSnapshot.AsEnumerable()
                             group sampleRow by sampleRow["LastPx.w"] into g
                             orderby g.Key
                             select new {
                                 GroupKey = double.Parse(g.Key.ToString()),
                                 SumValue = g.Sum(p => int.Parse(p["Qty"].ToString()))
                             })
                             join otcQty in
                                  (from otcRow in otc.AsEnumerable()
                                   where otcRow["WID"].ToString() == WID
                                   group otcRow by otcRow["Price"] into g2
                                   orderby g2.Key
                                   select new {
                                       GroupKey = double.Parse(g2.Key.ToString()),
                                       SumValue = g2.Sum(p => int.Parse(p[buySell].ToString()))
                                   })
                             on relatedQty.GroupKey equals otcQty.GroupKey into finalGroup
                             from otcQty in finalGroup.DefaultIfEmpty()
                             select new { Price = relatedQty.GroupKey, Qty = relatedQty.SumValue - (otcQty == null ? 0 : otcQty.SumValue) };

          var relatedPricePositives = from sampleRow in relatedPrice
                                      where sampleRow.Price > 0 && sampleRow.Qty > 0
                                      orderby sampleRow.Qty descending
                                      select sampleRow;

          // MM or Prop
          var otcPrice0 = from sampleRow in otc.AsEnumerable()
                          where sampleRow["WID"].ToString() == WID && sampleRow[buySell].ToString() != "0"
                          && sampleRow["Price"].ToString() == "0" && !sampleRow["Flag"].ToString().EndsWith("'")
                          orderby sampleRow[buySell] descending
                          select sampleRow;

#if DEBUG
          /*Console.WriteLine(WID + " 1");
           log.WriteLine(WID + " 1");
           foreach (var price in otcPrice0) {
               Console.WriteLine(price[buySell]);
               log.WriteLine(price[buySell]);
           }
           foreach (var group in relatedPricePositives) {
               Console.WriteLine(group.Qty + " " + group.Price);
               log.WriteLine(group.Qty + " " + group.Price);
           }
#endif

          //QTY ==
          foreach (var otcPrice in otcPrice0.ToArray()) {
              var equal = from sampleRow in relatedPricePositives
                          where sampleRow.Qty == int.Parse(otcPrice[buySell].ToString())
                          select sampleRow;
              if (equal.Count() > 0) {
                  int index = otc.Rows.IndexOf(otcPrice);
                  otc.Rows[index]["Price"] = equal.First().Price;
              }
          }

          foreach (var otcPrice1 in otcPrice0.ToArray()) {
              foreach (var otcPrice2 in otcPrice0.ToArray()) {
                  if (otcPrice1["BrokerCode"] == otcPrice2["BrokerCode"] && otcPrice1[buySell] == otcPrice2[buySell])
                      continue;

                  var greaterOrEqual = from sampleRow in relatedPricePositives
                                       where sampleRow.Qty == int.Parse(otcPrice1[buySell].ToString()) + int.Parse(otcPrice2[buySell].ToString())
                                       //orderby sampleRow.Qty //
                                       select sampleRow;
                  if (greaterOrEqual.Count() > 0) {
                      double price = greaterOrEqual.First().Price;
                      int index = otc.Rows.IndexOf(otcPrice2);
                      otc.Rows[index]["Price"] = price;
                      index = otc.Rows.IndexOf(otcPrice1);
                      otc.Rows[index]["Price"] = price;

                      break;
                  }
              }
          }


          //Qty >=
          foreach (var otcPrice in otcPrice0.ToArray()) {
              var greaterOrEqual = from sampleRow in relatedPricePositives
                                   where sampleRow.Qty >= int.Parse(otcPrice[buySell].ToString())
                                   orderby sampleRow.Qty //
                                   select sampleRow;
              if (greaterOrEqual.Count() == 1) {
                  int index = otc.Rows.IndexOf(otcPrice);
                  otc.Rows[index]["Price"] = greaterOrEqual.First().Price;
              }
          }

          //QTY ==
          foreach (var otcPrice in otcPrice0.ToArray()) {
              var equal = from sampleRow in relatedPricePositives
                          where sampleRow.Qty == int.Parse(otcPrice[buySell].ToString())
                          select sampleRow;
              if (equal.Count() > 0) {
                  int index = otc.Rows.IndexOf(otcPrice);
                  otc.Rows[index]["Price"] = equal.First().Price;
              }
          }

          // MM Prop MM' Prop'
          otcPrice0 = from sampleRow in otc.AsEnumerable()
                      where sampleRow["WID"].ToString() == WID && sampleRow[buySell].ToString() != "0"
                      && sampleRow["Price"].ToString() == "0"
                      orderby sampleRow["Flag"]
                      select sampleRow;

          var distinctBrokers = (from sampleRow in otcPrice0
                                 select sampleRow["BrokerCode"]).Distinct();

          foreach (var otcPrice in otcPrice0.ToArray()) {
              var equal = from sampleRow in relatedPricePositives
                          where sampleRow.Qty == int.Parse(otcPrice[buySell].ToString())
                          select sampleRow;
              if (equal.Count() > 0) {
                  UpdateOTCPrice(otcPrice, equal.First().Price);
              }
          }

          if (distinctBrokers.Count() == 1) {
              foreach (var positive in relatedPricePositives) {
                  bool found = false;
                  foreach (var otcPrice in otcPrice0) {
                      if (positive.Qty == int.Parse(otcPrice[buySell].ToString())) {
                          UpdateOTCPrice(otcPrice, positive.Price);
                          found = true;
                          break;
                      }
                  }
                  if (!found && otcPrice0.Count() > 0) {
                      DataRow oldRow = otcPrice0.Last();
                      int index = otc.Rows.IndexOf(oldRow);

                      otc.Rows[index][buySell] = int.Parse(otc.Rows[index][buySell].ToString()) - positive.Qty;

                      DataRow newRow = otc.NewRow();
                      newRow.ItemArray = oldRow.ItemArray;
                      newRow["Price"] = positive.Price;
                      newRow[buySell] = positive.Qty;
                      newRow["Flag"] = newRow["Flag"].ToString().TrimEnd('\'');
                      otc.Rows.InsertAt(newRow, index);
                  }
              }

          } else {
              for (int i = 0; i < 5; i++) {
                  //while (otcPrice0.Count() > 0) {
                  foreach (var otcPrice in otcPrice0.OrderByDescending(a => a[buySell])) {
                      var greaterOrEqual = from sampleRow in relatedPricePositives
                                           where sampleRow.Qty >= int.Parse(otcPrice[buySell].ToString())
                                           orderby sampleRow.Qty
                                           select sampleRow;
                      if (greaterOrEqual.Count() > 0) {
                          UpdateOTCPrice(otcPrice, greaterOrEqual.First().Price);
                      }
                  }

                  foreach (var otcPrice in otcPrice0.ToArray()) {
                      var equal = from sampleRow in relatedPricePositives
                                  where sampleRow.Qty == int.Parse(otcPrice[buySell].ToString())
                                  select sampleRow;
                      if (equal.Count() > 0) {
                          UpdateOTCPrice(otcPrice, equal.First().Price);
                      }
                  }

                  if (relatedPricePositives.Count() == 1) {
                      foreach (var otcPrice in otcPrice0) {
                          UpdateOTCPrice(otcPrice, relatedPricePositives.First().Price);
                      }
                  }

                  if (otcPrice0.Count() == 1) {

                      DataRow oldRow = otcPrice0.First();
                      int index = otc.Rows.IndexOf(oldRow);
                      otc.Rows[index]["Flag"] = otc.Rows[index]["Flag"].ToString().TrimEnd('\'');

                      foreach (var positive in relatedPricePositives) {

                          if (positive.Qty != int.Parse(oldRow[buySell].ToString())) {
                              DataRow newRow = otc.NewRow();
                              newRow.ItemArray = oldRow.ItemArray;
                              newRow["Price"] = positive.Price;
                              newRow[buySell] = positive.Qty;
                              otc.Rows.InsertAt(newRow, index + 1);
                              otc.Rows[index][buySell] = int.Parse(oldRow[buySell].ToString()) - positive.Qty;
                          } else
                              otc.Rows[index]["Price"] = positive.Price;
                      }
                  }

                  foreach (var positive in relatedPricePositives.OrderByDescending(a => a.Qty)) {
                      var lessOrEqual = from sampleRow in otcPrice0
                                        where int.Parse(sampleRow[buySell].ToString()) >= positive.Qty
                                        orderby sampleRow[buySell] descending
                                        select sampleRow;
                      if (lessOrEqual.Count() > 0) {
                          DataRow oldRow = lessOrEqual.First();
                          int index = otc.Rows.IndexOf(oldRow);
                          otc.Rows[index]["Flag"] = otc.Rows[index]["Flag"].ToString().TrimEnd('\'');

                          if (int.Parse(oldRow[buySell].ToString()) > positive.Qty) {
                              DataRow newRow = otc.NewRow();
                              newRow.ItemArray = oldRow.ItemArray;
                              newRow["Price"] = positive.Price;
                              newRow[buySell] = positive.Qty;
                              otc.Rows.InsertAt(newRow, index + 1);
                              otc.Rows[index][buySell] = int.Parse(oldRow[buySell].ToString()) - positive.Qty;
                          } else
                              otc.Rows[index]["Price"] = positive.Price;
                      }
                  }


                  /*foreach (var positive in relatedPricePositives) {
                      foreach (var positive2 in relatedPricePositives) {
                          if (positive2.Price == positive.Price)
                              continue;
                          var twoToOne = from row in otcPrice0
                                         where (positive.Qty + positive2.Qty) == int.Parse(row[buySell].ToString())
                                         && row["Flag"].ToString().EndsWith("'") //
                                         select row;
                          if (twoToOne.Count() > 0) {
                              DataRow oldRow = twoToOne.Last();
                              int index = otc.Rows.IndexOf(oldRow);

                              otc.Rows[index][buySell] = positive2.Qty;
                              otc.Rows[index]["Price"] = positive2.Price;
                              otc.Rows[index]["Flag"] = otc.Rows[index]["Flag"].ToString().TrimEnd('\'');

                              DataRow newRow = otc.NewRow();
                              newRow.ItemArray = oldRow.ItemArray;
                              newRow["Price"] = positive.Price;
                              newRow[buySell] = positive.Qty;
                              //newRow["Flag"] = newRow["Flag"].ToString().TrimEnd('\'');
                              otc.Rows.InsertAt(newRow, index);

                              break;
                          }
                      }
                  }

                  if (otcPrice0.Count() == 1) {

                      DataRow oldRow = otcPrice0.First();
                      int index = otc.Rows.IndexOf(oldRow);
                      otc.Rows[index]["Flag"] = otc.Rows[index]["Flag"].ToString().TrimEnd('\'');

                      foreach (var positive in relatedPricePositives) {

                          if (positive.Qty != int.Parse(oldRow[buySell].ToString())) {
                              DataRow newRow = otc.NewRow();
                              newRow.ItemArray = oldRow.ItemArray;
                              newRow["Price"] = positive.Price;
                              newRow[buySell] = positive.Qty;
                              otc.Rows.InsertAt(newRow, index + 1);
                              otc.Rows[index][buySell] = int.Parse(oldRow[buySell].ToString()) - positive.Qty;
                          } else
                              otc.Rows[index]["Price"] = positive.Price;
                      }
                  }
                  if (otcPrice0.Count() == 0)
                      break;
                  Console.WriteLine(i);
                  log.WriteLine(i);
              }
          }
#if DEBUG
          Console.WriteLine(WID);
          log.WriteLine(WID);
          foreach (var price in otcPrice0) {
              Console.WriteLine(price[buySell]);
              log.WriteLine(price[buySell]);
          }
          foreach (var group in relatedPricePositives) {
              Console.WriteLine(group.Qty + " " + group.Price);
              log.WriteLine(group.Qty + " " + group.Price);
          }
#endif

      }*/
/*public static IEnumerable<IEnumerable<T>> DifferentCombinations<T>(this IEnumerable<T> elements, int k) {
    return k == 0 ? new[] { new T[0] } :
      elements.SelectMany((e, i) =>
        elements.Skip(i + 1).DifferentCombinations(k - 1).Select(c => (new[] { e }).Concat(c)));
}*/

/*public static IEnumerable<IEnumerable<T>> GetKCombs<T>(IEnumerable<T> list, int length) where T : IComparable {
    if (length == 1) return list.Select(t => new T[] { t });
    return GetKCombs(list, length - 1)
        .SelectMany(t => list.Where(o => o.CompareTo(t.Last()) > 0),
            (t1, t2) => t1.Concat(new T[] { t2 }));
}*/