﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using EDLib;
using EDLib.SQL;
using System.IO;
using System.IO.Compression;
using System.Net;

namespace IndexFuturesDailyTickData
{
    class Program
    {
        static string todayStr = TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");
        static string _todayYear = todayStr.Substring(0, 4);
        static string _todayMonth = todayStr.Substring(4, 2);
        static string _todayDay = todayStr.Substring(6, 2);

        static void Zipcompress(string source, string dest)
        {
            using (ZipArchive archive = ZipFile.OpenRead(source))
            {
                foreach (ZipArchiveEntry entry in archive.Entries)
                {
                    if (entry.FullName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase))
                    {
                        string destinationPath = Path.GetFullPath(Path.Combine(dest, entry.FullName));
                        if (!File.Exists(destinationPath))
                            entry.ExtractToFile(destinationPath);
                    }
                }
            }
        }

        static void Main(string[] args)
        {
            try
            {
                string _todayStr = _todayYear + "_" + _todayMonth + "_" + _todayDay;
                //string zipPathName = $".\\Daily_{_todayStr}.zip";
                //string csvPath = $".\\";
                string zipPath = $"C:\\Users\\0006352\\Documents\\R_WorkSpace\\TAIFEX\\TXF\\Daily_{_todayStr}.zip";
                string csvPath = $"C:\\Users\\0006352\\Documents\\R_WorkSpace\\TAIFEX\\TXF\\CSV\\";

                string zipPath_C = $"C:\\Users\\0006352\\Documents\\R_WorkSpace\\TAIFEX\\FuturesSpread\\Daily_{_todayStr}_C.zip";
                string csvPath_C = $"C:\\Users\\0006352\\Documents\\R_WorkSpace\\TAIFEX\\FuturesSpread\\CSV\\";

                string zipPath_B = $"C:\\Users\\0006352\\Documents\\R_WorkSpace\\TAIFEX\\SpreadDailyStatistics\\Daily_{_todayStr}_B.zip";
                string csvPath_B = $"C:\\Users\\0006352\\Documents\\R_WorkSpace\\TAIFEX\\SpreadDailyStatistics\\CSV\\";

                //抓期交所資料(Futures TickData Download)
                WebClient wc = new WebClient();

                #region 前30個交易日期貨每筆成交資料
                Console.WriteLine($"{todayStr} Future Data Download...");
                wc.DownloadFile($"http://www.taifex.com.tw/file/taifex/Dailydownload/DailydownloadCSV/Daily_{_todayStr}.zip", zipPath);
                Zipcompress(zipPath, csvPath);
                #endregion

                #region 前30個交易日期貨價差每筆成交資料
                Console.WriteLine($"{todayStr} FutureSpread Data Download...");
                wc.DownloadFile($"http://www.taifex.com.tw/file/taifex/Dailydownload/DailydownloadCSV_C/Daily_{_todayStr}_C.zip", zipPath_C);
                Zipcompress(zipPath_C, csvPath_C);
                #endregion


                #region 前30個交易日期貨價差委託成交概況表
                Console.WriteLine($"{todayStr} FutureSpread Daily Statistics Data Download...");
                wc.DownloadFile($"http://www.taifex.com.tw/file/taifex/Dailydownload/DailydownloadCSV_B/Daily_{_todayStr}_B.zip", zipPath_B);
                Zipcompress(zipPath_B, csvPath_B);

                #endregion


            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }
    }
}
