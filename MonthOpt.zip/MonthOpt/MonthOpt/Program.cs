﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Net;
using System.Data;
using System.Data.SqlClient;
using EDLib;
using EDLib.SQL;
using System.IO;

namespace MonthOpt
{
	class Program
	{

		static DataTable ReadFile(string path)
		{
			int count = 0;
			DataTable dt = new DataTable();
			using (StreamReader sr = new StreamReader(path, Encoding.GetEncoding("Big5")))
			{
				string[] headers = sr.ReadLine().Split(',');
				foreach (string header in headers)
				{
					dt.Columns.Add($"{header}{count}");
					count += 1;
				}
				while (!sr.EndOfStream)
				{
					List<string> rows = sr.ReadLine().Split(',').ToList();
					if (rows[0] == "Date")
						rows.Add("");
					DataRow dr = dt.NewRow();
					for (int i = 0; i < headers.Length; i++)
					{
						dr[i] = rows[i];
					}
					dt.Rows.Add(dr);
				}
			}
			return dt;
		}

		static void SaveToCSV(DataTable oTable, string FilePath)
		{
			string data = "";
			StreamWriter wr = new StreamWriter(FilePath, false, Encoding.GetEncoding("Big5"));
			foreach (DataColumn column in oTable.Columns)
			{
				data += column.ColumnName + ",";
			}
			data += "\n";
			wr.Write(data);
			data = "";

			foreach (DataRow row in oTable.Rows)
			{
				foreach (DataColumn column in oTable.Columns)
				{
					data += row[column].ToString().Trim() + ",";
				}
				data += "\n";
				wr.Write(data);
				data = "";
			}
			data += "\n";
			wr.Dispose();
			wr.Close();
		}

		static DataTable InitializeTables()
		{
			DataTable dt = new DataTable();
			dt.Columns.Add("TDate", typeof(string));
			dt.Columns.Add("BrokerID", typeof(string));
			dt.Columns.Add("BrokerName", typeof(string));
			dt.Columns.Add("OptionID", typeof(string));
			dt.Columns.Add("DayQty", typeof(double));
			dt.Columns.Add("NightQty", typeof(double));
			dt.Columns.Add("TotalQty", typeof(double));
			return dt;
		}

		static DataTable InitializeDNTables()
		{
			DataTable dt = new DataTable();
			dt.Columns.Add("TDate", typeof(string));
			dt.Columns.Add("BrokerID", typeof(string));
			dt.Columns.Add("BrokerName", typeof(string));
			dt.Columns.Add("OptionID", typeof(string));
			dt.Columns.Add("Qty", typeof(double));
			return dt;
		}

		static void Main(string[] args)
		{
			//string[] dayorAll = { "Day", "All" };
			List<DataTable> summary = new List<DataTable>();

			//foreach (string dn in dayorAll)
			//{
				DataTable optBroker = ReadFile($".\\Monthly_Opt.csv");
				var Date = optBroker.AsEnumerable().First().ItemArray;
				int[] allDateIndex = Date.Select((r, i) => r.ToString().Contains("2017") ||
														r.ToString().Contains("99999999") ? i : -1).Where(i => i != -1).ToArray();
				//int[] dateIndex = { allDateIndex[allDateIndex.Length - 2], allDateIndex[allDateIndex.Length - 1] };
				DataTable result = InitializeDNTables();
				for (int i = 1; i < optBroker.Rows.Count; i++) // # of Rows
				{
					for (int j = 0; j < allDateIndex.Length - 1; j++) // dateIndex
					{
						for (int k = allDateIndex[j]; k < allDateIndex[j + 1] - 1; k++) // dateInterval
						{
							DataRow newRow = result.NewRow();
							string TDate = optBroker.Rows[0][allDateIndex[j]].ToString();
							string BrokerID = optBroker.Rows[i][0].ToString();
							string BrokerName = optBroker.Rows[i][1].ToString();
							string OptionID = Regex.Replace(optBroker.Columns[k].ColumnName.ToString(), @"[0-9]", string.Empty);
							double Qty = double.Parse(optBroker.Rows[i][k].ToString());
							newRow["TDate"] = TDate;
							newRow["BrokerID"] = BrokerID;
							newRow["BrokerName"] = BrokerName;
							newRow["OptionID"] = OptionID;
							newRow["Qty"] = Qty;
							result.Rows.Add(newRow);
						}
					}
				}
				summary.Add(result);
			//}
			/*
			var finalresult = from row1 in summary[0].AsEnumerable()
							  join row2 in summary[1].AsEnumerable() on
							  new { TDate = row1.Field<string>("TDate"), BrokerID = row1.Field<string>("BrokerID"), OptionID = row1.Field<string>("OptionID") }
							  equals
							  new { TDate = row2.Field<string>("TDate"), BrokerID = row2.Field<string>("BrokerID"), OptionID = row2.Field<string>("OptionID") }
							  into temp
							  from row2 in temp.DefaultIfEmpty()
							  select new
							  {
								  TDate = row1.Field<string>("TDate"),
								  BrokerID = row1.Field<string>("BrokerID"),
								  BrokerName = row1.Field<string>("BrokerName"),
								  OptionID = row1.Field<string>("OptionID"),
								  DayQty = row1.Field<double>("Qty"),
								  AllQty = row2.Field<double>("Qty"),
							  };
							  */

			DataTable optBrokerVolumeData = InitializeTables();
			foreach (DataRow row in summary[0].Rows)
			{
				DataRow newRow = optBrokerVolumeData.NewRow();
				newRow["TDate"] = row["TDate"].ToString().Substring(0, 4) + "-" + row["TDate"].ToString().Substring(4, 2);//row.TDate;
				newRow["BrokerID"] = row["BrokerID"].ToString();//row.BrokerID;
				newRow["BrokerName"] = row["BrokerName"].ToString();//row.BrokerName;
				newRow["OptionID"] = row["OptionID"].ToString();//row.OptionID;
																//newRow["DayQty"] = row.DayQty;
																//newRow["NightQty"] = row.AllQty - row.DayQty;
				newRow["TotalQty"] = double.Parse(row["Qty"].ToString());//row.AllQty;
				optBrokerVolumeData.Rows.Add(newRow);
#if !DEBUG
				string sqlInsert = $"Insert OptionVolume Values( '{row.TDate}', '{row.BrokerID}', " +
					$"'{row.BrokerName}', '{row.OptionID}', {row.DayQty}, {row.AllQty} - {row.DayQty}, {row.AllQty})";
				try
				{
					MSSQL.ExecSqlCmd(sqlInsert, testEDIS);
				}
				catch (Exception e)
				{
					MailService ms = new MailService();
					ms.SendMail("jerry.zeng@kgi.com", "10.19.1.45", new string[] { "jerry.zeng@kgi.com" }, null, null, "OptionVolume Fail", e.Message + "\n" + sqlInsert, false, null);
				}
#endif
			}
			SaveToCSV(optBrokerVolumeData, ".\\Optdata2017.csv");
		}
	}
}

