﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//using Excel = Microsoft.Office.Interop.Excel;
using EDLib;
using EDLib.SQL;

namespace twFuture
{

    public partial class Form1 : Form
    {
        static string todayStr = TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");
        static string _todayYear = todayStr.Substring(0, 4);
        static string _todayMonth = todayStr.Substring(4, 2);
        static string _todayDay = todayStr.Substring(6, 2);

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)   //讀期交所TXF成交資料明細
        {
            string _todayStr = _todayYear + "_" + _todayMonth + "_" + _todayDay;

            #region 從csv檔案讀取指數期貨商品交易資料
            /// <summary>
            /// 從csv檔案讀取個股期貨商品交易資料
            /// </summary>
            ///     
            //string strPath2 = @"H:\licheng\twfuture\20190107\20190104_CDF_201901.csv";
            //string strPath1 = @"H:\licheng\twfuture\20190107\";
            string strPath2 = $"C:\\Users\\0006352\\Documents\\R_WorkSpace\\TAIFEX\\TXF\\CSV\\";
            string strPath1 = $"C:\\Users\\0006352\\Documents\\R_WorkSpace\\TAIFEX\\TXF\\CSV\\";

            System.IO.FileInfo FileAttribute = new FileInfo(strPath1);
            FileAttribute.Attributes = FileAttributes.Normal;

            List<string> dirs = new List<string>();

            #region 找出資料夾下所有檔案
            foreach (string f in Directory.GetFiles(strPath1))
            {
                //先針對目前目路的檔案做處理 
                dirs.Add(f);
            }
            #endregion

            int MaxFileNumer = dirs.Count-1;
            //開啟CSV檔案
            StreamReader sr = new StreamReader(dirs[MaxFileNumer], System.Text.Encoding.Default);
            //StreamReader sr2 = new StreamReader(strPath2, System.Text.Encoding.Default);
            //StreamReader sr3 = new StreamReader(strPath3, System.Text.Encoding.Default);
            //StreamReader sr4 = new StreamReader(strPath4, System.Text.Encoding.Default);
            string line;

            string file;
            string aa = dirs[0].Substring(dirs[MaxFileNumer].Length - 23, 19);
            string[] bb = aa.Split('_');
            string TradeDate = bb[0];
            string CommodityId = bb[1];
            string MaturityMonth = bb[2];
            string CommodityName = "";

            int counter = 0;

            double Price;
            int TotalVolume;
            string BuyFutInstitutionId;
            string BuyFutInstitutionName;
            string SellFutInstitutionId;
            string SellFutInstitutionName;

            line = sr.ReadLine();  //跳過第1行表頭
            line = sr.ReadLine();  //跳過第2行表頭
            while ((line = sr.ReadLine()) != null)
            {
                string[] ReadLine_Array = line.Split(',');
                //valueDate = Convert.ToDateTime(ReadLine_Array[0]);
                Price = Convert.ToDouble(ReadLine_Array[0]);
                TotalVolume = Convert.ToInt32(ReadLine_Array[1]);
                BuyFutInstitutionId = Convert.ToString(ReadLine_Array[2]);
                BuyFutInstitutionName = Convert.ToString(ReadLine_Array[3]);
                SellFutInstitutionId = Convert.ToString(ReadLine_Array[4]);
                SellFutInstitutionName = Convert.ToString(ReadLine_Array[5]);
            }


            #endregion
        }

        static DataTable InitializeTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("UID");
            dt.Columns.Add("MatchTime");
            dt.Columns.Add("LastP");
            dt.Columns.Add("LastQ");
            dt.Columns.Add("TotalQ");
            dt.Columns.Add("Bid1P");
            dt.Columns.Add("Bid1Q");
            dt.Columns.Add("Ask1P");
            dt.Columns.Add("Ask1Q");
            return dt;
        }

        static DataTable InitializeTable2()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("No");
            dt.Columns.Add("UID");
            dt.Columns.Add("MatchTime");
            //dt.Columns.Add("LastP");
            //dt.Columns.Add("LastQ");
            dt.Columns.Add("TotalQ");
            dt.Columns.Add("Bid1P");
            dt.Columns.Add("Bid1Q");
            dt.Columns.Add("Ask1P");
            dt.Columns.Add("Ask1Q");
            //futures
            dt.Columns.Add("FID");
            dt.Columns.Add("FMatchTime");
            //dt.Columns.Add("FLastP");
            //dt.Columns.Add("FLastQ");
            dt.Columns.Add("FTotalQ");
            dt.Columns.Add("FBid1P");
            dt.Columns.Add("FBid1Q");
            dt.Columns.Add("FAsk1P");
            dt.Columns.Add("FAsk1Q");
            //Statistics
            dt.Columns.Add("BStk_SFut");
            dt.Columns.Add("SStk_BFut");
            return dt;
        }

        private void button2_Click(object sender, EventArgs e)  //讀KGI個股期Tick資料
        {

            /// <summary>
            /// 從csv檔案讀取個股期貨商品交易資料
            /// </summary>
            /// 
            //string strPath2 = @"H:\licheng\twfuture\20190107\20190104_CDF_201901.csv";
            //string strPath1 = ".\\StockData\\";
            string strPath1 = $"C:\\Users\\0006352\\Documents\\R_WorkSpace\\DataSource\\{todayStr}\\";
            
            //string strPath1 = $"\\10.19.1.149\\TickViewerData\\Price\\{todayStr}\\";


            //string strPath1 = @"C:\Users\0006352\Documents\R_WorkSpace\DataSource\20181107\";
            System.IO.FileInfo FileAttribute = new FileInfo(strPath1);
            FileAttribute.Attributes = FileAttributes.Normal;

            List<string> dirs = new List<string>();

            #region 找出資料夾下所有檔案
            foreach (string f in Directory.GetFiles(strPath1))
            {
                //先針對目前目路的檔案做處理 
                dirs.Add(f);
            }
            #endregion

            int MaxFileNumer = dirs.Count - 1; 

            //開啟CSV檔案
            StreamReader sr = new StreamReader(dirs[MaxFileNumer], System.Text.Encoding.Default);
            //StreamReader sr2 = new StreamReader(strPath2, System.Text.Encoding.Default);
            //StreamReader sr3 = new StreamReader(strPath3, System.Text.Encoding.Default);
            //StreamReader sr4 = new StreamReader(strPath4, System.Text.Encoding.Default);


            //string file;
            //string aa = dirs[0].Substring(dirs[0].Length - 23, 19);
            //string[] bb = aa.Split('_');
            //string TradeDate = bb[0];
            //string CommodityId = bb[1];
            //string MaturityMonth = bb[2];
            //string CommodityName = "";

            #region 讀csv資料到變數
            //string line;
            //int counter = 0;
            //string CommodityId;
            //string CommodityNm;
            //string MatchTime;
            //double LastP;
            //int LastQ;
            //int TotalQ;
            //double Bid1P;
            //double Bid1Q;
            //double Ask1P;
            //double Ask1Q;
            //string UnderlyingId;
            //string Kind;
            //string InformationSeq;
            //string InformationTime;
            //string MatchSeq;
            //double Bid2P;
            //int Bid2Q;
            //double Ask2P;
            //int Ask2Q;
            //double Bid3P;
            //int Bid3Q;
            //double Ask3P;
            //int Ask3Q;
            //double Bid4P;
            //int Bid4Q;
            //double Ask4P;
            //int Ask4Q;
            //double Bid5P;
            //int Bid5Q;
            //double Ask5P;
            //int Ask5Q;
            //string Maturity;
            //double Strike;
            //string RecTime;
            //string AdjustTime;

            //while ((line = sr.ReadLine()) != null)
            //{
            //    string[] ReadLine_Array = line.Split(',');
            //    CommodityId = Convert.ToString(ReadLine_Array[0]);
            //    CommodityNm = Convert.ToString(ReadLine_Array[1]);
            //    MatchTime = Convert.ToString(ReadLine_Array[2]);
            //    LastP = Convert.ToDouble(ReadLine_Array[3]);
            //    LastQ = Convert.ToInt32(ReadLine_Array[4]);
            //    TotalQ = Convert.ToInt32(ReadLine_Array[5]);
            //    Bid1P = Convert.ToDouble(ReadLine_Array[6]); 
            //    Bid1Q = Convert.ToInt32(ReadLine_Array[7]);
            //    Ask1P = Convert.ToDouble(ReadLine_Array[8]); 
            //    Ask1Q = Convert.ToInt32(ReadLine_Array[9]);
            //    UnderlyingId = Convert.ToString(ReadLine_Array[10]);
            //    Kind = Convert.ToString(ReadLine_Array[11]); 
            //    InformationSeq = Convert.ToString(ReadLine_Array[12]); 
            //    InformationTime = Convert.ToString(ReadLine_Array[13]);
            //    MatchSeq = Convert.ToString(ReadLine_Array[14]);
            //    Bid2P = Convert.ToDouble(ReadLine_Array[15]);
            //    Bid2Q = Convert.ToInt32(ReadLine_Array[16]);
            //    Ask2P = Convert.ToDouble(ReadLine_Array[17]);
            //    Ask2Q = Convert.ToInt32(ReadLine_Array[18]);
            //    Bid3P = Convert.ToDouble(ReadLine_Array[19]);
            //    Bid3Q = Convert.ToInt32(ReadLine_Array[20]);
            //    Ask3P = Convert.ToDouble(ReadLine_Array[21]);
            //    Ask3Q = Convert.ToInt32(ReadLine_Array[22]);
            //    Bid4P = Convert.ToDouble(ReadLine_Array[23]);
            //    Bid4Q = Convert.ToInt32(ReadLine_Array[24]);
            //    Ask4P = Convert.ToDouble(ReadLine_Array[25]);
            //    Ask4Q = Convert.ToInt32(ReadLine_Array[26]);
            //    Bid5P = Convert.ToDouble(ReadLine_Array[27]);
            //    Bid5Q = Convert.ToInt32(ReadLine_Array[28]);
            //    Ask5P = Convert.ToDouble(ReadLine_Array[29]);
            //    Ask5Q = Convert.ToInt32(ReadLine_Array[30]);
            //    Maturity = Convert.ToString(ReadLine_Array[31]);
            //    Strike = Convert.ToDouble(ReadLine_Array[32]);
            //    RecTime = Convert.ToString(ReadLine_Array[33]);
            //    if (RecTime == "")
            //    {
            //        RecTime = "13:45:00.000000";
            //    }
            //    //AdjustTime = Convert.ToString(ReadLine_Array[34]);

            //}

            #endregion

            DataTable dt = new DataTable();
            dt = ConvertFutCSVtoDataTable(dirs[MaxFileNumer], false);
            //dt.Columns.Add("是否成交", typeof(double));
            //var temp1 = dt.Select("TotalQ = 0");
            DataTable summary = InitializeTable();

            #region Method1 to select records which TotalQ > 0
            //foreach (DataRow row in dt.Rows)
            //{
            //    //if (int.Parse(row["TotalQ"].ToString()) > 0)
            //    if (row["TotalQ"].ToString() != "0")
            //    {
            //        DataRow newRow = summary.NewRow();
            //        newRow["MatchTime"] = row["MatchTime"].ToString();
            //        newRow["UID"] = row["CommodityId"].ToString();
            //        newRow["LastP"] = row["LastP"].ToString();
            //        newRow["LastQ"] = row["LastQ"].ToString();
            //        newRow["TotalQ"] = row["TotalQ"].ToString();
            //        summary.Rows.Add(newRow);
            //    }
            //}
            #endregion

            #region Method2 to select records which TotalQ > 0
            //--test--var dtresult = dt.AsEnumerable().Where(r => r["TotalQ"].ToString() != "0");
            var dtresult = from r in dt.AsEnumerable()
                           where Convert.ToDouble(r["TotalQ"]) > 0
                           //where r["TotalQ"].ToString() != "0"  
                           //where r.Field<string>("TotalQ") != "0")  //另一種寫法
                           select r;

            if (dtresult.Count() > 0)
            {
                List<DataRow> result = dtresult.ToList();
                foreach (DataRow dr in result)
                {
                    DataRow newRow = summary.NewRow();
                    newRow["MatchTime"] = dr["MatchTime"].ToString();
                    newRow["UID"] = dr["CommodityId"].ToString();
                    newRow["LastP"] = dr["LastP"].ToString();
                    newRow["LastQ"] = dr["LastQ"].ToString();
                    newRow["TotalQ"] = dr["TotalQ"].ToString();
                    newRow["Bid1P"] = dr["Bid1P"].ToString();
                    newRow["Bid1Q"] = dr["Bid1Q"].ToString();
                    newRow["Ask1P"] = dr["Ask1P"].ToString();
                    newRow["Ask1Q"] = dr["Ask1Q"].ToString();
                    summary.Rows.Add(newRow);
                }
            }

            #endregion
            //資料放到DataGridView
            //dataGridView1.DataSource = dt;
            dataGridView1.DataSource = summary;

            //Utility.SaveToCSV(dt, ".\\股期Tick資料.csv", true);

   

        }
        /// <summary>
        /// 將個股期CSV文件的數據讀取到DataTable中
        /// </summary>
        /// <param name="fileName">CSV文件路徑</param>
        /// <returns>返回讀取了個股期CSV數據的DataTable</returns>
        public static DataTable ConvertFutCSVtoDataTable(string strFilePath, bool isheader)
        {

            DataTable dt = new DataTable();
            using (StreamReader sr = new StreamReader(strFilePath, Encoding.GetEncoding("Big5")))
            {
                if (isheader == false)
                {
                    string[] headers = { "CommodityId", "CommodityNm", "MatchTime", "LastP", "LastQ", "TotalQ", "Bid1P", "Bid1Q", "Ask1P", "Ask1Q", "UnderlyingId", "Kind", "InformationSeq", "InformationTime", "MatchSeq", "Bid2P", "Bid2Q", "Ask2P", "Ask2Q", "Bid3P", "Bid3Q", "Ask3P", "Ask3Q", "Bid4P", "Bid4Q", "Ask4P", "Ask4Q", "Bid5P", "Bid5Q", "Ask5P", "Ask5Q", "Maturity", "Strike", "RecTime" };
                    //string[] headers = sr.ReadLine().Split(','); //若無特別指定, 則將第一列內容當表頭
                    foreach (string header in headers)  //write specific header 
                    {
                        dt.Columns.Add(header);
                    }
                }
                else
                {
                    string[] headers = sr.ReadLine().Split(',');
                    foreach (string header in headers)  //read header from csv file
                    {
                        dt.Columns.Add(header);
                    }
                }

                while (!sr.EndOfStream)
                {
                    string[] rows = sr.ReadLine().Split(',');
                    DataRow dr = dt.NewRow();
                    for (int i = 0; i < rows.Length; i++)
                    {
                        dr[i] = rows[i];
                    }
                    dt.Rows.Add(dr);
                }

            }

            return dt;
        }

        /// <summary>
        /// 將CSV文件的數據讀取到DataTable中
        /// </summary>
        /// <param name="fileName">CSV文件路徑</param>
        /// <returns>返回讀取了CSV數據的DataTable</returns>
        public static DataTable ConvertCSVtoDataTable(string strFilePath, bool isheader)
        {
            
                DataTable dt = new DataTable();
                using (StreamReader sr = new StreamReader(strFilePath, Encoding.GetEncoding("Big5")))
                {
                    if (isheader == false)
                    {
                        //string[] headers = { "CommodityId", "CommodityNm", "MatchTime", "LastP", "LastQ", "TotalQ", "Bid1P", "Bid1Q", "Ask1P", "Ask1Q", "UnderlyingId", "Kind", "InformationSeq", "InformationTime", "MatchSeq", "Bid2P", "Bid2Q", "Ask2P", "Ask2Q", "Bid3P", "Bid3Q", "Ask3P", "Ask3Q", "Bid4P", "Bid4Q", "Ask4P", "Ask4Q", "Bid5P", "Bid5Q", "Ask5P", "Ask5Q", "Maturity", "Strike", "RecTime" };
                        string[] headers = sr.ReadLine().Split(','); //若無特別指定, 則將第一列內容當表頭, 計算欄位數
                        int count = 1;
                        foreach (string header in headers)  //write specific header 
                        {
                            dt.Columns.Add("第" + count.ToString()+ "欄");
                            count++;
                        }
                    }
                    else
                    {
                        string[] headers = sr.ReadLine().Split(',');
                        foreach (string header in headers)  //read header from csv file
                        {
                            dt.Columns.Add(header);
                        }
                    }

                    while (!sr.EndOfStream)
                    {
                        string[] rows = sr.ReadLine().Split(',');
                        DataRow dr = dt.NewRow();
                        for (int i = 0; i < rows.Length; i++)
                        {
                            dr[i] = rows[i];
                        }
                        dt.Rows.Add(dr);
                    }

                }

                return dt;
            }


        #region 将DataGridView控件中数据导出到Excel
        /// <summary>
        /// 将DataGridView控件中数据导出到Excel
        /// </summary>
        /// <param name="gridView">DataGridView对象</param>
        /// <param name="isShowExcle">是否显示Excel界面</param>
        /// <returns></returns>
        //public bool ExportDataGridview(DataGridView gridView, bool isShowExcle)
        //{
        //    if (gridView.Rows.Count == 0)
        //        return false;
        //    //建立Excel对象
        //    Excel.Application excel = new Excel.Application();
        //    excel.Application.Workbooks.Add(true);
        //    excel.Visible = isShowExcle;
        //    //生成字段名称
        //    for (int i = 0; i < gridView.ColumnCount; i++)
        //    {
        //        excel.Cells[1, i + 1] = gridView.Columns[i].HeaderText;
        //    }
        //    //填充数据
        //    for (int i = 0; i < gridView.RowCount - 1; i++)
        //    {
        //        for (int j = 0; j < gridView.ColumnCount; j++)
        //        {
        //            if (gridView[j, i].ValueType == typeof(string))
        //            {
        //                excel.Cells[i + 2, j + 1] = "'" + gridView[j, i].Value.ToString();
        //            }
        //            else
        //            {
        //                excel.Cells[i + 2, j + 1] = gridView[j, i].Value.ToString();
        //            }
        //        }
        //    }
        //    return true;
        //}

        #endregion


        static DataTable InitializeTables1()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("StockNo", typeof(string));
            dt.Columns.Add("StockName", typeof(string));
            dt.Columns.Add("Chairman", typeof(string));
            dt.Columns.Add("Industry", typeof(string));
            dt.Columns.Add("Price", typeof(double));
            dt.Columns.Add("Volume", typeof(double));
            dt.Columns.Add("Count", typeof(Int32));
            dt.Columns.Add("Sum", typeof(double));
            dt.Columns.Add("Max", typeof(double));
            return dt;
        }
        /// <summary>
        /// 測試將CSV文件的數據讀取到DataTable中,並顯示在dataGridView
        /// </summary>
        /// <param name="fileName">CSV文件路徑</param>
        /// <returns>讀取CSV數據並顯示在dataGridView</returns>
        private void button3_Click(object sender, EventArgs e)
        {
            #region 從csv檔案讀資料
            DataTable dt1 = new DataTable();
            DataTable dt2 = new DataTable();
            DataTable dt3 = new DataTable();
            string strPath1 = ".\\權證標的.csv";
            string strPath2 = ".\\日收盤還原表排行1.csv";
            string strPath3 = ".\\上市櫃公司基本資料.csv";
            string sqlStr1 = "SELECT * from [上市櫃公司基本資料] A where A.[年度]='2019' ";
            dt1 = ConvertCSVtoDataTable(strPath1, true);
            dt2 = ConvertCSVtoDataTable(strPath2, true);
            //dt3 = CMoney.ExecCMoneyQry(sqlStr1);
            //dataGridView1.DataSource = dt3;
            #endregion

            #region 合併dt1與dt2的資料
            var query = from row1 in dt1.AsEnumerable()
                        join row2 in dt2.AsEnumerable() on
                        //row1.Field<string>("股票代號") equals row2.Field<string>("股票代號")
                        //row1["股票代號"] equals row2["股票代號"]
                        new { StockNo = row1.Field<string>("股票代號") }
                        equals
                        new { StockNo = row2.Field<string>("股票代號") }
                        into temp      //row1 in dt1 Left join row2 in dt2
                        from row2 in temp.DefaultIfEmpty()
                        //where 放這邊 => 找出 收盤價>10 且 成交量>1000 的股票
                        where Convert.ToDouble(row2["成交量"]) > 1000  
                           && Convert.ToDouble(row2["收盤價"]) > 10
                        orderby row2["成交量"] descending   //依成交量高到低排序
                        select new       //{ StockNo = row1["股票代號"] , Price = row2["收盤價"] };
                        {
                            StockNo = row1["股票代號"],
                            StockName = row1["股票名稱"],
                            Chairman = row1["董事長"],
                            Industry = row1["產業名稱"],
                            Price = row2["收盤價"],
                            Volume = row2["成交量"],
                            Count = temp.Count()+10,      //統計相同股票代號者之總個數+10
                            Sum = temp.Sum(row2 => Convert.ToDouble(row2["成交量"])),  //統計相同股票代號,成交量之和
                            Max = temp.Max(row2 => Convert.ToDouble(row2["收盤價"])),  //統計相同股票代號,收盤價最大為何
                        };

            DataTable summary = InitializeTables1();

            summary = query.ToDataTable();  //透過ToDataTable直接轉換為datatable
            dataGridView1.DataSource = summary;

            /// <summary>
            /// 透過DataRow再將資料加到DataTable
            /// </summary>
            //if (query.Count() > 0)
            //{
            //    foreach (var row in query)
            //    {
            //        DataRow newRow = summary.NewRow();
            //        newRow["StockNo"] = row.StockNo;
            //        newRow["StockName"] = row.StockName;
            //        newRow["Chairman"] = row.Chairman;
            //        newRow["Industry"] = row.Industry;
            //        newRow["Price"] = row.Price;
            //        newRow["Volume"] = row.Volume;
            //        newRow["Count"] = row.Count;
            //        newRow["Sum"] = row.Sum;
            //        newRow["Max"] = row.Max;
            //        //newRow["StockNo"] = row.row1["股票代號"];
            //        //newRow["StockName"] = row.row1["股票名稱"];
            //        //newRow["Chairman"] = row.row1["董事長"];
            //        //newRow["Price"] = row.row2["收盤價"];
            //        //newRow["Volume"] = row.row2["成交量"];
            //        summary.Rows.Add(newRow);
            //    }

            //    dataGridView1.DataSource = summary;
            //}

            #endregion
        }
        /// <summary>
        /// 將Cmoney資料數據讀取到DataTable中
        /// </summary>
        /// <param name="fileName">CSV文件路徑</param>
        /// <returns>返回讀取Cmoney數據的DataTable</returns>
        private void button4_Click(object sender, EventArgs e)
        {
            #region 從csv檔案讀資料
            DataTable dt1 = new DataTable();
            DataTable dt2 = new DataTable();
            string sqlStr = "SELECT A.[股票代號], A.[股票名稱], A.[產業名稱], A.[上市上櫃], A.[實收資本額(百萬)], A.[普通股每股面額(元)] from [上市櫃公司基本資料] A where A.[年度]='2019' ";
            dt1 = CMoney.ExecCMoneyQry(sqlStr);
            dataGridView1.DataSource = dt1;
            #endregion
        }

        /// <summary>
        /// 將個股&個股期貨CSV文件的數據讀取到DataTable中,並顯示在dataGridView
        /// </summary>
        /// <param name="fileName">CSV文件路徑</param>
        /// <returns>讀取CSV數據並顯示在dataGridView</returns>
        private void button5_Click(object sender, EventArgs e)
        {
            /// <summary>
            /// 從csv檔案讀取個股期貨商品交易資料
            /// </summary>
            /// 
            //string strPath2 = @"H:\licheng\twfuture\20190107\20190104_CDF_201901.csv";
            string strPath1 = ".\\StockData\\";
            string strPath2 = ".\\StockFuturesData\\";
            //string strPath1 = @"C:\Users\0006352\Documents\R_WorkSpace\DataSource\20181107\";
            System.IO.FileInfo FileAttribute = new FileInfo(strPath1);
            FileAttribute.Attributes = FileAttributes.Normal;

            List<string> dirs = new List<string>();
            List<string> dirs2 = new List<string>();

            #region 找出資料夾下所有檔案
            foreach (string f in Directory.GetFiles(strPath1))
            {
                //先針對目前目路的檔案做處理 
                dirs.Add(f);
            }
            foreach (string f in Directory.GetFiles(strPath2))
            {
                //先針對目前目路的檔案做處理 
                dirs2.Add(f);
            }
            #endregion

            //開啟CSV檔案
            StreamReader sr = new StreamReader(dirs[0], System.Text.Encoding.Default);
            StreamReader sr2 = new StreamReader(dirs2[0], System.Text.Encoding.Default);
            //StreamReader sr3 = new StreamReader(strPath3, System.Text.Encoding.Default);
            //StreamReader sr4 = new StreamReader(strPath4, System.Text.Encoding.Default);


            //string file;
            //string aa = dirs[0].Substring(dirs[0].Length - 23, 19);
            //string[] bb = aa.Split('_');
            //string TradeDate = bb[0];
            //string CommodityId = bb[1];
            //string MaturityMonth = bb[2];
            //string CommodityName = "";

            #region 讀csv資料到變數
            //string line;
            //int counter = 0;
            //string CommodityId;
            //string CommodityNm;
            //string MatchTime;
            //double LastP;
            //int LastQ;
            //int TotalQ;
            //double Bid1P;
            //double Bid1Q;
            //double Ask1P;
            //double Ask1Q;
            //string UnderlyingId;
            //string Kind;
            //string InformationSeq;
            //string InformationTime;
            //string MatchSeq;
            //double Bid2P;
            //int Bid2Q;
            //double Ask2P;
            //int Ask2Q;
            //double Bid3P;
            //int Bid3Q;
            //double Ask3P;
            //int Ask3Q;
            //double Bid4P;
            //int Bid4Q;
            //double Ask4P;
            //int Ask4Q;
            //double Bid5P;
            //int Bid5Q;
            //double Ask5P;
            //int Ask5Q;
            //string Maturity;
            //double Strike;
            //string RecTime;
            //string AdjustTime;

            //while ((line = sr.ReadLine()) != null)
            //{
            //    string[] ReadLine_Array = line.Split(',');
            //    CommodityId = Convert.ToString(ReadLine_Array[0]);
            //    CommodityNm = Convert.ToString(ReadLine_Array[1]);
            //    MatchTime = Convert.ToString(ReadLine_Array[2]);
            //    LastP = Convert.ToDouble(ReadLine_Array[3]);
            //    LastQ = Convert.ToInt32(ReadLine_Array[4]);
            //    TotalQ = Convert.ToInt32(ReadLine_Array[5]);
            //    Bid1P = Convert.ToDouble(ReadLine_Array[6]); 
            //    Bid1Q = Convert.ToInt32(ReadLine_Array[7]);
            //    Ask1P = Convert.ToDouble(ReadLine_Array[8]); 
            //    Ask1Q = Convert.ToInt32(ReadLine_Array[9]);
            //    UnderlyingId = Convert.ToString(ReadLine_Array[10]);
            //    Kind = Convert.ToString(ReadLine_Array[11]); 
            //    InformationSeq = Convert.ToString(ReadLine_Array[12]); 
            //    InformationTime = Convert.ToString(ReadLine_Array[13]);
            //    MatchSeq = Convert.ToString(ReadLine_Array[14]);
            //    Bid2P = Convert.ToDouble(ReadLine_Array[15]);
            //    Bid2Q = Convert.ToInt32(ReadLine_Array[16]);
            //    Ask2P = Convert.ToDouble(ReadLine_Array[17]);
            //    Ask2Q = Convert.ToInt32(ReadLine_Array[18]);
            //    Bid3P = Convert.ToDouble(ReadLine_Array[19]);
            //    Bid3Q = Convert.ToInt32(ReadLine_Array[20]);
            //    Ask3P = Convert.ToDouble(ReadLine_Array[21]);
            //    Ask3Q = Convert.ToInt32(ReadLine_Array[22]);
            //    Bid4P = Convert.ToDouble(ReadLine_Array[23]);
            //    Bid4Q = Convert.ToInt32(ReadLine_Array[24]);
            //    Ask4P = Convert.ToDouble(ReadLine_Array[25]);
            //    Ask4Q = Convert.ToInt32(ReadLine_Array[26]);
            //    Bid5P = Convert.ToDouble(ReadLine_Array[27]);
            //    Bid5Q = Convert.ToInt32(ReadLine_Array[28]);
            //    Ask5P = Convert.ToDouble(ReadLine_Array[29]);
            //    Ask5Q = Convert.ToInt32(ReadLine_Array[30]);
            //    Maturity = Convert.ToString(ReadLine_Array[31]);
            //    Strike = Convert.ToDouble(ReadLine_Array[32]);
            //    RecTime = Convert.ToString(ReadLine_Array[33]);
            //    if (RecTime == "")
            //    {
            //        RecTime = "13:45:00.000000";
            //    }
            //    //AdjustTime = Convert.ToString(ReadLine_Array[34]);

            //}

            #endregion

            DataTable dt = new DataTable();
            DataTable dt2 = new DataTable();
            dt = ConvertFutCSVtoDataTable(dirs[0], false);
            dt2 = ConvertFutCSVtoDataTable(dirs2[0], false);
            //dt.Columns.Add("是否成交", typeof(double));
            //var temp1 = dt.Select("TotalQ = 0");
            DataTable summary = InitializeTable2();

            #region Method1 to select records which TotalQ > 0
            //foreach (DataRow row in dt.Rows)
            //{
            //    //if (int.Parse(row["TotalQ"].ToString()) > 0)
            //    if (row["TotalQ"].ToString() != "0")
            //    {
            //        DataRow newRow = summary.NewRow();
            //        newRow["MatchTime"] = row["MatchTime"].ToString();
            //        newRow["UID"] = row["CommodityId"].ToString();
            //        newRow["LastP"] = row["LastP"].ToString();
            //        newRow["LastQ"] = row["LastQ"].ToString();
            //        newRow["TotalQ"] = row["TotalQ"].ToString();
            //        summary.Rows.Add(newRow);
            //    }
            //}
            #endregion

            #region Method2 to select records which TotalQ > 0
            //--test--var dtresult = dt.AsEnumerable().Where(r => r["TotalQ"].ToString() != "0");
            var dtresult = from r in dt.AsEnumerable()   //inner join
                           from r2 in dt2.AsEnumerable()
                           where 
                           r.Field<string>("MatchTime").Substring(0, 6)  == r2.Field<string>("MatchTime").Substring(0, 6)
                           && Convert.ToDouble(r["LastP"]) == 0 && Convert.ToDouble(r2["LastP"]) == 0
                           select new
                           {
                               //Stock
                               UID = r.Field<string>("CommodityId"),
                               MatchTime = r["MatchTime"],
                               LastP = r["LastP"],
                               LastQ = r["LastQ"],
                               TotalQ = r["TotalQ"],
                               Bid1P = r["Bid1P"],
                               Bid1Q = r["Bid1Q"],
                               Ask1P = r["Ask1P"],
                               Ask1Q = r["Ask1Q"],
                               //Futures
                               FID = r2.Field<string>("CommodityId"),
                               FMatchTime = r2["MatchTime"],
                               FLastP = r2["LastP"],
                               FLastQ = r2["LastQ"],
                               FTotalQ = r2["TotalQ"],
                               FBid1P = r2["Bid1P"],
                               FBid1Q = r2["Bid1Q"],
                               FAsk1P = r2["Ask1P"],
                               FAsk1Q = r2["Ask1Q"],
                           };

            if (dtresult.Count() > 0)
            {
                //List<DataRow> result = dtresult.ToList();
                int count = 1;
                foreach (var dr in dtresult)
                {
                    DataRow newRow = summary.NewRow();
                    newRow["No"] = count;
                    newRow["UID"] = dr.UID.ToString();
                    newRow["MatchTime"] = dr.MatchTime.ToString().Substring(0, 2)+":"+ dr.MatchTime.ToString().Substring(2, 2) + ":" + dr.MatchTime.ToString().Substring(4, 2)+"." + dr.MatchTime.ToString().Substring(6, 3);
                    //newRow["LastP"] = dr.LastP.ToString();
                    //newRow["LastQ"] = dr.LastQ.ToString();
                    newRow["TotalQ"] = dr.TotalQ.ToString();
                    newRow["Bid1P"] = dr.Bid1P.ToString();
                    newRow["Bid1Q"] = dr.Bid1Q.ToString();
                    newRow["Ask1P"] = dr.Ask1P.ToString();
                    newRow["Ask1Q"] = dr.Ask1Q.ToString();

                    //futures data
                    newRow["FID"] = dr.FID.ToString();
                    newRow["FMatchTime"] = dr.FMatchTime.ToString().Substring(0, 2) + ":" + dr.FMatchTime.ToString().Substring(2, 2) + ":" + dr.FMatchTime.ToString().Substring(4, 2) + "." + dr.FMatchTime.ToString().Substring(6, 3);
                    //newRow["FLastP"] = dr.FLastP.ToString();
                    //newRow["FLastQ"] = dr.FLastQ.ToString();
                    newRow["FTotalQ"] = dr.FTotalQ.ToString();
                    newRow["FBid1P"] = dr.FBid1P.ToString();
                    newRow["FBid1Q"] = dr.FBid1Q.ToString();
                    newRow["FAsk1P"] = dr.FAsk1P.ToString();
                    newRow["FAsk1Q"] = dr.FAsk1Q.ToString();
                    newRow["FAsk1Q"] = dr.FAsk1Q.ToString();
                    newRow["BStk_SFut"] = (-Convert.ToDouble(dr.Ask1P) + Convert.ToDouble(dr.FBid1P)).ToString();
                    newRow["SStk_BFut"] = (-Convert.ToDouble(dr.FAsk1P) + Convert.ToDouble(dr.Bid1P)).ToString();
                    summary.Rows.Add(newRow);
                    count++;
                }
            }

            #endregion
            //資料放到DataGridView
            //dataGridView1.DataSource = dt;
            dataGridView1.DataSource = summary;

            //Utility.SaveToCSV(summary, ".\\個股股期Join資料_Summary.csv", true);
            MessageBox.Show("Data Query and Output Complete");

        }
    }
}
