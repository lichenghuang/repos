﻿using System;
using System.IO;
using System.Data.SqlClient;
using System.Data;
using System.Text;
using EDLib.SQL;
using EDLib;
using System.Linq;
using System.Text.RegularExpressions;

namespace CMoneyTest
{
	class Program
	{
		static string WClass(string callPut, string barrier, string WID)
		{
			if (callPut == "認購")
			{
				if (barrier == "一般型")
					return "c";
				else if (barrier == "上限型")
					return "cuo";
				else if (barrier == "下限型")
				{
					if (WID.EndsWith("X"))
						return "xcdo";
					else
						return "cdo";//
				}
			}
			else if (callPut == "認售")
			{
				if (barrier == "一般型")
					return "p";
				else if (barrier == "上限型")
				{
					if (WID.EndsWith("X"))
						return "xpuo";
					else
						return "puo";//
				}
				else if (barrier == "下限型")
					return "pdo";
			}
			return "X";
		}

		static DataTable warrantBasics;

		static void Main(string[] args)
		{
			//CM Connection components
			//CMADODB5.CMConnection conobj = new CMADODB5.CMConnection();
			//ADODB.Recordset rs = new ADODB.Recordset();

			//Get Date
			string date = DateTime.Today.ToString("yyyyMMdd");//Console.ReadLine();
															  //string date = "20180402";
			Console.WriteLine("Inserting newEDIS.WarrantBasics of " + date);

			//CMoney Query
			string sqlStr = "SELECT A.代號, A.名稱, A.標的代號, A.標的名稱, A.發行機構代號,A.[認購／認售], A.上下限型別, A.發行日期,A.上市日期, A.最後交易日, A.到期日期,"
			   + "A.[發行數量(千)],A.[流通數量(千)], A.最新履約價,A.最新限制價格,A.最新執行比例,A.發行價格,A.[發行波動率(%)],A.發行時財務費用年利率,A.[一般證/牛熊證], B.A級發行標的,A.[原始價內外程度(%)],A.[存續期間(月)],A.[原始歷史波動率(%)],A.[利率(%)], A.[類別]"
			   + $" from 權證基本資料表 as A left join [權證標的證券(季)] as B on A.標的代號=B.股票代號 and (B.[有效日期起]<='{date}' and B.[有效日期迄]>='{date}' ) where (A.到期日期 >= '{date}' or A.到期日期 is null )and A.發行日期<='"
			   + $"{date}' and A.年度='{date.Substring(0, 4)}'  order by A.代號";//or (B.年季=left(A.發行日期,4) and B.A級發行標的 is null)//(B.[有效日期起]<=A.發行日期 and B.[有效日期迄]>=A.發行日期 )
																			 //Console.WriteLine(sqlStr);
																			 //Console.ReadKey();
			warrantBasics = CMoney.ExecCMoneyQry(sqlStr);
			//rs = conobj.CMExecute("5", "10.60.0.191", "", sqlStr);//1433

			/*Open SQL Connection & Delete old data*/
#if !DEBUG
			SqlConnection conn = new SqlConnection("Data Source=10.19.1.45;Initial Catalog=newEDIS;User ID=sa;Password=dw910770");
			conn.Open();
			MSSQL.ExecSqlCmd($"Delete WarrantBasics where (IssuedDate<='{date}' and MaturityDate>='{date}') Or MaturityDate='1911/01/01'", conn);
#endif
			//Load Underlying_Trader
			DataTable underlyingTrader = MSSQL.ExecSqlQry("Select UID, TraderAccount ,TraderName from Underlying_Trader", EDLib.GlobalParameters.edis20SqlConnString);

			//Open Output files
			using (StreamWriter cmLog = new StreamWriter(".\\CMoneyOutput.csv", false, Encoding.UTF8))//F:\\Schedule\\CMWarrantBasics
			using (StreamWriter sqlLog = new StreamWriter(".\\CMoneySQLlog.txt"))
			{

				//Output header
				/*
                for (int i = 0; i < rs.Fields.Count; i++) {
                    if (!rs.Fields[i].Name.Equals(string.Empty))
                        cmLog.Write(rs.Fields[i].Name + ",");
                    else
                        cmLog.Write(" ,");
                }
                */
				foreach (DataColumn col in warrantBasics.Columns)
				{
					if (!col.ColumnName.Equals(string.Empty))
						cmLog.Write(col.ColumnName + ",");
					else
						cmLog.Write(" ,");
				}

				cmLog.Write("\n");
				//Insert
				foreach (DataRow row in warrantBasics.Rows)
				{
					string sqlInsert = "Insert WarrantBasics Values( ";

					//WID  WName UID UName IssuerName 
					for (int i = 0; i < 2; i++)//代號, 名稱
						sqlInsert += $"'{row[i].ToString()}',";

					//標的代號
					if (row[2].ToString().Substring(0, 2) == "TX" && row[2].ToString().Length == 8 && row[2].ToString().Substring(2, 6).All(char.IsDigit))
						sqlInsert += $"'{row[1].ToString().Substring(0, 5)}',";
					else
						sqlInsert += $"'{row[2].ToString()}',";

					for (int i = 3; i < 5; i++) //標的名稱, 發行機構代號 
						sqlInsert += $"'{row[i].ToString()}',";

					//WClass//[認購／認售], 上下限型別,[一般證/牛熊證]
					sqlInsert += $"'{WClass(row[5].ToString(), row[6].ToString(), row[0].ToString())}',";// rs.Fields[19].Value.ToString()

					//IssuedDate ListedDate LastTradingDate MaturityDate
					for (int i = 7; i < 11; i++)
					{//發行日期,上市日期, 最後交易日, 到期日期
						if (!row[i].ToString().Equals(string.Empty))//.IsNullOrWhiteSpace()
							sqlInsert += $"'{row[i].ToString()}',";
						else
							sqlInsert += "'19110101',";
					}

					//IssueLots FloatingLots StrikePrice BarrierPrice CR IssuePrice
					for (int i = 11; i < 17; i++)
					{//[發行數量(千)],[流通數量(千)], 最新履約價,最新限制價格,最新執行比例,發行價格
						if (!row[i].ToString().Equals(string.Empty))//.Equals(string.Empty)
							sqlInsert += $"'{row[i].ToString()}',";
						else
							sqlInsert += "'0',";
					}

					//IssueVol_FinRate
					if (!row[17].ToString().Equals(string.Empty) && row[19].ToString().ToUpper() == "FALSE")//[發行波動率(%)],發行時財務費用年利率
						sqlInsert += $"'{row[17].ToString()}',";
					else if (!row[18].ToString().Equals(string.Empty) && row[19].ToString().ToUpper() == "TRUE")
						sqlInsert += $"'{row[18].ToString()}',";
					else
						sqlInsert += "'0',";

					//ClassAOrNot 
					if (!row[20].ToString().Equals(string.Empty) && row[20].ToString().ToUpper() == "TRUE")
						sqlInsert += "1,";
					else
						sqlInsert += "'0',";

					//TraderAccount TraderName                
					DataRow[] result = underlyingTrader.Select($"UID='{row[2].ToString()}'");
					if (result.Length > 0)
						sqlInsert += $"'{result[0][1]}','{result[0][2]}',";
					else
						sqlInsert += "'sys','sys',";

					//Moneyness
					if (!row[21].ToString().Equals(string.Empty))
						sqlInsert += $"'{row[21]}',";
					else
						sqlInsert += "'0',";

					//Duration
					if (!row[22].ToString().Equals(string.Empty))
						sqlInsert += $"'{row[22]}',";
					else
						sqlInsert += "'0',";

					//HistoriacalVol
					if (!row[23].ToString().Equals(string.Empty))
						sqlInsert += $"'{row[23]}',";
					else
						sqlInsert += "'0',";

					//InterestRate
					if (!row[24].ToString().Equals(string.Empty))
						sqlInsert += $"'{row[24]}',";
					else
						sqlInsert += "'0',";

					//Type
					if (!row[25].ToString().Equals(string.Empty))
						sqlInsert += $"'{row[25]}')";
					else
						sqlInsert += "'')";

					//LogFile output
					for (int i = 0; i < row.ItemArray.Length; i++)
					{
						if (!row[i].ToString().Equals(string.Empty))
							cmLog.Write(row[i].ToString() + ",");
						else
							cmLog.Write(" ,");
					}

#if !DEBUG
					try
					{
						MSSQL.ExecSqlCmd(sqlInsert, conn);
					}

					catch (Exception e)
					{
						MailService ms = new MailService();
						//ms.SendMail("allen.li@kgi.com", "10.19.1.45", new string[] { "allen.li@kgi.com" }, null, null, "WarrantBasicsFail", e.Message + "\n" + sqlInsert, false, null);
						ms.SendMail("jerry.zeng@kgi.com", "10.19.1.45", new string[] { "jerry.zeng@kgi.com" }, null, null, "WarrantBasicsFail", e.Message + "\n" + sqlInsert, false, null);
					}
#endif

					sqlLog.WriteLine(sqlInsert);
					cmLog.Write("\n");
				}
#if !DEBUG
				conn.Close();
#endif
			}
		}
	}
}

