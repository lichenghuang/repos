﻿using System;
using System.IO;
using System.Data.SqlClient;
using System.Data;
using EDLib.SQL;
using EDLib;


namespace BrokerNameID
{
    class Program
    {
        static DataTable BrokerNameID;
        static string lastTDate = TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");
        //static string lastTDate_1 = TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");

        static void LoadData()
        {
            string sqlStr = $"SELECT 券商代號, replace(名稱, '-', '') from 券商公司基本資料表 where 年度 = '{lastTDate.Substring(0, 4)}'";
            BrokerNameID = CMoney.ExecCMoneyQry(sqlStr);
            Console.WriteLine("CMoneyCount" + BrokerNameID.Rows.Count);
        }

		static string sqlInsert;

        static void Main(string[] args)
        {
           try
           {
                LoadData();
#if !DEBUG
            /*Open SQL Connection*/
            SqlConnection testEDIS = new SqlConnection("Data Source = 10.19.1.45; Initial Catalog = testEDIS; User ID = sa; Password = dw910770");
            testEDIS.Open();
            MSSQL.ExecSqlCmd("Delete from BrokerNameID", testEDIS);
            //SqlConnection newEDIS = new SqlConnection("Data Source = 10.19.1.45; Initial Catalog = newEDIS; User ID = sa; Password = dw910770");
            //newEDIS.Open();
#endif
                using (StreamWriter sqlLog = new StreamWriter(".\\SQLlog.txt"))
                {
                    foreach(DataRow row in BrokerNameID.Rows)
                    {
                        string sqlstring = string.Join(",", row.ItemArray);
                        sqlLog.WriteLine(sqlstring);
                        sqlInsert = "Insert BrokerNameID Values( '";
                        sqlInsert += $"{row[0].ToString()}', '{row[1].ToString()}')";
#if !DEBUG
                MSSQL.ExecSqlCmd(sqlInsert, testEDIS);
                testEDIS.Close();
#endif
                    }
                }
            }
			catch (Exception e)
			{
				MailService ms = new MailService();
				//ms.SendMail("allen.li@kgi.com", "10.19.1.45", new string[] { "allen.li@kgi.com" }, null, null, "WarrantBasicsFail", e.Message + "\n" + sqlInsert, false, null);
				ms.SendMail("jerry.zeng@kgi.com", "10.19.1.45", new string[] { "jerry.zeng@kgi.com" }, null, null, "BrokerNameIDFail", e.Message + "\n" + sqlInsert, false, null);
			}
		}
    }
}
