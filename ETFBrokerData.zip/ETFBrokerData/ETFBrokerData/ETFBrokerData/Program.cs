﻿using System;
using System.Linq;
using EDLib;
using EDLib.SQL;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace ETFBrokerData
{
    class Program
    {
        static DataTable etfBroker;
        //static DataTable summary;
        static DataTable InitializeTables()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("TDate", typeof(string));
            dt.Columns.Add("ETFID", typeof(string));
            dt.Columns.Add("ETFName", typeof(string));
            dt.Columns.Add("BrokerID", typeof(string));
            dt.Columns.Add("BrokerSubID", typeof(string));
            dt.Columns.Add("BrokerSubName", typeof(string));
            dt.Columns.Add("BuyingLots", typeof(int));
            dt.Columns.Add("SellingLots", typeof(int));
            dt.Columns.Add("BuyingAmount", typeof(int));
            dt.Columns.Add("SellingAmount", typeof(int));
            return dt;
        }

        //static string lastTDate = TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");
        static string lastTDate = DateTime.Now.ToString("yyyyMMdd");
        //static string lastTDate = "20190430";
        static List<string> LastTDateList = new List<string>() ;

        static void Main(string[] args)
        {
            LastTDateList.Add(lastTDate);
            foreach (string lastTDate in LastTDateList)
            {
                Console.WriteLine(lastTDate);
                Console.WriteLine("Cmoney Data Query Begins...");

                try
                {

                    string sqlStr = "SELECT A.日期, A.股票代號, D.股票名稱, E.總公司代號, A.券商代號, A.券商名稱, isnull(A.買張,0) as buy , isnull(A.賣張,0) * -1 as sell, isnull(A.張增減,0) as netbs "
                    + " ,isnull(A.[買金額(千)],0) as buyA, isnull(A.[賣金額(千)],0) * -1 as sellA, isnull(A.[金額增減(千)],0) as netbsA "
                    + " from 個股券商分點進出明細 as A "
                    + " left join ETF基本資料表 as D on D.股票代號=A.股票代號 "
                    + " left join 券商公司基本資料表 as E on A.券商代號=E.代號 "
                    //+ " left join 個股券商進出明細 as C on C.股票代號=A.股票代號 and E.總公司代號=C.券商代號 and A.日期=C.日期 "
                    + $" where A.日期='{lastTDate}' and D.年度='{lastTDate.Substring(0, 4)}' and E.年度='{lastTDate.Substring(0, 4)}'  "
                    //+ " group by A.日期, A.股票代號, A.券商代號, E.總公司代號, D.股票名稱 , C.買張 , C.賣張, C.張增減, C.[買金額(千)], C.[賣金額(千)], C.[金額增減(千)] "
                    //+ " having Sum(A.買張)-isnull(C.買張,0)<>0 or Sum(A.賣張)-isnull(C.賣張,0)<>0 or Sum(A.張增減)-isnull(C.張增減,0)<>0 or Sum(A.[買金額(千)])-isnull(C.[買金額(千)],0)<>0 or Sum(A.[賣金額(千)])-isnull(C.[賣金額(千)],0)<>0 or Sum(A.[金額增減(千)])-isnull(C.[金額增減(千)],0) <>0"
                    + " order by A.股票代號, E.總公司代號, A.券商代號 ";


                    etfBroker = CMoney.ExecCMoneyQry(sqlStr);
                    Utility.SaveToCSV(etfBroker, $".\\etfBroker_{lastTDate}.csv", true);
                    Console.WriteLine("Cmoney Data Output to CSV Complete...");

                    #region 整理到DataTable
                    //DataTable summary = InitializeTables();  //ETF資料
                    //if (etfBroker.Rows.Count > 0)
                    //{
                    //    foreach (DataRow row in etfBroker.Rows)
                    //    {
                    //        DataRow newRow = summary.NewRow();
                    //        newRow["TDate"] = row["日期"].ToString();
                    //        newRow["ETFID"] = row["股票代號"].ToString();
                    //        newRow["ETFName"] = row["股票名稱"].ToString();
                    //        newRow["BrokerID"] = row["總公司代號"].ToString();
                    //        newRow["BrokerSubID"] = row["券商代號"].ToString();
                    //        newRow["BrokerSubName"] = row["券商名稱"].ToString();
                    //        newRow["BuyingLots"] = row["buy"];
                    //        newRow["SellingLots"] = row["sell"];
                    //        newRow["BuyingAmount"] = row["buyA"];
                    //        newRow["SellingAmount"] = row["sellA"];

                    //        summary.Rows.Add(newRow);
                    //    }
                    //}
                    //Utility.SaveToCSV(summary, ".\\ETFsummary.csv", true);

                    #endregion

                    #region 寫入資料庫
#if !DEBUG
                    using (SqlConnection conn = new SqlConnection("Data Source=10.19.1.45;Initial Catalog=testEDIS;User ID=sa;Password=dw910770"))
                    {
                        conn.Open();
                        //MSSQL.ExecSqlCmd($"DELETE FROM ETFBroker WHERE TDate>='{lastTDate}' and TDate<='{lastTDate} 23:59'", conn);
                        Console.WriteLine($"Inserting ETFBroker of {lastTDate}");
                        foreach (DataRow row in etfBroker.Rows)
                        {

                            string SQLcmd = $@"Insert into ETFBroker(TDate, ETFID,  ETFName, BrokerID, BrokerSubID, BrokerSubName, BuyingLots, SellingLots, BuyingAmount, SellingAmount) Values("
                                + $"'{row[0].ToString()}','{row[1].ToString()}', '{row[2].ToString()}', '{row[3].ToString()}', '{row[4].ToString()}', '{row[5].ToString()}', {row[6].ToString()}, {row[7].ToString()}, {row[9].ToString()}, '{row[10].ToString()}')";
                            MSSQL.ExecSqlCmd(SQLcmd, conn);
                        }

                        //Console.WriteLine(SQLcmd);

                        Console.WriteLine("Cmoney Data Insert Complete");
                    }
#endif
                    #endregion

                }
                catch (Exception e)
                {
                    //Console.ReadLine();
                    MailService ms = new MailService();
                    ms.SendMail("lecheng@kgi.com", "10.19.1.45 ERROR", new string[] { "lecheng@kgi.com" }, null, null, $"{lastTDate}ETFBroker ERROR!", e.ToString(), false, null);

                }
            }
            
        }
    }
}
