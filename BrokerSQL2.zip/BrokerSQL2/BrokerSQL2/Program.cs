﻿using System;
using System.Data.SqlClient;
using System.IO;
using System.Threading;
using EDLib;
using EDLib.SQL;

namespace BrokerSQL2
{
    class Program
    {
        static void Main(string[] args) {
            StreamReader reader = null;

            /*Get Input & open the daily quotation files*/
            try {
#if !DEBUG                
                string date = TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");//Console.ReadLine();// "20180629";//
#else
                Console.Write("Please inpute date (yyyyMMdd):");
                string date = Console.ReadLine();
#endif
                Console.WriteLine("Inserting WarrantTradingBroker of " + date);

				reader = new StreamReader($"\\\\10.19.1.203\\Warrant\\QuoteData\\JQuote\\{date}\\WarrantDataBrokerRecognized.csv", System.Text.Encoding.Default);//TODO

				/*Open SQL Connection & Delete old data*/
				using (StreamWriter sqlLog = new StreamWriter(".\\SQLlog.txt"))
                using (SqlConnection conn = new SqlConnection("Data Source=10.19.1.45;Initial Catalog=testEDIS;User ID=sa;Password=dw910770")) {
                    conn.Open();
                    MSSQL.ExecSqlCmd($"DELETE FROM WarrantTradingBroker WHERE TDate>='{date}' and TDate<='{date} 23:59'", conn);
                    string[] stringSeparators = { "\",\"", "\",", ",\"", "," };
                    string[] lineSplit = reader.ReadLine().Split(stringSeparators, StringSplitOptions.None);

                    while (!reader.EndOfStream) {
						lineSplit = reader.ReadLine().Split(stringSeparators, StringSplitOptions.None);
						for (int i = 0; i < lineSplit.Length; i++)
						{
							lineSplit[i] = lineSplit[i].ToString() == "NA" ? "(NULL)" : lineSplit[i];
						}
						string SQLcmd = "Insert into WarrantTradingBroker(TDate, WID, LastPx, LastQty, BrokerBuy, BrokerSell, BrokerBuyFlag, BrokerSellFlag, RanOver, PnL, SerialNumber  ) Values('"
                          + lineSplit[0].TrimStart('"') + "','" + lineSplit[1] + "','" + lineSplit[83] + "','" + lineSplit[87] + "','" + lineSplit[88] + "','" + lineSplit[89] + "','" + lineSplit[90]
                          + "','" + lineSplit[95] + "','" + lineSplit[84] + "'," + lineSplit[96] + ",'" + lineSplit[82] + "')";
                        //+ LineSplit[0] + "','" + LineSplit[1] + "','" + LineSplit[8] + "','" + LineSplit[10] + "','" + LineSplit[80] + "','" + LineSplit[81] + "','" + LineSplit[82]
                        //    + "','" + LineSplit[83] + "','" + LineSplit[86].Remove(LineSplit[86].Length - 1 , 1) + "')";

                        //Console.WriteLine(SQLcmd);//
                        sqlLog.WriteLine(SQLcmd);
                        MSSQL.ExecSqlCmd(SQLcmd, conn);
                    }
                }

            } catch (Exception e) {
                MailService ms = new MailService();
				ms.SendMail("jerry.zeng@kgi.com", "10.19.1.45 ERROR", new string[] { "jerry.zeng@kgi.com" }, null, null, "BrokerSQL2 ERROR!", e.ToString(), false, null);
			} finally {
                if (reader != null)
                    reader.Close();
            }
        }
    }
}
