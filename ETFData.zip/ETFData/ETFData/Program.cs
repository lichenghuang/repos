﻿using System;
using System.Linq;
using EDLib;
using EDLib.SQL;
using System.Data;
using System.Data.SqlClient;

namespace ETFData
{
	class Program
	{
		static DataTable etfMML;
		static DataTable etfMM;
		static DataTable summary;

		static string lastTDate =  TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");//"20170713";//
		
		static void Main(string[] args)
		{
			//for (int i = 991; i >= 1; i--)
			//{
			//lastTDate = TradeDate.LastNTradeDate(i).ToString("yyyyMMdd");
				Console.WriteLine(lastTDate);
				//自營ETF交易資料
				try
				{
					string sqlStr = "SELECT A.日期, A.股票代號, D.股票名稱, E.總公司代號, Sum(A.買張)-isnull(C.買張,0) as buy , (Sum(A.賣張)-isnull(C.賣張,0)) * -1 as sell, Sum(A.張增減)-isnull(C.張增減,0) as netbs "
					+ " ,Sum(A.[買金額(千)])-isnull(C.[買金額(千)],0) as buyA, (Sum(A.[賣金額(千)])-isnull(C.[賣金額(千)],0)) * -1 as sellA, Sum(A.[金額增減(千)])-isnull(C.[金額增減(千)],0) as netbsA "
					+ " from 個股券商分點進出明細 as A "
					+ " left join ETF基本資料表 as D on D.股票代號=A.股票代號 "
					+ " left join 券商公司基本資料表 as E on A.券商代號=E.代號 "
					+ " left join 個股券商進出明細 as C on C.股票代號=A.股票代號 and E.總公司代號=C.券商代號 and A.日期=C.日期 "
					+ $" where A.日期='{lastTDate}' and D.年度='{lastTDate.Substring(0, 4)}' and E.年度='{lastTDate.Substring(0, 4)}' "
					+ " group by A.日期, A.股票代號, E.總公司代號, D.股票名稱 , C.買張 , C.賣張, C.張增減, C.[買金額(千)], C.[賣金額(千)], C.[金額增減(千)] "
					+ " having Sum(A.買張)-isnull(C.買張,0)<>0 or Sum(A.賣張)-isnull(C.賣張,0)<>0 or Sum(A.張增減)-isnull(C.張增減,0)<>0 or Sum(A.[買金額(千)])-isnull(C.[買金額(千)],0)<>0 or Sum(A.[賣金額(千)])-isnull(C.[賣金額(千)],0)<>0 or Sum(A.[金額增減(千)])-isnull(C.[金額增減(千)],0) <>0"
					+ " order by A.股票代號 ";

					etfMM = CMoney.ExecCMoneyQry(sqlStr);
					etfMM.Columns.Add("Lamount", typeof(string));
					foreach (DataRow row in etfMM.Rows)
					{
						row["Lamount"] = "N";
					}

					//鉅額交易
					sqlStr = "SELECT A.日期, A.股票代號, D.股票名稱, E.總公司代號, A.買張 as buy , (A.賣張) * -1 as sell, A.張增減 as netbs "
					+ " ,A.[買金額(千)] buyA, (A.[賣金額(千)]) * -1 as sellA, A.[金額增減(千)] as netbsA "
					+ " from 個股券商分點進出鉅額明細 as A "
					+ " left join ETF基本資料表 as D on D.股票代號=A.股票代號 "
					+ " left join 券商公司基本資料表 as E on A.券商代號 = E.代號 "
					+ $" where A.日期='{lastTDate}' and D.年度='{lastTDate.Substring(0, 4)}' and E.年度='{lastTDate.Substring(0, 4)}' "
					+ " and isnull(D.股票代號, '1') <> '1' and A.券商代號 = E.總公司代號"
					+ " order by A.股票代號 ";

					etfMML = CMoney.ExecCMoneyQry(sqlStr);
					Utility.SaveToCSV(etfMM, ".\\etf.csv", true);
					Utility.SaveToCSV(etfMML, ".\\etfL.csv", true);

					if (etfMML.Rows.Count > 0)
					{
						etfMML.Columns.Add("Lamount", typeof(string));
						foreach (DataRow row in etfMML.Rows)
						{
							row["Lamount"] = "Y";
						}
						summary = etfMM.AsEnumerable().Union(etfMML.AsEnumerable()).CopyToDataTable();
					}
					else
					{
						summary = etfMM;
					}

					Utility.SaveToCSV(summary, ".\\etfSummary.csv", true);
#if !DEBUG
					using (SqlConnection conn = new SqlConnection("Data Source=10.19.1.45;Initial Catalog=testEDIS;User ID=sa;Password=dw910770"))
					{
						conn.Open();
						MSSQL.ExecSqlCmd($"DELETE FROM ETFTradingBroker WHERE TDate>='{lastTDate}' and TDate<='{lastTDate} 23:59'", conn);
						Console.WriteLine($"Inserting ETFTradingBroker of {lastTDate}");
						foreach (DataRow row in summary.Rows)
						{
							string SQLcmd = $@"Insert into ETFTradingBroker(TDate, ETFID,  ETFName, BrokerID, BuyingLots, SellingLots, BuyingAmount, SellingAmount, LAmount) Values("
									+ $"'{row[0].ToString()}','{row[1].ToString()}', '{row[2].ToString()}', '{row[3].ToString()}', {row[4].ToString()}, {row[5].ToString()}, {row[7].ToString()}, {row[8].ToString()}, '{row[10].ToString()}')";
							MSSQL.ExecSqlCmd(SQLcmd, conn);
							//Console.WriteLine(SQLcmd);
						}
					}
#endif
				}
				catch (Exception e)
				{
					//Console.ReadLine();
					MailService ms = new MailService();
					ms.SendMail("lecheng@kgi.com", "10.19.1.45 ERROR", new string[] { "lecheng@kgi.com" }, null, null, $"{lastTDate}ETFTradingBroker ERROR!", e.ToString(), false, null);
				}
			//}
		}
	}
}
