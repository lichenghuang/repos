﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Add
    {
        public int Fun1(int i, int j)
        {
            return (i + j);
        }
    }
}